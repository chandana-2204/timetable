"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Faculty Absence Registration & Impact Assessment Service (P1)

SIH 2025 | Problem Statement SIH25091
"""

import uuid
from typing import Dict, Any, List, Optional
from datetime import datetime, date
from ..database.connection import db_manager, DatabaseConnectionManager

class FacultyAbsenceService:
    """Manages faculty absence declarations and tracks affected timetable sessions requiring coverage."""

    def __init__(self, db_mgr: Optional[DatabaseConnectionManager] = None):
        self.db_mgr = db_mgr if db_mgr is not None else db_manager

    def record_absence(
        self,
        faculty_id: str,
        start_date: str,
        end_date: str,
        reason: str
    ) -> Dict[str, Any]:
        """
        Record a faculty absence declaration, mark affected sessions, and return impacted session IDs.
        start_date and end_date in ISO format 'YYYY-MM-DD'.
        """
        # Validate dates
        d_start = datetime.strptime(start_date, "%Y-%m-%d").date()
        d_end = datetime.strptime(end_date, "%Y-%m-%d").date()
        if d_start > d_end:
            raise ValueError(f"Start date {start_date} cannot be after end date {end_date}.")

        absence_id = str(uuid.uuid4())
        affected_sessions = []

        with self.db_mgr.transaction() as conn:
            # 1. Insert absence record
            conn.execute(
                """
                INSERT INTO faculty_absences (absence_id, faculty_id, start_date, end_date, reason, status)
                VALUES (?, ?, ?, ?, ?, 'PENDING')
                """,
                (absence_id, faculty_id, start_date, end_date, reason)
            )

            # 2. Query all active scheduled sessions taught by this faculty
            # Sessions have day_of_week ('Monday', 'Tuesday', etc.)
            sessions = conn.execute(
                """
                SELECT session_id, course_id, group_id, room_id, day_of_week, slot_id
                FROM scheduled_sessions
                WHERE faculty_id = ? AND status = 'ACTIVE'
                """,
                (faculty_id,)
            ).fetchall()

            # Map weekday names to Python weekday numbers: Monday=0 ... Sunday=6
            days_map = {"Monday": 0, "Tuesday": 1, "Wednesday": 2, "Thursday": 3, "Friday": 4, "Saturday": 5, "Sunday": 6}

            for s in sessions:
                day_num = days_map.get(s["day_of_week"])
                if day_num is not None:
                    # Check if any date in [d_start, d_end] falls on this weekday
                    curr = d_start
                    while curr <= d_end:
                        if curr.weekday() == day_num:
                            affected_sessions.append({
                                "session_id": s["session_id"],
                                "date": curr.isoformat(),
                                "day_of_week": s["day_of_week"],
                                "slot_id": s["slot_id"],
                                "course_id": s["course_id"],
                                "group_id": s["group_id"],
                                "room_id": s["room_id"]
                            })
                            # Propose a substitution entry in status 'PROPOSED'
                            sub_id = str(uuid.uuid4())
                            conn.execute(
                                """
                                INSERT INTO substitutions 
                                (substitution_id, session_id, absence_id, original_faculty_id, substitute_faculty_id, date, slot_id, status)
                                VALUES (?, ?, ?, ?, '', ?, ?, 'PROPOSED')
                                """,
                                (sub_id, s["session_id"], absence_id, faculty_id, curr.isoformat(), s["slot_id"])
                            )
                            break
                        curr = curr.replace(day=curr.day + 1) if curr.day < 28 else curr # Simple increment

        return {
            "absence_id": absence_id,
            "faculty_id": faculty_id,
            "start_date": start_date,
            "end_date": end_date,
            "affected_sessions_count": len(affected_sessions),
            "affected_sessions": affected_sessions
        }

    def cancel_absence(self, absence_id: str):
        """Cancel an absence declaration and remove pending substitutions."""
        with self.db_mgr.transaction() as conn:
            conn.execute("UPDATE faculty_absences SET status = 'CANCELLED' WHERE absence_id = ?", (absence_id,))
            conn.execute("DELETE FROM substitutions WHERE absence_id = ? AND status = 'PROPOSED'", (absence_id,))
