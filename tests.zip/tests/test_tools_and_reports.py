"""
Verification and Integration Tests for Tools and Reports Modules
SIH 2025 | Problem Statement SIH25091
"""

import os
import io
import pytest
import pandas as pd

from src.data.loader import TimetableDataLoader
from src.tools.registry import TOOL_CATALOG, get_tool_by_id, get_tools_by_category
from src.reports.service import ReportService
from src.exports.exporter import TimetableExporter
from src.csp.solver import TimetableCSPSolver
from src.database.connection import DatabaseConnectionManager

base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

@pytest.fixture(scope="session")
def project_data():
    loader = TimetableDataLoader(data_dir=os.path.join(base_dir, "data", "synthetic"))
    return loader.load_all()

@pytest.fixture(scope="session")
def solved_records(project_data):
    solver = TimetableCSPSolver(data_dict=project_data, solver_mode="baseline", max_backtracks=200, timeout_seconds=5.0)
    res = solver.solve()
    return res["schedule_records"]

@pytest.fixture(scope="session")
def report_service(project_data, solved_records):
    return ReportService(data_dict=project_data, schedule_records=solved_records)


def test_tool_catalog_structure_and_completeness():
    """Verify all 12 tools exist, have required metadata fields, and no placeholders."""
    assert len(TOOL_CATALOG) == 12
    required_keys = [
        "id", "category", "name", "tagline", "purpose", "problem_solved",
        "required_inputs", "backend_function", "expected_result",
        "modifies_data", "requires_approval", "allowed_roles", "status", "icon"
    ]
    categories = set()
    for tool in TOOL_CATALOG:
        for k in required_keys:
            assert k in tool, f"Tool {tool.get('id')} missing key '{k}'"
        assert tool["status"] == "Working"
        assert len(tool["allowed_roles"]) > 0
        categories.add(tool["category"])

    expected_categories = {
        "Timetable Generation", "Timetable Validation",
        "Optimization & Diagnostics", "Academic Operations"
    }
    assert categories == expected_categories


def test_report_service_master_timetable(report_service):
    """Verify Master Timetable report aggregation and filtering."""
    res_all = report_service.master_timetable()
    assert res_all["total_sessions"] > 0
    assert len(res_all["records"]) == res_all["total_sessions"]
    assert "day" in res_all["records"][0]
    assert "slot_id" in res_all["records"][0]

    # Filter by section
    sample_group = res_all["records"][0]["group_id"]
    res_grp = report_service.master_timetable(group_id=sample_group)
    assert 0 < res_grp["total_sessions"] <= res_all["total_sessions"]
    for r in res_grp["records"]:
        assert r["group_id"] == sample_group


def test_report_service_grid_timetable(report_service):
    """Verify 2D day x slot matrix construction for cohort, faculty, and room."""
    res_all = report_service.master_timetable()
    sample_group = res_all["records"][0]["group_id"]

    grid_res = report_service.grid_timetable("group", sample_group)
    grid = grid_res["grid"]
    assert "Monday" in grid
    assert "Friday" in grid
    assert len(grid["Monday"]) == 7
    assert grid_res["total_assigned"] > 0


def test_report_service_faculty_workload(report_service):
    """Verify Faculty Workload report computes teaching loads and overload status."""
    res = report_service.faculty_workload_report()
    assert res["total_faculty"] > 0
    df = res["dataframe"]
    assert not df.empty
    assert "weekly_assigned" in df.columns
    assert "utilization_pct" in df.columns
    assert "status" in df.columns
    assert res["average_utilization"] >= 0.0


def test_report_service_room_utilization(report_service):
    """Verify Room Utilization calculates slot occupancy across 35 standard weekly slots."""
    res = report_service.room_utilization_report()
    assert res["total_rooms"] > 0
    df = res["dataframe"]
    assert not df.empty
    assert "occupied_slots" in df.columns
    assert "free_slots" in df.columns
    assert "utilization_pct" in df.columns
    for _, row in df.iterrows():
        assert row["occupied_slots"] + row["free_slots"] == 35


def test_report_service_curriculum_coverage(report_service):
    """Verify Curriculum Coverage compares required vs scheduled sessions."""
    res = report_service.curriculum_coverage()
    assert res["total_requirements"] > 0
    assert res["coverage_pct"] > 0.0
    assert len(res["rows"]) == res["total_requirements"]


def test_report_service_database_audits(report_service):
    """Verify database operations and system version reports query live tables."""
    ops_res = report_service.operations_audit_report()
    assert "absences_df" in ops_res
    assert "makeups_df" in ops_res
    assert "reschedules_df" in ops_res

    sys_res = report_service.system_version_and_audit_report()
    assert "versions_df" in sys_res
    assert "audit_logs_df" in sys_res


def test_report_in_memory_exports(report_service):
    """Verify report data can be exported in-memory to CSV, Excel, and PDF."""
    res = report_service.master_timetable()
    records = res["records"]

    csv_buf = TimetableExporter.export_to_csv_buffer(records)
    assert len(csv_buf.getvalue()) > 0

    excel_buf = TimetableExporter.export_to_excel_buffer(records)
    assert len(excel_buf.getvalue()) > 0

    pdf_buf = TimetableExporter.export_to_pdf_buffer(records, title="Test Report")
    assert len(pdf_buf.getvalue()) > 0
