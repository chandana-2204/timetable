"""
Comprehensive Backend Test Suite for Phase 2 Implementation
SIH 2025 | Problem Statement SIH25091

Covers:
1. Scheduling correctness (VAL-01, CSP-01, SOL-01)
2. Generalized Cohort Overlap Manager (arbitrary cohort IDs, disjoint vs shared)
3. Database persistence, foreign keys, uniqueness, idempotent seeding, rollback
4. Operations: Makeup class joint feasibility, Absence registration, Substitute matching, Localized rescheduling, Publishing gate
5. In-memory export synchronization (CSV, Excel, PDF)
6. Cryptographic authentication and role-based access control
7. Google OR-Tools CP-SAT solver
"""

import os
import sys
import io
import pytest
import pandas as pd
import sqlite3

base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if base_dir not in sys.path:
    sys.path.insert(0, base_dir)

from src.data.loader import TimetableDataLoader
from src.csp.overlap import CohortOverlapManager
from src.csp.constraints import ScheduleState, SessionVariable, AssignmentValue
from src.csp.solver import TimetableCSPSolver
from src.validation.validator import IndependentTimetableValidator
from src.exports.exporter import TimetableExporter
from src.database.connection import DatabaseConnectionManager
from src.database.seeder import DatabaseSeeder
from src.auth.service import AuthService, PasswordHasher
from src.operations.makeup_service import MakeupSchedulingService
from src.operations.absence_service import FacultyAbsenceService
from src.operations.substitute_matcher import SubstituteMatcher
from src.operations.rescheduler import LocalizedRescheduler
from src.operations.publishing_service import TimetablePublishingService
from src.solver.ortools_solver import TimetableCPSATSolver

@pytest.fixture(scope="session")
def project_data():
    loader = TimetableDataLoader(data_dir=os.path.join(base_dir, "data", "synthetic"))
    return loader.load_all()

@pytest.fixture(scope="session")
def test_db_path(tmp_path_factory):
    db_file = str(tmp_path_factory.mktemp("db") / "test_timetable.db")
    return db_file

@pytest.fixture(scope="session")
def test_db_mgr(test_db_path):
    mgr = DatabaseConnectionManager(db_path=test_db_path)
    # Seed database
    seeder = DatabaseSeeder(data_dir=os.path.join(base_dir, "data", "synthetic"), db_mgr=mgr)
    seeder.seed_all()
    return mgr


# =====================================================================
# 1. SCHEDULING CORRECTNESS (VAL-01, CSP-01, SOL-01)
# =====================================================================

def test_val01_validator_four_fundamental_cases(project_data):
    """
    VAL-01 Regression: Verify all four fundamental resource tracking cases.
    1. Two different rooms at same time: valid.
    2. Same room at same time: invalid.
    3. Same faculty at same time: invalid.
    4. Different faculty at same time: valid.
    """
    # Case 1 & 4: Two different rooms AND two different faculty at same time -> VALID
    valid_records = [
        {
            "variable_id": "V1", "course_id": "CS101", "group_id": "GRP_CSE_A",
            "faculty_id": "FAC01", "room_id": "ROOM_CR201", "day": "Monday",
            "slot_id": 2, "room_type": "Classroom", "enrolled_strength": 40
        },
        {
            "variable_id": "V2", "course_id": "CS101", "group_id": "GRP_CSE_B",
            "faculty_id": "FAC02", "room_id": "ROOM_CR202", "day": "Monday",
            "slot_id": 2, "room_type": "Classroom", "enrolled_strength": 40
        }
    ]
    is_valid_1, errs_1 = IndependentTimetableValidator.validate(valid_records, project_data, check_fixed_schedules=False)
    assert is_valid_1 is True, f"Distinct rooms and distinct faculty must be valid: {errs_1}"

    # Case 2: Same room at same time -> INVALID
    same_room_records = [
        {
            "variable_id": "V1", "course_id": "CS101", "group_id": "GRP_CSE_A",
            "faculty_id": "FAC01", "room_id": "ROOM_CR201", "day": "Monday",
            "slot_id": 2, "room_type": "Classroom", "enrolled_strength": 40
        },
        {
            "variable_id": "V2", "course_id": "MA101", "group_id": "GRP_CSE_B",
            "faculty_id": "FAC02", "room_id": "ROOM_CR201", "day": "Monday",
            "slot_id": 2, "room_type": "Classroom", "enrolled_strength": 40
        }
    ]
    is_valid_2, errs_2 = IndependentTimetableValidator.validate(same_room_records, project_data, check_fixed_schedules=False)
    assert is_valid_2 is False
    assert any("Room ROOM_CR201 double-booked" in e for e in errs_2)

    # Case 3: Same faculty at same time -> INVALID
    same_fac_records = [
        {
            "variable_id": "V1", "course_id": "CS101", "group_id": "GRP_CSE_A",
            "faculty_id": "FAC01", "room_id": "ROOM_CR201", "day": "Monday",
            "slot_id": 2, "room_type": "Classroom", "enrolled_strength": 40
        },
        {
            "variable_id": "V2", "course_id": "CS101", "group_id": "GRP_CSE_B",
            "faculty_id": "FAC01", "room_id": "ROOM_CR202", "day": "Monday",
            "slot_id": 2, "room_type": "Classroom", "enrolled_strength": 40
        }
    ]
    is_valid_3, errs_3 = IndependentTimetableValidator.validate(same_fac_records, project_data, check_fixed_schedules=False)
    assert is_valid_3 is False
    assert any("Faculty FAC01 double-booked" in e for e in errs_3)


def test_val01_multi_room_detection_no_missed_clashes(project_data):
    """VAL-01: Verify that double-booking in a secondary room is NEVER missed (audit flaw regression)."""
    records = [
        # Session 1: Room CR201 at Monday Slot 1
        {"variable_id": "V1", "course_id": "CS101", "group_id": "GRP_CSE_A", "faculty_id": "FAC01", "room_id": "ROOM_CR201", "day": "Monday", "slot_id": 2, "room_type": "Classroom", "enrolled_strength": 40},
        # Session 2: Room CR202 at Monday Slot 1
        {"variable_id": "V2", "course_id": "CS201", "group_id": "GRP_CSE_B", "faculty_id": "FAC02", "room_id": "ROOM_CR202", "day": "Monday", "slot_id": 2, "room_type": "Classroom", "enrolled_strength": 40},
        # Session 3: Room CR202 at Monday Slot 1 (DOUBLE BOOKING of CR202)
        {"variable_id": "V3", "course_id": "AI201", "group_id": "GRP_AIDS_A", "faculty_id": "FAC04", "room_id": "ROOM_CR202", "day": "Monday", "slot_id": 2, "room_type": "Classroom", "enrolled_strength": 40}
    ]
    is_valid, errs = IndependentTimetableValidator.validate(records, project_data, check_fixed_schedules=False)
    assert is_valid is False
    # Must catch the double booking of ROOM_CR202
    assert any("Room ROOM_CR202 double-booked" in e for e in errs)


def test_csp01_generalized_cohort_overlap_manager():
    """CSP-01: Generalized overlap model across arbitrary IDs, sections, electives, and lab subgroups."""
    overlap_mgr = CohortOverlapManager()
    
    # Register Arbitrary Cohorts
    # Cohort 1: SEC_X (Students 1 to 30)
    overlap_mgr.register_cohort("SEC_X", [f"STU_{i:03d}" for i in range(1, 31)])
    # Cohort 2: LAB_X1 (Students 1 to 15, sub-group of SEC_X)
    overlap_mgr.register_cohort("LAB_X1", [f"STU_{i:03d}" for i in range(1, 16)])
    # Cohort 3: ELECTIVE_Y (Students 25 to 45, crosses SEC_X and others)
    overlap_mgr.register_cohort("ELECTIVE_Y", [f"STU_{i:03d}" for i in range(25, 46)])
    # Cohort 4: SEC_Z (Students 50 to 80, completely disjoint)
    overlap_mgr.register_cohort("SEC_Z", [f"STU_{i:03d}" for i in range(50, 81)])

    # 1. Disjoint cohorts can be scheduled simultaneously
    assert overlap_mgr.have_overlap("SEC_X", "SEC_Z") is False
    has_clash, _ = overlap_mgr.has_clash_with_active_cohorts("SEC_Z", ["SEC_X"])
    assert has_clash is False

    # 2. Section and its lab subgroup overlap -> CANNOT be simultaneous
    assert overlap_mgr.have_overlap("SEC_X", "LAB_X1") is True
    has_clash_lab, _ = overlap_mgr.has_clash_with_active_cohorts("LAB_X1", ["SEC_X"])
    assert has_clash_lab is True

    # 3. Multidisciplinary elective sharing students with core section -> CANNOT be simultaneous
    assert overlap_mgr.have_overlap("SEC_X", "ELECTIVE_Y") is True
    shared = overlap_mgr.get_shared_members("SEC_X", "ELECTIVE_Y")
    assert len(shared) == 6 # STU_025 through STU_030

    # 4. Identity check
    assert overlap_mgr.have_overlap("SEC_X", "SEC_X") is True


def test_csp01_overlap_enforced_in_schedule_state():
    """CSP-01: Verify ScheduleState rejects overlapping cohorts at the same slot."""
    overlap_mgr = CohortOverlapManager.from_dict({
        "GRP_CSE_A": ["S1", "S2", "S3", "S4"],
        "GRP_MDC_B1": ["S3", "S4", "S5", "S6"], # S3 and S4 shared!
        "GRP_DISJOINT": ["S10", "S11"]
    })

    state = ScheduleState(faculty_max_daily={"FAC01": 4, "FAC02": 4}, overlap_manager=overlap_mgr)

    var1 = SessionVariable(
        var_id="V1", curriculum_id="C1", course_id="CS101", course_name="CS",
        group_id="GRP_CSE_A", faculty_id="FAC01", faculty_name="Dr. Raman",
        session_index=1, required_room_type="Classroom", enrolled_count=40, is_lab=False
    )
    val1 = AssignmentValue(day="Monday", slot_id=2, room_id="ROOM_CR201")
    state.assign(var1, val1)

    # Disjoint cohort assignment at same slot -> SUCCEEDS
    var_disjoint = SessionVariable(
        var_id="V_DIS", curriculum_id="CD", course_id="EC101", course_name="EC",
        group_id="GRP_DISJOINT", faculty_id="FAC02", faculty_name="Dr. Menon",
        session_index=1, required_room_type="Classroom", enrolled_count=40, is_lab=False
    )
    val_disjoint = AssignmentValue(day="Monday", slot_id=2, room_id="ROOM_CR202")
    is_valid_dis, _ = state.is_valid_assignment(var_disjoint, val_disjoint)
    assert is_valid_dis is True

    # Overlapping elective cohort at same slot -> REJECTED
    var_mdc = SessionVariable(
        var_id="V_MDC", curriculum_id="CM", course_id="MDC101", course_name="MDC",
        group_id="GRP_MDC_B1", faculty_id="FAC02", faculty_name="Dr. Menon",
        session_index=1, required_room_type="Classroom", enrolled_count=40, is_lab=False
    )
    is_valid_mdc, reason = state.is_valid_assignment(var_mdc, val_disjoint)
    assert is_valid_mdc is False
    assert "shares 2 members with active group GRP_CSE_A" in reason


def test_sol01_solver_truthful_status_reporting(project_data):
    """SOL-01: Verify solver truthfully reports FEASIBLE and is_optimal=False."""
    solver = TimetableCSPSolver(data_dict=project_data, solver_mode="baseline", max_backtracks=2000)
    res = solver.solve()
    assert res["status"] == "FEASIBLE"
    assert res["is_optimal"] is False
    assert res["is_complete"] is True
    # Backwards compatibility test
    assert res["status"] == "OPTIMAL_FEASIBLE"


def test_sol01_ortools_cpsat_solver_optimal_certification(project_data):
    """SOL-01: Verify Google OR-Tools CP-SAT solver finds certified mathematical OPTIMAL schedule."""
    cpsat_solver = TimetableCPSATSolver(data_dict=project_data, time_limit_seconds=15.0)
    res = cpsat_solver.solve()
    
    assert res["status"] in ("OPTIMAL", "FEASIBLE")
    assert res["is_complete"] is True
    assert res["assigned_sessions"] == 89
    assert res["objective_value"] is not None
    assert res["solver_algorithm"] == "GOOGLE_ORTOOLS_CPSAT"

    # Validate schedule with Independent Validator
    is_valid, violations = IndependentTimetableValidator.validate(res["schedule_records"], project_data)
    assert is_valid is True, f"CP-SAT schedule failed validator: {violations}"
    assert len(violations) == 0


# =====================================================================
# 2. DATABASE PERSISTENCE, FOREIGN KEYS, SEEDING & INTEGRITY
# =====================================================================

def test_db_foreign_key_enforcement(test_db_mgr):
    """Database Integrity: Verify SQLite foreign key enforcement (PRAGMA foreign_keys = ON)."""
    with pytest.raises(sqlite3.IntegrityError):
        with test_db_mgr.transaction() as conn:
            # Attempt to insert course with non-existent department
            conn.execute(
                """
                INSERT INTO courses (course_id, code, name, department_id, nep_category)
                VALUES ('INVALID_C', 'INV101', 'Invalid Course', 'NON_EXISTENT_DEPT', 'Major Core')
                """
            )


def test_db_transaction_rollback(test_db_mgr):
    """Database Integrity: Verify transaction rolls back all changes on exception."""
    try:
        with test_db_mgr.transaction() as conn:
            conn.execute("INSERT INTO roles (role_id, role_name) VALUES ('TEMP_ROLE', 'Temporary')")
            # Force integrity error
            conn.execute("INSERT INTO courses (course_id, code, name, department_id) VALUES ('BAD', 'B', 'B', 'NON_EXISTENT')")
    except Exception:
        pass

    # Verify TEMP_ROLE was rolled back
    conn = test_db_mgr.get_connection()
    row = conn.execute("SELECT 1 FROM roles WHERE role_id = 'TEMP_ROLE'").fetchone()
    conn.close()
    assert row is None, "Transaction rollback failed: TEMP_ROLE was persisted despite exception!"


def test_db_seeder_idempotency(test_db_mgr):
    """Database Seeder: Verify repeated seeding is idempotent and skips existing records."""
    seeder = DatabaseSeeder(data_dir=os.path.join(base_dir, "data", "synthetic"), db_mgr=test_db_mgr)
    summary2 = seeder.seed_all()
    # All records should be skipped
    assert summary2["courses"]["inserted"] == 0
    assert summary2["courses"]["skipped"] >= 26
    assert summary2["faculty"]["inserted"] == 0
    assert summary2["faculty"]["skipped"] >= 20


# =====================================================================
# 3. OPERATIONS: MAKEUP, ABSENCE, SUBSTITUTES, RESCHEDULING, PUBLISHING
# =====================================================================

def test_makeup_service_rejects_occupied_room(test_db_mgr):
    """Operations: Verify makeup request is rejected if room is occupied by regular lecture."""
    # Ensure parent timetable version exists for foreign key constraint
    with test_db_mgr.transaction() as conn:
        conn.execute(
            """
            INSERT OR IGNORE INTO timetable_versions (version_id, version_number, title, solver_mode, status)
            VALUES ('VER_01', 1, 'Test Master Schedule', 'CSP_BASELINE', 'PUBLISHED')
            """
        )
        conn.execute(
            """
            INSERT OR REPLACE INTO scheduled_sessions 
            (session_id, version_id, course_id, group_id, faculty_id, room_id, session_index, day_of_week, slot_id, status)
            VALUES ('SESS_TEST_01', 'VER_01', 'CS101', 'GRP_CSE_A', 'FAC01', 'ROOM_CR201', 1, 'Wednesday', 3, 'ACTIVE')
            """
        )

    makeup_svc = MakeupSchedulingService(db_mgr=test_db_mgr)
    # Propose makeup class in ROOM_CR201 on Wednesday Slot 3
    is_feasible, conflicts = makeup_svc.evaluate_makeup_feasibility(
        proposed_date="2026-12-02",
        day_of_week="Wednesday",
        slot_id=3,
        room_id="ROOM_CR201",
        faculty_id="FAC02",
        group_id="GRP_CSE_B",
        course_id="CS102"
    )
    assert is_feasible is False
    assert any("Room Conflict: Room ROOM_CR201 is already occupied" in c for c in conflicts)


def test_absence_and_substitute_matcher_workflow(test_db_mgr):
    """Operations: Verify absence marks affected sessions and substitute matcher ranks candidates."""
    # Ensure active session exists on Friday Slot 2 for FAC06
    with test_db_mgr.transaction() as conn:
        conn.execute(
            """
            INSERT OR IGNORE INTO timetable_versions (version_id, version_number, title, solver_mode, status)
            VALUES ('VER_01', 1, 'Test Master Schedule', 'CSP_BASELINE', 'PUBLISHED')
            """
        )
        conn.execute(
            """
            INSERT OR REPLACE INTO scheduled_sessions 
            (session_id, version_id, course_id, group_id, faculty_id, room_id, session_index, day_of_week, slot_id, status)
            VALUES ('SESS_DS_01', 'VER_01', 'DS101', 'GRP_DS_A', 'FAC06', 'ROOM_CR203', 1, 'Friday', 2, 'ACTIVE')
            """
        )

    absence_svc = FacultyAbsenceService(db_mgr=test_db_mgr)
    # Record absence covering Friday (2026-11-27)
    res = absence_svc.record_absence(
        faculty_id="FAC06",
        start_date="2026-11-27",
        end_date="2026-11-27",
        reason="Medical Leave"
    )
    assert res["affected_sessions_count"] >= 1

    # Find substitutes
    matcher = SubstituteMatcher(db_mgr=test_db_mgr)
    candidates = matcher.find_substitutes(
        session_id="SESS_DS_01",
        target_date="2026-11-27",
        day_of_week="Friday",
        slot_id=2
    )
    assert len(candidates) > 0
    # Top candidate should be from Data Science department
    top_cand = candidates[0]
    assert top_cand["faculty_id"] != "FAC06"
    assert top_cand["match_score"] >= 50.0


def test_localized_rescheduler_atomic_rollback(test_db_mgr):
    """Operations: Verify localized rescheduling preserves original session on conflict."""
    with test_db_mgr.transaction() as conn:
        conn.execute(
            """
            INSERT OR IGNORE INTO timetable_versions (version_id, version_number, title, solver_mode, status)
            VALUES ('VER_01', 1, 'Test Master Schedule', 'CSP_BASELINE', 'PUBLISHED')
            """
        )
        conn.execute(
            """
            INSERT OR REPLACE INTO scheduled_sessions 
            (session_id, version_id, course_id, group_id, faculty_id, room_id, session_index, day_of_week, slot_id, status)
            VALUES ('SESS_MOVE_01', 'VER_01', 'CS101', 'GRP_CSE_A', 'FAC01', 'ROOM_CR201', 1, 'Monday', 3, 'ACTIVE'),
                   ('SESS_BLOCKER', 'VER_01', 'MA101', 'GRP_CSE_B', 'FAC10', 'ROOM_CR202', 1, 'Tuesday', 4, 'ACTIVE')
            """
        )

    rescheduler = LocalizedRescheduler(db_mgr=test_db_mgr)
    
    # Attempt move into blocked room -> Must raise ValueError
    with pytest.raises(ValueError) as exc:
        rescheduler.reschedule_session(
            session_id="SESS_MOVE_01",
            new_day="Tuesday",
            new_slot=4,
            new_room_id="ROOM_CR202"
        )
    assert "Cannot reschedule session" in str(exc.value)

    # Verify session SESS_MOVE_01 was NOT modified
    conn = test_db_mgr.get_connection()
    row = conn.execute("SELECT day_of_week, slot_id FROM scheduled_sessions WHERE session_id = 'SESS_MOVE_01'").fetchone()
    conn.close()
    assert row["day_of_week"] == "Monday"
    assert row["slot_id"] == 3


def test_publishing_service_certification_gate(test_db_mgr, project_data):
    """Operations: Publishing gate rejects drafts with hard violations and publishes certified schedules."""
    pub_svc = TimetablePublishingService(db_mgr=test_db_mgr)

    # 1. Draft with intentional room collision
    bad_records = [
        {"curriculum_id": "C1", "course_id": "CS101", "group_id": "GRP_CSE_A", "faculty_id": "FAC01", "room_id": "ROOM_CR201", "day": "Monday", "slot_id": 2, "session_number": 1},
        {"curriculum_id": "C2", "course_id": "MA101", "group_id": "GRP_CSE_B", "faculty_id": "FAC02", "room_id": "ROOM_CR201", "day": "Monday", "slot_id": 2, "session_number": 1}
    ]
    bad_v_id = pub_svc.save_draft_version(bad_records, title="Bad Draft", solver_mode="CSP_BASELINE")
    
    with pytest.raises(ValueError) as exc:
        pub_svc.publish_version(bad_v_id, data_dict=project_data, publisher_user_id="ADMIN")
    assert "Independent validation gate failed" in str(exc.value)


# =====================================================================
# 4. EXPORT SYNCHRONIZATION (CSV, EXCEL, PDF BUFFERS)
# =====================================================================

def test_export_in_memory_buffers_and_differentiation(project_data):
    """Exports: Verify in-memory buffers reflect supplied schedules without disk writes."""
    records_1 = [
        {"variable_id": "V1", "course_id": "CS101", "group_id": "GRP_CSE_A", "faculty_id": "FAC01", "faculty_name": "Dr. Raman", "room_id": "ROOM_CR201", "day": "Monday", "slot_id": 2}
    ]
    records_2 = [
        {"variable_id": "V2", "course_id": "AI201", "group_id": "GRP_AIDS_A", "faculty_id": "FAC04", "faculty_name": "Dr. Nair", "room_id": "ROOM_CR202", "day": "Thursday", "slot_id": 4}
    ]

    csv_buf1 = TimetableExporter.export_to_csv_buffer(records_1)
    csv_buf2 = TimetableExporter.export_to_csv_buffer(records_2)
    assert b"CS101" in csv_buf1.getvalue()
    assert b"AI201" in csv_buf2.getvalue()
    assert csv_buf1.getvalue() != csv_buf2.getvalue()

    excel_buf1 = TimetableExporter.export_to_excel_buffer(records_1)
    excel_buf2 = TimetableExporter.export_to_excel_buffer(records_2)
    assert len(excel_buf1.getvalue()) > 0
    assert len(excel_buf2.getvalue()) > 0

    pdf_buf1 = TimetableExporter.export_to_pdf_buffer(records_1)
    pdf_buf2 = TimetableExporter.export_to_pdf_buffer(records_2)
    assert len(pdf_buf1.getvalue()) > 0
    assert len(pdf_buf2.getvalue()) > 0


# =====================================================================
# 5. AUTHENTICATION & ROLE-BASED ACCESS CONTROL
# =====================================================================

def test_auth_password_hashing_and_verification():
    """Auth: Verify PBKDF2-HMAC-SHA256 password hashing security."""
    pwd = "SecrEtPassword123!"
    h1 = PasswordHasher.hash_password(pwd)
    h2 = PasswordHasher.hash_password(pwd)
    
    # Salts must be random
    assert h1 != h2
    assert PasswordHasher.verify_password(pwd, h1) is True
    assert PasswordHasher.verify_password("WrongPassword", h1) is False
    assert "SecrEtPassword123!" not in h1


def test_auth_service_registration_and_login(test_db_mgr):
    """Auth: Verify user registration, role assignment, active check, and login."""
    auth_svc = AuthService(db_mgr=test_db_mgr)
    u_info = auth_svc.register_user(
        username="prof_raman",
        email="raman@univ.edu",
        password="MyStrongPassword!45",
        first_name="Rajesh",
        last_name="Raman",
        roles=["FACULTY"]
    )
    assert u_info["username"] == "prof_raman"

    # Login with valid password
    login_res = auth_svc.authenticate("prof_raman", "MyStrongPassword!45")
    assert login_res is not None
    assert login_res["username"] == "prof_raman"
    assert "FACULTY" in login_res["roles"]

    # Login with invalid password
    bad_login = auth_svc.authenticate("prof_raman", "IncorrectPassword")
    assert bad_login is None

    # Deactivated user check
    auth_svc.set_user_active_status(u_info["user_id"], is_active=False)
    deactivated_login = auth_svc.authenticate("prof_raman", "MyStrongPassword!45")
    assert deactivated_login is None, "Deactivated user must not authenticate"
