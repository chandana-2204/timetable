# Dataset Documentation & Synthetic Data Disclosure

## Project Context
**Project:** NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System  
**SIH 2025 | Problem Statement:** SIH25091  
**Team:** Gandikota Sai Chandana (12511912) & Inayat (12512142)  
**Subject Code:** K3P25IL  

---

## 1. Data Source Disclosure Statement
> **IMPORTANT DISCLOSURE:** All data in this directory is **100% SYNTHETIC DEMONSTRATION DATA** algorithmically generated using Python with a fixed random seed (`seed = 42`). It does **not** contain real university records, personally identifiable information (PII), or confidential institutional data. The dataset was structured to realistically benchmark multidisciplinary timetable planning under the **National Education Policy (NEP) 2020** curriculum framework.

---

## 2. Master Excel Workbook Architecture
The file `academic_timetable_data.xlsx` is structured into 7 distinct sheets:
1. **Start Here:** Project metadata, data dictionary, ethics disclosure, and summary statistics.
2. **Courses:** 26 courses with categories (DSC, DSE, MDC, AEC, SEC, VAC), credits, room requirements, and hours.
3. **Faculty:** 20 faculty profiles, designations, department affiliations, daily workload limits (4h), and blackout slots.
4. **Rooms:** 14 facilities (auditoriums, lecture halls, computer labs, electronics labs, science labs) with capacity and building details.
5. **Groups & Slots:** 10 student groups across departments with enrolled strength and weekly slot schedules.
6. **Existing Schedule:** Pre-fixed institutional allocations (e.g. Dean's Colloquium, keynote events).
7. **Data Needed:** Validation checklist, constraint rules summary, and NEP-2020 basket guidelines.

---

## 3. CSV File Directory
- `courses.csv`: Course specifications across 6 NEP categories.
- `faculty.csv`: Instructor profiles, workloads, and unavailable windows.
- `rooms.csv`: Room types, capacities (50 to 120 seats), and equipment classifications.
- `student_groups.csv`: Cohort sizes (28 to 55 students) across B.Tech, B.Sc, and NEP baskets.
- `curriculum.csv`: 38 curriculum items defining 89 weekly contact sessions to schedule.
- `existing_schedule.csv`: 5 pre-locked institutional sessions.
- `historical_allocations.csv`: 1,800 historical candidate allocation records for ML classifier training.

---

## 4. Feature Descriptions for ML Training
1. `day_index`: Day of the week (0 = Monday to 4 = Friday).
2. `slot_index`: Period index (1 to 7).
3. `is_peak_slot`: Binary flag (1 for slots 2, 3, 4, 5; 0 otherwise).
4. `is_late_slot`: Binary flag (1 for slot 7: 16:00-17:00).
5. `enrolled_students`: Student group cohort size.
6. `room_capacity`: Maximum seat capacity of the candidate room.
7. `room_capacity_ratio`: Ratio of enrolled students to room capacity.
8. `room_type_match`: Binary flag (1 if facility matches required room type).
9. `is_lab_course`: Binary flag (1 if lab session requiring specialized equipment).
10. `faculty_daily_load`: Current daily teaching hours for the instructor.
11. `faculty_weekly_load`: Cumulative weekly teaching hours.
12. `faculty_available`: Binary flag (1 if instructor is available; 0 if blackout slot).
13. `group_daily_load`: Proxy for current cohort load on that day.
14. `group_has_window_gap`: Binary flag indicating potential idle gap.
15. `historical_collision_score`: Congestion density index.
**Target (`is_conflict`):** 0 = Feasible candidate assignment; 1 = Conflict-prone candidate assignment.

---

## 5. Dataset Validation & Integrity Rules
- Referential integrity enforced across foreign keys.
- Capacity check: `room.capacity >= group.strength`.
- Room suitability check: `room.type == course.required_room_type`.
- Faculty daily workload ceiling: `<= 4` hours/day.
- Fixed allocations: Preserved intact without relocation.
