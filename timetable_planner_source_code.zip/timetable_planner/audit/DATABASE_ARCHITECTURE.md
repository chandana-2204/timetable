# DATABASE ARCHITECTURE SPECIFICATION
## Normalized Relational Architecture for NEP-2020 Timetable Management
**Project Identifier:** SIH 2025 | Problem Statement SIH25091  
**Subject Code:** K3P25IL  
**Audit Stage:** Phase 1 Forensic Audit (Proposed Architecture — Not Yet Migrated)

---

## 1. Existing Storage Assessment & Limitations

Currently, the timetable planner operates under an **unpersisted, in-memory prototype model**:
1. **Source Data:** Static CSV files in `data/synthetic/*.csv` loaded into Pandas DataFrames by `TimetableDataLoader`.
2. **Active Timetable State:** Ephemeral Python dictionaries and lists stored in Streamlit `st.session_state["current_schedule"]`.
3. **Persisted Outputs:** Static pre-generated files in `outputs/master_timetable.*`.

### Critical Vulnerabilities of the Current Storage Model:
- **No Concurrency Protection:** Multiple Streamlit browser sessions share the same Python process. Concurrent solver runs or bookings will result in race conditions, overwriting files or producing disjoint in-memory states.
- **No Referential Integrity:** CSV rows have no database-level foreign key enforcement; an invalid `faculty_id` or `room_id` can be added without database rejection.
- **No Transactional ACID Boundaries:** An update to a session cannot be rolled back atomically if a downstream validation fails.
- **No Audit Trail or Historical Versioning:** Schedules cannot be compared across revisions; deleted sessions are permanently lost.

---

## 2. Entity-Relationship Conceptual Model

```mermaid
erDiagram
    USERS ||--o{ USER_ROLES : has
    ROLES ||--o{ USER_ROLES : assigned_to
    ROLES ||--o{ ROLE_PERMISSIONS : grants
    PERMISSIONS ||--o{ ROLE_PERMISSIONS : defines

    DEPARTMENTS ||--o{ PROGRAMMES : offers
    DEPARTMENTS ||--o{ FACULTY : employs
    DEPARTMENTS ||--o{ ROOMS : manages

    PROGRAMMES ||--o{ SEMESTERS : contains
    SEMESTERS ||--o{ SECTIONS : divides_into
    SECTIONS ||--o{ STUDENTS : enrolls
    STUDENTS ||--o{ ENROLLMENTS : takes
    COURSES ||--o{ ENROLLMENTS : includes

    COURSES ||--o{ CURRICULUM_REQUIREMENTS : specifies
    SECTIONS ||--o{ CURRICULUM_REQUIREMENTS : requires
    FACULTY ||--o{ CURRICULUM_REQUIREMENTS : teaches

    FACULTY ||--o{ FACULTY_AVAILABILITY : declares
    ROOMS ||--o{ ROOM_MAINTENANCE : undergoes

    TIMETABLE_VERSIONS ||--o{ SCHEDULED_SESSIONS : contains
    CURRICULUM_REQUIREMENTS ||--o{ SCHEDULED_SESSIONS : materializes
    ROOMS ||--o{ SCHEDULED_SESSIONS : hosts
    FACULTY ||--o{ SCHEDULED_SESSIONS : conducts

    ROOMS ||--o{ RESOURCE_BOOKINGS : reserves
    USERS ||--o{ RESOURCE_BOOKINGS : requests

    FACULTY ||--o{ FACULTY_ABSENCES : files
    SCHEDULED_SESSIONS ||--o{ SUBSTITUTIONS : requires
    FACULTY ||--o{ SUBSTITUTIONS : substitutes

    SCHEDULED_SESSIONS ||--o{ MAKEUP_REQUESTS : reschedules
    USERS ||--o{ NOTIFICATIONS : receives
    USERS ||--o{ AUDIT_LOGS : performs
```

---

## 3. Normalized Relational Schema (3NF Specification)

### 3.1 Security, Users & Authorization
```sql
-- 1. Users
CREATE TABLE users (
    user_id VARCHAR(36) PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- 2. Roles
CREATE TABLE roles (
    role_id VARCHAR(20) PRIMARY KEY, -- 'ADMIN', 'DEAN', 'HOD', 'FACULTY', 'STUDENT'
    role_name VARCHAR(50) NOT NULL,
    description TEXT
);

-- 3. Permissions
CREATE TABLE permissions (
    permission_id VARCHAR(50) PRIMARY KEY, -- 'TIMETABLE_GENERATE', 'MAKEUP_REQUEST', etc.
    module VARCHAR(30) NOT NULL,
    description TEXT
);

-- 4. User Roles Mapping
CREATE TABLE user_roles (
    user_id VARCHAR(36) REFERENCES users(user_id) ON DELETE CASCADE,
    role_id VARCHAR(20) REFERENCES roles(role_id) ON DELETE CASCADE,
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    PRIMARY KEY (user_id, role_id)
);

-- 5. Role Permissions Mapping
CREATE TABLE role_permissions (
    role_id VARCHAR(20) REFERENCES roles(role_id) ON DELETE CASCADE,
    permission_id VARCHAR(50) REFERENCES permissions(permission_id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);
```

### 3.2 Academic Hierarchy & Student Enrollments
```sql
-- 6. Departments
CREATE TABLE departments (
    department_id VARCHAR(20) PRIMARY KEY, -- 'CSE', 'ECE', 'MATH', etc.
    name VARCHAR(100) NOT NULL,
    code VARCHAR(10) UNIQUE NOT NULL,
    hod_faculty_id VARCHAR(20), -- FK resolved after faculty table
    building VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- 7. Programmes
CREATE TABLE programmes (
    programme_id VARCHAR(20) PRIMARY KEY, -- 'BTECH_CSE', 'BSC_DS', etc.
    department_id VARCHAR(20) REFERENCES departments(department_id) ON DELETE RESTRICT,
    name VARCHAR(100) NOT NULL,
    degree_level VARCHAR(20) NOT NULL, -- 'Undergraduate', 'Postgraduate', 'Doctoral'
    total_semesters INT NOT NULL DEFAULT 8
);

-- 8. Semesters
CREATE TABLE semesters (
    semester_id VARCHAR(20) PRIMARY KEY, -- '2025_AUTUMN_SEM3'
    academic_year VARCHAR(10) NOT NULL, -- '2025-2026'
    term VARCHAR(10) NOT NULL, -- 'Odd', 'Even', 'Summer'
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    is_active BOOLEAN DEFAULT FALSE NOT NULL
);

-- 9. Sections (Student Cohorts)
CREATE TABLE sections (
    section_id VARCHAR(20) PRIMARY KEY, -- 'SEC_CSE_3A', 'SEC_CSE_3B'
    programme_id VARCHAR(20) REFERENCES programmes(programme_id) ON DELETE RESTRICT,
    semester_number INT NOT NULL,
    name VARCHAR(50) NOT NULL,
    capacity INT NOT NULL DEFAULT 60,
    academic_term_id VARCHAR(20) REFERENCES semesters(semester_id) ON DELETE RESTRICT
);

-- 10. Students
CREATE TABLE students (
    student_id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) UNIQUE REFERENCES users(user_id) ON DELETE CASCADE,
    roll_number VARCHAR(20) UNIQUE NOT NULL,
    programme_id VARCHAR(20) REFERENCES programmes(programme_id) ON DELETE RESTRICT,
    section_id VARCHAR(20) REFERENCES sections(section_id) ON DELETE RESTRICT,
    admission_year INT NOT NULL,
    current_semester INT NOT NULL
);

-- 11. Courses (NEP-2020 Compliant)
CREATE TABLE courses (
    course_id VARCHAR(20) PRIMARY KEY, -- 'CS101', 'NEP_MDC01'
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(150) NOT NULL,
    department_id VARCHAR(20) REFERENCES departments(department_id) ON DELETE RESTRICT,
    nep_category VARCHAR(30) NOT NULL, -- 'Major Core (DSC)', 'Minor Elective (DSE)', etc.
    lecture_credits INT NOT NULL DEFAULT 3,
    lab_credits INT NOT NULL DEFAULT 0,
    total_credits INT NOT NULL DEFAULT 3,
    sessions_per_week INT NOT NULL DEFAULT 3,
    required_room_type VARCHAR(30) NOT NULL DEFAULT 'Classroom'
);

-- 12. Student Course Enrollments (Resolves Cross-Department Shared Cohort Clashes!)
CREATE TABLE enrollments (
    enrollment_id VARCHAR(36) PRIMARY KEY,
    student_id VARCHAR(36) REFERENCES students(student_id) ON DELETE CASCADE,
    course_id VARCHAR(20) REFERENCES courses(course_id) ON DELETE RESTRICT,
    semester_id VARCHAR(20) REFERENCES semesters(semester_id) ON DELETE RESTRICT,
    enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status VARCHAR(20) DEFAULT 'ACTIVE' NOT NULL,
    UNIQUE (student_id, course_id, semester_id)
);
```

### 3.3 Faculty, Facilities & Curriculum
```sql
-- 13. Faculty
CREATE TABLE faculty (
    faculty_id VARCHAR(20) PRIMARY KEY, -- 'FAC01'
    user_id VARCHAR(36) UNIQUE REFERENCES users(user_id) ON DELETE CASCADE,
    department_id VARCHAR(20) REFERENCES departments(department_id) ON DELETE RESTRICT,
    designation VARCHAR(50) NOT NULL, -- 'Professor', 'Associate Professor', etc.
    max_hours_per_day INT NOT NULL DEFAULT 4,
    max_hours_per_week INT NOT NULL DEFAULT 16,
    is_active BOOLEAN DEFAULT TRUE NOT NULL
);

-- 14. Faculty Availability (Blackouts & Office Hours)
CREATE TABLE faculty_availability (
    availability_id VARCHAR(36) PRIMARY KEY,
    faculty_id VARCHAR(20) REFERENCES faculty(faculty_id) ON DELETE CASCADE,
    day_of_week VARCHAR(10) NOT NULL, -- 'Monday', 'Tuesday', etc.
    slot_id INT NOT NULL, -- 1 through 7
    is_available BOOLEAN DEFAULT FALSE NOT NULL, -- FALSE = Blackout window
    reason VARCHAR(100),
    UNIQUE (faculty_id, day_of_week, slot_id)
);

-- 15. Rooms & Laboratories
CREATE TABLE rooms (
    room_id VARCHAR(20) PRIMARY KEY, -- 'ROOM_LH101', 'ROOM_CL301'
    name VARCHAR(100) NOT NULL,
    type VARCHAR(30) NOT NULL, -- 'LectureHall', 'Classroom', 'ComputerLab', 'ElectronicsLab', 'ScienceLab'
    capacity INT NOT NULL,
    building VARCHAR(50) NOT NULL,
    floor INT NOT NULL DEFAULT 1,
    is_active BOOLEAN DEFAULT TRUE NOT NULL
);

-- 16. Room Maintenance
CREATE TABLE room_maintenance (
    maintenance_id VARCHAR(36) PRIMARY KEY,
    room_id VARCHAR(20) REFERENCES rooms(room_id) ON DELETE CASCADE,
    day_of_week VARCHAR(10) NOT NULL,
    slot_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    reason TEXT NOT NULL,
    UNIQUE (room_id, day_of_week, slot_id, start_date)
);

-- 17. Curriculum Requirements (Planning Units)
CREATE TABLE curriculum_requirements (
    requirement_id VARCHAR(20) PRIMARY KEY, -- 'CUR_01'
    semester_id VARCHAR(20) REFERENCES semesters(semester_id) ON DELETE RESTRICT,
    section_id VARCHAR(20) REFERENCES sections(section_id) ON DELETE RESTRICT,
    course_id VARCHAR(20) REFERENCES courses(course_id) ON DELETE RESTRICT,
    primary_faculty_id VARCHAR(20) REFERENCES faculty(faculty_id) ON DELETE RESTRICT,
    sessions_per_week INT NOT NULL,
    required_room_type VARCHAR(30) NOT NULL,
    enrolled_strength INT NOT NULL,
    is_fixed BOOLEAN DEFAULT FALSE NOT NULL
);
```

### 3.4 Timetables, Sessions & Resource Bookings
```sql
-- 18. Timetable Versions
CREATE TABLE timetable_versions (
    version_id VARCHAR(36) PRIMARY KEY,
    semester_id VARCHAR(20) REFERENCES semesters(semester_id) ON DELETE RESTRICT,
    version_number INT NOT NULL,
    title VARCHAR(100) NOT NULL,
    solver_mode VARCHAR(30) NOT NULL, -- 'CSP_BASELINE', 'CSP_ML', 'ORTOOLS_CPSAT'
    status VARCHAR(20) NOT NULL, -- 'DRAFT', 'PUBLISHED', 'ARCHIVED'
    quality_score FLOAT,
    hard_violations INT DEFAULT 0 NOT NULL,
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    published_at TIMESTAMP,
    published_by VARCHAR(36) REFERENCES users(user_id)
);

-- 19. Scheduled Sessions
CREATE TABLE scheduled_sessions (
    session_id VARCHAR(36) PRIMARY KEY,
    version_id VARCHAR(36) REFERENCES timetable_versions(version_id) ON DELETE CASCADE,
    requirement_id VARCHAR(20) REFERENCES curriculum_requirements(requirement_id) ON DELETE RESTRICT,
    course_id VARCHAR(20) REFERENCES courses(course_id) ON DELETE RESTRICT,
    section_id VARCHAR(20) REFERENCES sections(section_id) ON DELETE RESTRICT,
    faculty_id VARCHAR(20) REFERENCES faculty(faculty_id) ON DELETE RESTRICT,
    room_id VARCHAR(20) REFERENCES rooms(room_id) ON DELETE RESTRICT,
    session_index INT NOT NULL,
    day_of_week VARCHAR(10) NOT NULL,
    slot_id INT NOT NULL,
    is_locked BOOLEAN DEFAULT FALSE NOT NULL,
    status VARCHAR(20) DEFAULT 'ACTIVE' NOT NULL, -- 'ACTIVE', 'CANCELLED', 'RESCHEDULED'
    -- HARD CONSTRAINT AT DATABASE LEVEL:
    UNIQUE (version_id, day_of_week, slot_id, room_id),
    UNIQUE (version_id, day_of_week, slot_id, faculty_id),
    UNIQUE (version_id, day_of_week, slot_id, section_id)
);

-- 20. Ad-Hoc Resource Bookings (Colloquiums, Guest Lectures, Exams)
CREATE TABLE resource_bookings (
    booking_id VARCHAR(36) PRIMARY KEY,
    room_id VARCHAR(20) REFERENCES rooms(room_id) ON DELETE RESTRICT,
    booked_by_user_id VARCHAR(36) REFERENCES users(user_id) ON DELETE RESTRICT,
    event_name VARCHAR(150) NOT NULL,
    booking_date DATE NOT NULL,
    day_of_week VARCHAR(10) NOT NULL,
    slot_id INT NOT NULL,
    status VARCHAR(20) DEFAULT 'PENDING' NOT NULL, -- 'PENDING', 'APPROVED', 'REJECTED'
    approved_by VARCHAR(36) REFERENCES users(user_id),
    UNIQUE (room_id, booking_date, slot_id)
);
```

### 3.5 Dynamic Operations: Absences, Substitutions, Makeup, Notifications & Audits
```sql
-- 21. Faculty Absences
CREATE TABLE faculty_absences (
    absence_id VARCHAR(36) PRIMARY KEY,
    faculty_id VARCHAR(20) REFERENCES faculty(faculty_id) ON DELETE CASCADE,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    reason VARCHAR(100) NOT NULL,
    status VARCHAR(20) DEFAULT 'PENDING' NOT NULL, -- 'PENDING', 'APPROVED', 'CANCELLED'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- 22. Substitutions
CREATE TABLE substitutions (
    substitution_id VARCHAR(36) PRIMARY KEY,
    session_id VARCHAR(36) REFERENCES scheduled_sessions(session_id) ON DELETE CASCADE,
    original_faculty_id VARCHAR(20) REFERENCES faculty(faculty_id) ON DELETE RESTRICT,
    substitute_faculty_id VARCHAR(20) REFERENCES faculty(faculty_id) ON DELETE RESTRICT,
    date DATE NOT NULL,
    slot_id INT NOT NULL,
    status VARCHAR(20) DEFAULT 'PROPOSED' NOT NULL, -- 'PROPOSED', 'CONFIRMED', 'DECLINED'
    match_score FLOAT, -- Algorithm match score based on competence and availability
    confirmed_at TIMESTAMP
);

-- 23. Makeup Class Requests
CREATE TABLE makeup_requests (
    request_id VARCHAR(36) PRIMARY KEY,
    original_session_id VARCHAR(36) REFERENCES scheduled_sessions(session_id) ON DELETE CASCADE,
    faculty_id VARCHAR(20) REFERENCES faculty(faculty_id) ON DELETE RESTRICT,
    section_id VARCHAR(20) REFERENCES sections(section_id) ON DELETE RESTRICT,
    room_id VARCHAR(20) REFERENCES rooms(room_id) ON DELETE RESTRICT,
    proposed_date DATE NOT NULL,
    day_of_week VARCHAR(10) NOT NULL,
    slot_id INT NOT NULL,
    reason TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'PENDING' NOT NULL, -- 'PENDING', 'APPROVED', 'REJECTED'
    approved_by VARCHAR(36) REFERENCES users(user_id),
    -- Prevent duplicate pending requests for the same room & slot
    UNIQUE (room_id, proposed_date, slot_id)
);

-- 24. Notifications
CREATE TABLE notifications (
    notification_id VARCHAR(36) PRIMARY KEY,
    recipient_user_id VARCHAR(36) REFERENCES users(user_id) ON DELETE CASCADE,
    title VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    category VARCHAR(30) NOT NULL, -- 'TIMETABLE_CHANGE', 'MAKEUP_CLASS', 'SUBSTITUTION'
    is_read BOOLEAN DEFAULT FALSE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- 25. Audit Logs (Immutable Governance Trail)
CREATE TABLE audit_logs (
    log_id BIGINT PRIMARY KEY, -- Auto-incrementing in Postgres/SQLite
    user_id VARCHAR(36) REFERENCES users(user_id),
    action VARCHAR(50) NOT NULL, -- 'GENERATE_SCHEDULE', 'PUBLISH_SCHEDULE', 'APPROVE_MAKEUP'
    entity_name VARCHAR(50) NOT NULL,
    entity_id VARCHAR(36) NOT NULL,
    old_state JSON,
    new_state JSON,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);
```

---

## 4. Concurrency Control & Transaction Guarantees

To prevent race conditions, stale updates, and double-bookings during concurrent usage:

1. **Database-Level Unique Constraints:**
   - As specified in table `scheduled_sessions`:
     ```sql
     UNIQUE (version_id, day_of_week, slot_id, room_id)
     UNIQUE (version_id, day_of_week, slot_id, faculty_id)
     UNIQUE (version_id, day_of_week, slot_id, section_id)
     ```
   - These constraints guarantee that **no two concurrent transactions** can ever insert two classes in the same room, with the same faculty, or with the same section at the same slot in the same published version.
2. **Transaction Isolation Level:**
   - Solver schedule publishing and makeup class approvals must execute under **SERIALIZABLE** transaction isolation.
3. **Optimistic Locking:**
   - `timetable_versions` and `scheduled_sessions` will carry an integer `version_lock` incremented on every update to reject conflicting simultaneous writes.

---

## 5. Non-Destructive Migration Plan (Phase 2 Preparation)

- **Step 1:** Establish SQLite local database engine (`timetable.db`) with SQLAlchemy ORM models matching the 3NF schema above.
- **Step 2:** Write automated seed loader to import existing CSV records (`courses.csv`, `faculty.csv`, `rooms.csv`, `student_groups.csv`, `curriculum.csv`, `existing_schedule.csv`) into the relational tables without altering any existing CSV datasets.
- **Step 3:** Connect Streamlit frontend to read and write through SQLAlchemy sessions with automatic rollback on error.
