# FORENSIC AUDIT REPORT
## University Academic Timetable Planning & Conflict Resolution System
**Project Identifier:** SIH 2025 | Problem Statement SIH25091  
**Subject Code:** K3P25IL | **Academic Track:** NEP-2020 Multidisciplinary Planning  
**Audit Executed On:** 2026-11-24  
**Audit Scope:** Full Source-Level Forensic Audit of Core Backend, Streamlit UI, CSP Solver, ML Classifier, Data Ingestion, Independent Validator, Diagnostics, and Exports.

---

## 1. Executive Summary & Architectural Health Assessment

The existing codebase implements an academic prototype demonstrating **Constraint Satisfaction Problem (CSP) heuristic backtracking search** coupled with a **supervised Random Forest conflict predictor**. It includes a vibrant Streamlit dashboard (`app.py`), synthetic dataset generators (`src/data/generator.py`), and multi-format exporters (CSV, Excel, PDF via ReportLab).

### Overall Architectural Health: **FRAGILE / PROTOTYPE-GRADE**
While the heuristic backtracking CSP core and the supervised ML classifier perform well for static, single-batch scheduling of synthetic cohorts, the platform exhibits **fundamental structural gaps** that prevent it from functioning as a true university-grade timetable management platform:

1. **Zero Database & Persistence Mechanism:** The system relies entirely on ephemeral Streamlit `st.session_state` and flat CSV files. There are no relational tables, foreign key constraints in persistence, database transactions, or concurrency locks.
2. **Critical Validator Logic Defect:** `IndependentTimetableValidator` contains a severe indexing flaw in double-booking tracking that silently misses room collisions, faculty collisions, and group collisions if they occur across different resources in the same time slot.
3. **Cross-Department Shared Cohort Blindness:** Elective student cohorts (e.g. `GRP_MDC_B1`) and departmental sections (`GRP_CSE_A`) are modeled as independent, disjoint string tokens without individual student enrollment tracking. Consequently, the master timetable actively schedules CSE students to regular lectures (`CS101`) and elective classes (`NEP_MDC01`) at the **exact same time** (Monday Slot 2).
4. **False Optimality Claims:** The CSP solver terminates at the very first feasible node and executes zero mathematical objective optimization; however, it hard-codes its output status as `"OPTIMAL_FEASIBLE"`.
5. **Completely Absent Dynamic Operations:** No authentication/RBAC, no faculty absence management, no substitute recommendation engine, no makeup class approval workflows, no dynamic rescheduling, and no notifications exist anywhere in the repository.
6. **OR-Tools CP-SAT is Merely Installed:** `ortools` (v9.15.6755) is present in the Python environment but is completely unreferenced and unused in the entire codebase.
7. **Broken UI-to-Export Synchronization:** Generating a timetable in the Streamlit UI does not persist or update the exported files; the "Reports & Exports" page serves stale, pre-generated files from disk.

---

## 2. Repository Dependency Map

```mermaid
flowchart TD
    subgraph UI_Layer ["Streamlit UI (app.py)"]
        Dashboard["📊 Dashboard"]
        Viewer["📅 Timetable Viewer"]
        Generator["🚀 Timetable Generator"]
        MLAnalytics["📈 ML Analytics"]
        TeamFaculty["👥 Team & Faculty"]
        DataMgmt["⚙️ Data Management"]
        Diagnostics["🔍 Conflict Diagnostics"]
        Benchmarking["⚡ Benchmarking"]
        ReportsExports["📑 Reports & Exports"]
    end

    subgraph State_Storage ["State & In-Memory Storage"]
        SessionState["st.session_state<br/>('current_schedule', 'schedule_records')"]
        CacheResource["@st.cache_resource<br/>(DataLoader, Classifier)"]
    end

    subgraph Core_Engine ["Scheduling & Diagnostic Engines"]
        CSPSolver["TimetableCSPSolver<br/>(src/csp/solver.py)"]
        Constraints["ScheduleState & SoftConstraintEvaluator<br/>(src/csp/constraints.py)"]
        Heuristics["MRV + Degree + LCV + ForwardChecker<br/>(src/csp/heuristics.py)"]
        MLClassifier["TimetableConflictClassifier<br/>(src/ml/classifier.py)"]
        Validator["IndependentTimetableValidator<br/>(src/validation/validator.py)"]
        Explainer["ConflictExplainer<br/>(src/diagnostics/explainer.py)"]
        Benchmarker["TimetableBenchmarker<br/>(src/benchmarking/benchmark.py)"]
    end

    subgraph Data_Export_Layer ["Data Ingestion & Export Layer"]
        DataLoader["TimetableDataLoader<br/>(src/data/loader.py)"]
        DataGen["generate_all_datasets<br/>(src/data/generator.py)"]
        Exporter["TimetableExporter<br/>(src/exports/exporter.py)"]
        DiskCSV["data/synthetic/*.csv"]
        DiskExcel["data/synthetic/*.xlsx"]
        DiskOutputs["outputs/master_timetable.*"]
    end

    %% UI Connections
    Generator -->|Configures & Triggers| CSPSolver
    Generator -->|Validates Solution| Validator
    Generator -->|Writes Solution| SessionState
    Viewer -->|Reads Solution Records| SessionState
    Dashboard -->|Reads Summary Metrics| DataLoader
    Dashboard -->|Reads Active Schedule| SessionState
    MLAnalytics -->|Reads Metrics & Feature Importances| MLClassifier
    DataMgmt -->|Direct Pandas Display| DiskCSV
    Diagnostics -->|Runs Infeasible Benchmark| CSPSolver
    Diagnostics -->|Diagnoses Unassigned| Explainer
    Benchmarking -->|Runs Head-to-Head| Benchmarker
    ReportsExports -->|Reads STALE files from disk!| DiskOutputs

    %% Backend Connections
    CSPSolver --> Constraints
    CSPSolver --> Heuristics
    CSPSolver --> MLClassifier
    Heuristics --> Constraints
    Benchmarker --> CSPSolver
    DataLoader --> DiskCSV
    DataLoader --> DiskExcel
    DataGen --> DiskCSV
    Exporter --> DiskOutputs
```

---

## 3. Detailed Feature-by-Feature Forensic Verification

| # | Major Feature Scope | Implementation Status | Verdict & Technical Defect Description |
|---|---|---|---|
| **1** | **Authentication & Authorization** | **Missing** | Zero authentication or RBAC code. No login view, password hashing, session tokens, or role-based route guards exist. |
| **2** | **Faculty Management** | **Partially Implemented** | Read-only dataframe displayed in `app.py` (`⚙️ Data Management`, `👥 Team & Faculty`). No CRUD forms, no availability window editor, no persistence. |
| **3** | **Department Management** | **Missing** | Departments exist only as raw strings (`CSE`, `ECE`, etc.) in faculty and group records. No department entity, HOD assignment, or department-level isolation. |
| **4** | **Student & Section Management** | **Partially Implemented** | Only high-level student groups (`student_groups.csv`) exist. Individual student entity, section dividing, student course enrollment, and cross-basket tracking are **Missing**. |
| **5** | **Room & Resource Management** | **Partially Implemented** | Static room catalog read-only table in UI. Centralized room reservation, ad-hoc booking, and maintenance blackouts are **Missing**. |
| **6** | **Timetable Generation** | **Fully Implemented & Verified** | Generates 100% complete timetable allocations for the 89 weekly synthetic sessions using heuristic search. |
| **7** | **CSP Backtracking Engine** | **Fully Implemented & Verified** | Recursive search with node counting, backtrack limiting, constraint checking, and timeout guards in `src/csp/solver.py`. |
| **8** | **MRV, Degree, LCV & Forward Checking** | **Fully Implemented & Verified** | Variable ordering (MRV tied with degree), value ordering (LCV), and forward checking domain pruning with wipeout detection in `src/csp/heuristics.py`. |
| **9** | **ML Classifier Integration** | **Fully Implemented & Verified** | Random Forest model trained on 15 features (98% accuracy); batch inference prioritizes low-conflict values during search. |
| **10** | **Independent Validation Gate** | **Implemented Incorrectly / Broken** | `IndependentTimetableValidator.validate()` has a defective collision tracking dictionary that misses double bookings of rooms, faculty, and groups. |
| **11** | **Conflict Diagnostics** | **Fully Implemented & Verified** | `ConflictExplainer.diagnose_unassigned_sessions` provides explainable root causes and actionable recommendations for overconstrained variables. |
| **12** | **Makeup Classes** | **Missing** | Zero code, database tables, or UI controls exist for makeup class requests, feasibility checking, or approvals. |
| **13** | **Faculty Absence Handling** | **Missing** | Zero code exists to record faculty sick leave, emergency absence, or cancellation of assigned timetable slots. |
| **14** | **Substitute Matching** | **Missing** | Zero logic exists to query alternative faculty matching department, subject expertise, and availability. |
| **15** | **Dynamic Timetable Rescheduling** | **Missing** | No mechanism exists to alter an active session without wiping the entire schedule and re-running the global solver. |
| **16** | **Notifications System** | **Missing** | Zero push, email, SMS, or in-app notification infrastructure exists. |
| **17** | **Multi-Role Timetable Synchronization** | **Partially Implemented** | UI only visualizes student groups. Room view is missing. Faculty view is present only in static Excel exports. Dynamic synchronization is missing. |
| **18** | **Excel, CSV & PDF Exports** | **Partially Implemented / Broken Connection** | `TimetableExporter` generates valid files, but UI buttons serve stale static files on disk rather than the actively generated schedule in session state. |
| **19** | **Data Persistence & ACID Storage** | **Missing** | Entirely reliant on ephemeral memory and static CSVs. No relational database, no ACID transactions, no concurrency locks. |
| **20** | **Multi-Department Scheduling** | **Implemented Incorrectly** | Schedules all departments in a single flat batch, but fails to prevent clashes for students attending shared cross-department multidisciplinary electives. |

---

## 4. Critical Scheduling Forensic Investigations

### 4.1 Cross-Department Shared Cohort Conflicts (Empirical Proof)
- **Investigation Objective:** Verify whether students in shared multidisciplinary elective cohorts experience timetable collisions with departmental core classes.
- **Root Cause:** In `curriculum.csv`, `GRP_CSE_A` has core curriculum (`CUR_01` to `CUR_07`), while `GRP_MDC_B1` (Multidisciplinary Cohort B1 for CSE/ECE students) has curriculum `CUR_35`. In `src/csp/constraints.py`, `state.group_occupancy` indexes solely on `(day, slot, var.group_id)`. Because `'GRP_CSE_A' != 'GRP_MDC_B1'`, the state treats them as independent cohorts.
- **Empirical Evidence in Production Schedule (`outputs/master_timetable.csv`):**
  ```csv
  # Session 1: GRP_CSE_A
  CUR_01_S1,CUR_01,CS101,Programming Fundamentals,GRP_CSE_A,B.Tech CSE - Section A,FAC01,Dr. Rajesh Raman,1,Monday,2,Slot 2,ROOM_LH101
  # Session 2: GRP_MDC_B1
  CUR_35_S1,CUR_35,NEP_MDC01,Digital Humanities & Culture,GRP_MDC_B1,Multidisciplinary Cohort B1 (CSE/ECE),FAC16,Dr. Gautam Sen,1,Monday,2,Slot 2,ROOM_CR201
  ```
- **Finding:** On **Monday, Slot 2 (10:00 - 11:00)**, CSE Section A students are scheduled for `CS101` in Auditorium `ROOM_LH101` AND `NEP_MDC01` in `ROOM_CR201`. Students cannot be in two places at once. The system falsely claims 0 hard clashes.

### 4.2 Independent Validator Flaw (Source-Level Proof)
- **Investigation Objective:** Trace `IndependentTimetableValidator.validate()` in `src/validation/validator.py` lines 40-83.
- **Defective Code Trace:**
  ```python
  fac_occupancy = {} # (day, slot) -> faculty_id
  room_occupancy = {} # (day, slot) -> room_id
  group_occupancy = {} # (day, slot) -> group_id

  # Room double booking check:
  if time_key in room_occupancy:
      if room_occupancy[time_key] == rid:
          violations.append(f"Hard Constraint 2 Violated: Room {rid} double-booked on {day} Slot {slot}.")
  else:
      room_occupancy[time_key] = rid
  ```
- **Flaw Mechanism:** `room_occupancy` uses `time_key = (day, slot)` as the dictionary key! In an academic institution, 14 rooms can be occupied during Monday Slot 1. When the first room (`ROOM_CR201`) is checked, `room_occupancy[(Monday, 1)] = 'ROOM_CR201'`. When a second room (`ROOM_CR202`) is checked, `time_key in room_occupancy` is True, but `room_occupancy[(Monday, 1)] == 'ROOM_CR202'` evaluates to `False`, so nothing happens and `room_occupancy` is NOT updated! If a third session also books `ROOM_CR202` (a fatal double-booking!), the check evaluates `'ROOM_CR201' == 'ROOM_CR202'`, which is `False`! The validator **silently ignores the double booking**.
- **Audit Test Execution:** Executed in `audit/test_audit_forensics.py::test_audit_room_collision_validator_flaw` and confirmed.

### 4.3 Google OR-Tools Investigation
- **Investigation Objective:** Verify whether Google OR-Tools CP-SAT is utilized.
- **Findings:**
  - `ortools` version `9.15.6755` is installed in the local virtual environment.
  - Repository-wide grep for `ortools`, `cp_model`, and `CpModel` returns **zero occurrences** across all Python, markdown, JSON, and script files.
  - The solver is exclusively a pure Python backtracking CSP algorithm.
  - The project documentation and claims regarding a "Hybrid CSP + OR-Tools solver" are unsupported by the codebase.

### 4.4 Solver Optimality vs. Feasibility
- **Investigation Objective:** Evaluate the mathematical optimization status of `TimetableCSPSolver.solve()`.
- **Finding:**
  - `TimetableCSPSolver._backtrack()` returns `True` at the very first assignment where all variables are assigned.
  - It does not evaluate, compare, or minimize the objective function (`SoftConstraintEvaluator.calculate_penalties`) during branch exploration.
  - It does not perform branch-and-bound optimization.
  - It returns `status = "OPTIMAL_FEASIBLE"`.
  - **Verdict:** Calling this solution "OPTIMAL" is mathematically invalid. It is a **first-feasible satisfaction assignment**, not an optimal solution.

### 4.5 UI-to-Export Synchronization Defect
- **Investigation Objective:** Trace export generation upon solver execution in `app.py`.
- **Finding:**
  - Lines 855-871 run `solver.solve()` and update `st.session_state["schedule_records"]`.
  - Lines 1024-1060 serve download buttons by reading `outputs/master_timetable_multisheet.xlsx` and `outputs/master_timetable.csv` directly from disk.
  - Solver execution never writes to disk.
  - The downloaded files are static artifacts created during previous batch runs and do not reflect any user modifications or new solver runs.

---

## 5. Comprehensive Forensic Findings Matrix

| Finding ID | Feature Area | Severity | File & Line Reference | Defect & Root Cause | Required Correction |
|---|---|---|---|---|---|
| **SEC-01** | Authentication & RBAC | **P0 (Critical)** | `app.py:1-1073` | Zero auth/session security. All pages and data are publicly accessible to anyone running the web app. | Implement secure authentication with hashed credentials, JWT/session management, and role-based permissions (Admin, Dean, HOD, Faculty, Student). |
| **VAL-01** | Schedule Validation | **P0 (Critical)** | `src/validation/validator.py:40-83` | `room_occupancy`, `fac_occupancy`, and `group_occupancy` key solely on `(day, slot)`, failing to index multiple concurrent resources and missing double bookings. | Change occupancy trackers to sets of 3-tuples: `(day, slot, room_id)`, `(day, slot, faculty_id)`, and `(day, slot, group_id)`. |
| **CSP-01** | Cross-Dept Scheduling | **P0 (Critical)** | `src/csp/constraints.py:65,94` | Cohort overlap between departmental sections and multidisciplinary baskets is unmodeled, causing simultaneous class assignments for the same students. | Introduce student enrollment mapping to resolve group overlap conflicts in CSP domain generation and state checking. |
| **DAT-01** | Data Persistence & ACID | **P0 (Critical)** | Entire repository | Absence of relational database, transactions, or file locks. Concurrency races will corrupt data. | Establish normalized relational database (SQLite/PostgreSQL) with foreign keys, unique constraints, and transaction boundaries. |
| **DYN-01** | Faculty Absence & Substitution | **P1 (High)** | Missing module | No mechanism to handle faculty leaves, match available substitutes based on subject competence, or reassign sessions. | Create Absence and Substitution models, matching algorithms, and approval workflows. |
| **DYN-02** | Makeup Class Scheduling | **P1 (High)** | Missing module | No mechanism to book makeup lectures while guaranteeing simultaneous room, section, and faculty availability. | Implement makeup request booking engine with joint (room, faculty, section) conflict validation. |
| **SOL-01** | Solver Optimization Status | **P1 (High)** | `src/csp/solver.py:191-192` | Solver labels first-found feasible state as `OPTIMAL_FEASIBLE` without running an objective optimization algorithm. | Implement Google OR-Tools CP-SAT or branch-and-bound optimization to minimize soft penalties with a true optimality certificate. |
| **SYNC-01** | UI Export Synchronization | **P1 (High)** | `app.py:1024-1060` | Streamlit download buttons serve static files from disk rather than the active session schedule. | Connect export download buttons directly to in-memory active schedule via `TimetableExporter` byte buffers. |
| **UI-01** | Room & Faculty Timetables | **P2 (Medium)** | `app.py:683-776` | Timetable viewer only displays Student Cohorts. Faculty and Room grid viewers are missing from UI. | Add Faculty and Room filter dropdowns to render synchronized multi-role weekly timetable grids. |
| **NOTIF-01** | Notifications Engine | **P2 (Medium)** | Missing module | No event-driven notifications for schedule updates, room shifts, or cancellations. | Implement notification dispatch service for timetable change alerts. |

---

## 6. Test Suite Execution Summary

### 6.1 Baseline Existing Test Suite (`tests/test_timetable_system.py`)
- **Execution Command:** `python -m pytest tests/test_timetable_system.py -v`
- **Result:** **10 Passed in 16.32s**
- **Forensic Assessment:** The existing test suite verifies that the CSP solver runs to completion on synthetic data and that the ML model achieves $>85\%$ accuracy. However, existing tests **did not test** for cross-department shared cohort collisions, the validator's room tracking dictionary bug, or export synchronization.

### 6.2 Forensic Audit Test Suite (`audit/test_audit_forensics.py`)
- **Execution Command:** `python -m pytest audit/test_audit_forensics.py -v -s`
- **Result:** **9 Passed in 3.86s** (All forensic assertions confirmed)
- **Key Empirical Verifications:**
  1. Confirmed that `IndependentTimetableValidator` misses double-booking of `ROOM_CR202` when another room was previously indexed in that slot.
  2. Confirmed that `ScheduleState` permits concurrent scheduling of `GRP_CSE_A` and `GRP_MDC_B1` (CSE students double-booked on Monday Slot 2).
  3. Confirmed that `solver.solve()` leaves disk exports completely un-synchronized and stale.
  4. Confirmed that no dynamic makeup class insertion or absence handling logic exists.
