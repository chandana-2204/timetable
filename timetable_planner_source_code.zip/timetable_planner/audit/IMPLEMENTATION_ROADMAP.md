# IMPLEMENTATION ROADMAP
## University Academic Timetable Planning & Conflict Resolution System
**Problem Statement:** SIH25091 | **Academic Track:** NEP-2020 Multidisciplinary Planning  
**Audit Stage:** Phase 1 Forensic Audit Deliverable

---

## 1. Guiding Principle & Implementation Strategy

```
AUDIT (Phase 1) ➔ REPAIR (Phase 2) ➔ COMPLETE (Phase 3) ➔ SCALE (Phase 4 & 5)
Evidence before assumptions. Preservation before replacement. Correctness before new features.
```

The roadmap prioritizes fixing critical data integrity flaws and security holes before adding dynamic features, ensuring no breaking changes occur to the existing working prototype.

---

## 2. Prioritization Matrix (P0 / P1 / P2 / P3)

```mermaid
flowchart TD
    subgraph P0_Blockers ["P0 — Critical Correctness & Security Blockers"]
        P0_1["Fix Validator Collision Tracking Flaw (VAL-01)"]
        P0_2["Fix Cross-Department Cohort Overlap Clashes (CSP-01)"]
        P0_3["Implement Normalized Persistence & Transactions (DAT-01)"]
        P0_4["Implement Authentication & Role-Based Access Control (SEC-01)"]
    end

    subgraph P1_High ["P1 — Core Architecture & Dynamic Operations"]
        P1_1["Integrate Google OR-Tools CP-SAT Solver (SOL-01)"]
        P1_2["Faculty Absence & Substitute Matching Engine (DYN-01)"]
        P1_3["Makeup Class Joint-Feasibility Booking Engine (DYN-02)"]
        P1_4["Synchronize Streamlit UI Exports with In-Memory State (SYNC-01)"]
        P1_5["Synchronized Multi-Role Timetable Views (UI-01)"]
    end

    subgraph P2_Medium ["P2 — Operational Workflows & Governance"]
        P2_1["Event-Driven Notification System (NOTIF-01)"]
        P2_2["Immutable Audit Logging Trail (AUD-01)"]
        P2_3["Interactive Faculty Availability Scheduler (UI-02)"]
        P2_4["Resource & Room Maintenance Blackouts (RES-01)"]
    end

    subgraph P3_Scale ["P3 — Advanced Optimization & Production Readiness"]
        P3_1["PostgreSQL Production Migration & Docker Containerization"]
        P3_2["Automated Conflict-Directed Backjumping (CBJ)"]
        P3_3["iCalendar (.ics) Subscriptions & Mobile Sync"]
    end

    P0_Blockers --> P1_High
    P1_High --> P2_Medium
    P2_Medium --> P3_Scale
```

---

## 3. Phased Execution Roadmap

### Phase 2: Core Stabilization & Forensic Repair (Immediate Next Turn)
**Goal:** Fix the broken validator, eliminate cross-department shared cohort clashes, connect active exports, and introduce non-destructive SQLite persistence with basic authentication.

| Milestone ID | Task Description | Target Files | Priority | Acceptance Criteria |
|---|---|---|---|---|
| **M2.1** | **Repair Validator Tracking Logic:** Replace `(day, slot)` dictionary keying with 3-tuple sets `(day, slot, resource_id)` to catch 100% of double bookings across concurrent rooms, faculty, and student groups. | `src/validation/validator.py` | **P0** | Validator catches the previously missed `ROOM_CR202` double-booking and all multi-resource collisions. |
| **M2.2** | **Cross-Department Shared Cohort Conflict Resolution:** Model shared student memberships between parent sections (e.g. `GRP_CSE_A`) and elective cohorts (`GRP_MDC_B1`). Block timeslots in CSP domains when parent section is scheduled. | `src/csp/constraints.py`, `src/csp/solver.py` | **P0** | No student in `GRP_CSE_A` has an overlapping session with `GRP_MDC_B1` in the master schedule. |
| **M2.3** | **Export Stream Synchronization:** Connect Streamlit download buttons to in-memory active schedule state via `io.BytesIO` rather than serving stale disk files. | `app.py`, `src/exports/exporter.py` | **P1** | Downloaded Excel, CSV, and PDF immediately reflect any newly generated or modified timetable. |
| **M2.4** | **Room & Faculty Timetable Views:** Add Faculty and Room filter dropdowns in the Streamlit `📅 Timetable Viewer` to visualize schedules from all 3 perspectives. | `app.py` | **P1** | Users can inspect weekly grids by Student Group, Faculty Member, or Classroom/Lab. |
| **M2.5** | **Non-Destructive Database Foundation & Authentication:** Implement SQLAlchemy models for the 25 normalized tables (SQLite dev file `timetable.db`) and seed from existing CSVs without modifying production files. Add basic login view in Streamlit. | `src/database/models.py`, `src/database/session.py`, `src/auth/service.py`, `app.py` | **P0** | System starts with login screen; seeded data matches CSV data; all CRUD operations persist. |

### Phase 3: Hybrid Solver & Dynamic Operations
**Goal:** Implement true Google OR-Tools CP-SAT mathematical optimization, faculty absence handling, substitute recommendation, and makeup class booking.

| Milestone ID | Task Description | Target Files | Priority | Acceptance Criteria |
|---|---|---|---|---|
| **M3.1** | **Google OR-Tools CP-SAT Solver Integration:** Formulate integer linear programming CP-SAT model minimizing soft penalties (gaps, consecutive hours, capacity waste) with certified optimality status. | `src/solver/ortools_solver.py`, `src/csp/solver.py`, `app.py` | **P1** | CP-SAT solver finds certified optimal schedule minimizing soft penalty objective; UI allows toggling between CSP and CP-SAT. |
| **M3.2** | **Faculty Absence & Substitute Matching Engine:** Implement absence filing and algorithm to score available substitute instructors by department match, subject competence, and daily load. | `src/operations/absence_service.py`, `src/operations/substitute_matcher.py`, `app.py` | **P1** | Absence marks sessions for substitute coverage; engine lists top-3 conflict-free substitute faculty. |
| **M3.3** | **Makeup Class Scheduling Engine:** Implement makeup request workflow verifying joint availability across section, faculty, and room before granting approval. | `src/operations/makeup_service.py`, `app.py` | **P1** | Makeup session cannot be approved if room or section has an existing class in that slot. |
| **M3.4** | **Localized Dynamic Rescheduler:** Allow moving an individual session to an alternate open slot without running a full re-generation. | `src/operations/rescheduler.py`, `app.py` | **P1** | Drag/select reschedule updates the session and verifies zero newly introduced hard clashes. |

### Phase 4: Governance, Notifications & Institutional Workflows
**Goal:** In-app notification center, audit logging, interactive availability pickers, and room maintenance controls.

| Milestone ID | Task Description | Target Files | Priority | Acceptance Criteria |
|---|---|---|---|---|
| **M4.1** | **Event-Driven Notifications:** Dispatch alerts for schedule updates, room shifts, and makeup approvals. | `src/notifications/service.py`, `app.py` | **P2** | In-app notification bell shows real-time unread alerts. |
| **M4.2** | **Immutable Audit Log:** Record every administrative change with timestamp, user ID, and state diff. | `src/database/audit.py`, `app.py` | **P2** | Audit log tab displays complete historical revision timeline. |
| **M4.3** | **Interactive Blackout Picker:** Visual weekly grid for faculty to click and set unavailable hours. | `app.py` | **P2** | Click-to-toggle availability slots updates database and feeds directly into solver. |
| **M4.4** | **Room Maintenance Blackouts:** Schedule facility maintenance windows that automatically block timetable allocation. | `app.py`, `src/operations/facility_service.py` | **P2** | Maintenance slots are unavailable for timetable sessions or makeup classes. |

### Phase 5: Production Hardening & Multi-Institution Scaling
**Goal:** PostgreSQL deployment, Docker containerization, and REST API.

| Milestone ID | Task Description | Target Files | Priority | Acceptance Criteria |
|---|---|---|---|---|
| **M5.1** | **PostgreSQL & Docker:** Dockerfile and Docker Compose setup with PostgreSQL and Alembic migrations. | `Dockerfile`, `docker-compose.yml`, `alembic/` | **P3** | Containerized deployment passes complete integration suite. |
| **M5.2** | **FastAPI Backend:** Expose RESTful endpoints for timetable generation, student schedules, and mobile clients. | `src/api/` | **P3** | API documentation generated via OpenAPI/Swagger. |
| **M5.3** | **iCalendar (.ics) Export:** Generate iCal feeds for students and faculty to synchronize with Google Calendar / Outlook. | `src/exports/ical_exporter.py` | **P3** | Timetable imports cleanly into standard calendar applications. |

---

## 4. Exact Files to be Modified / Created in Phase 2

### Files to Modify:
1. `src/validation/validator.py`: Repair the dictionary keying bug in `IndependentTimetableValidator.validate()`.
2. `src/csp/constraints.py`: Extend `ScheduleState` to track student cohort intersections and enforce shared cohort non-overlap.
3. `src/csp/solver.py`: Pass student cohort intersection mappings into domain generation and state validation.
4. `src/exports/exporter.py`: Add `export_to_excel_buffer()` and `export_to_csv_buffer()` returning `io.BytesIO` streams.
5. `app.py`:
   - Replace disk file downloads with in-memory active schedule buffers.
   - Add Faculty and Room timetable grid viewers.
   - Integrate authentication login form and session state route guard.

### Files to Create (Inside `src/`):
6. `src/database/models.py`: SQLAlchemy 3NF models matching `audit/DATABASE_ARCHITECTURE.md`.
7. `src/database/session.py`: Database engine and session factory with SQLite default (`timetable.db`).
8. `src/database/seeder.py`: Non-destructive seeder populating SQLite tables from existing CSV files.
9. `src/auth/service.py`: Authentication service with password hashing and role verification.
