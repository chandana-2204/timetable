"""
Forensic Audit Test Suite for NEP-2020 Timetable System
SIH25091 Forensic Repository Audit

Non-destructive tests verifying:
1. Faculty collision
2. Room collision
3. Section collision
4. Cross-department shared-resource collision
5. Makeup versus regular lecture collision
6. Duplicate booking
7. Concurrent booking
8. Capacity violations
9. Faculty workload violations
10. Timetable synchronization
"""

import os
import sys
import pytest
import pandas as pd
import numpy as np

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from src.data.loader import TimetableDataLoader, DataValidator
from src.csp.constraints import ScheduleState, SessionVariable, AssignmentValue
from src.csp.solver import TimetableCSPSolver
from src.validation.validator import IndependentTimetableValidator
from src.diagnostics.explainer import ConflictExplainer
from src.exports.exporter import TimetableExporter

@pytest.fixture(scope="module")
def project_data():
    loader = TimetableDataLoader(data_dir=os.path.join(BASE_DIR, "data", "synthetic"))
    return loader.load_all()

def test_audit_faculty_collision_solver_and_validator(project_data):
    """Audit Test 1: Verify faculty collision behavior in both ScheduleState and Validator."""
    state = ScheduleState(faculty_max_daily={"FAC01": 4})
    var1 = SessionVariable(
        var_id="V1", curriculum_id="C1", course_id="CS101", course_name="CS",
        group_id="GRP_CSE_A", faculty_id="FAC01", faculty_name="Dr. Raman",
        session_index=1, required_room_type="Classroom", enrolled_count=40, is_lab=False
    )
    var2 = SessionVariable(
        var_id="V2", curriculum_id="C2", course_id="CS201", course_name="DSA",
        group_id="GRP_CSE_B", faculty_id="FAC01", faculty_name="Dr. Raman",
        session_index=1, required_room_type="Classroom", enrolled_count=40, is_lab=False
    )
    val = AssignmentValue(day="Monday", slot_id=2, room_id="ROOM_CR201")
    state.assign(var1, val)
    is_valid, reason = state.is_valid_assignment(var2, val)
    assert not is_valid, "ScheduleState should reject faculty collision"

    # Now audit IndependentTimetableValidator on double-booking
    records = [
        {
            "variable_id": "V1", "curriculum_id": "CUR_01", "course_id": "CS101",
            "group_id": "GRP_CSE_A", "faculty_id": "FAC01", "day": "Monday",
            "slot_id": 2, "room_id": "ROOM_CR201", "room_type": "Classroom",
            "enrolled_strength": 40
        },
        {
            "variable_id": "V2", "curriculum_id": "CUR_08", "course_id": "CS101",
            "group_id": "GRP_CSE_B", "faculty_id": "FAC01", "day": "Monday",
            "slot_id": 2, "room_id": "ROOM_CR202", "room_type": "Classroom",
            "enrolled_strength": 40
        }
    ]
    is_val_passed, val_errs = IndependentTimetableValidator.validate(records, project_data)
    # Check if validator caught the faculty double booking
    assert not is_val_passed, f"Validator failed to catch faculty collision! Errors: {val_errs}"
    assert any("Faculty FAC01 double-booked" in e for e in val_errs)

def test_audit_room_collision_validator_flaw(project_data):
    """
    Audit Test 2: Uncover the critical dictionary-key bug in IndependentTimetableValidator.
    In validator.py:
        if time_key in room_occupancy:
            if room_occupancy[time_key] == rid:
                violations.append(...)
        else:
            room_occupancy[time_key] = rid
    When a third session double-books a room other than the first room in that slot,
    does the validator detect it?
    """
    records = [
        # Session 1: Room CR201 at Monday Slot 1
        {
            "variable_id": "V1", "curriculum_id": "CUR_01", "course_id": "CS101",
            "group_id": "GRP_CSE_A", "faculty_id": "FAC01", "day": "Monday",
            "slot_id": 1, "room_id": "ROOM_CR201", "room_type": "Classroom",
            "enrolled_strength": 40
        },
        # Session 2: Room CR202 at Monday Slot 1 (different room)
        {
            "variable_id": "V2", "curriculum_id": "CUR_08", "course_id": "CS101",
            "group_id": "GRP_CSE_B", "faculty_id": "FAC02", "day": "Monday",
            "slot_id": 1, "room_id": "ROOM_CR202", "room_type": "Classroom",
            "enrolled_strength": 40
        },
        # Session 3: Room CR202 at Monday Slot 1 (DOUBLE BOOKING of CR202 with Session 2!)
        {
            "variable_id": "V3", "curriculum_id": "CUR_15", "course_id": "AI201",
            "group_id": "GRP_AIDS_A", "faculty_id": "FAC04", "day": "Monday",
            "slot_id": 1, "room_id": "ROOM_CR202", "room_type": "Classroom",
            "enrolled_strength": 40
        }
    ]
    is_val_passed, val_errs = IndependentTimetableValidator.validate(records, project_data)
    
    # Forensic check: Due to room_occupancy[(Monday, 1)] == 'ROOM_CR201',
    # Session 3 compares 'ROOM_CR201' == 'ROOM_CR202', which is FALSE!
    # Therefore, the double-booking of ROOM_CR202 is SILENTLY MISSED!
    has_room_clash = any("Room ROOM_CR202 double-booked" in e for e in val_errs)
    print(f"\n[FORENSIC EVIDENCE] Validator Passed: {is_val_passed}, Errors: {val_errs}")
    # Document this defect: The validator BUG allows ROOM_CR202 double-booking to pass silently!
    assert not has_room_clash, "Expected the validator bug to manifest: ROOM_CR202 clash is silently missed!"

def test_audit_section_collision(project_data):
    """Audit Test 3: Check section double booking."""
    state = ScheduleState(faculty_max_daily={"FAC01": 4, "FAC02": 4})
    var1 = SessionVariable(
        var_id="V1", curriculum_id="C1", course_id="CS101", course_name="CS",
        group_id="GRP_CSE_A", faculty_id="FAC01", faculty_name="Dr. Raman",
        session_index=1, required_room_type="Classroom", enrolled_count=40, is_lab=False
    )
    var2 = SessionVariable(
        var_id="V2", curriculum_id="C2", course_id="MA101", course_name="Math",
        group_id="GRP_CSE_A", faculty_id="FAC02", faculty_name="Dr. Patel",
        session_index=1, required_room_type="Classroom", enrolled_count=40, is_lab=False
    )
    val1 = AssignmentValue(day="Monday", slot_id=1, room_id="ROOM_CR201")
    val2 = AssignmentValue(day="Monday", slot_id=1, room_id="ROOM_CR202")
    state.assign(var1, val1)
    is_valid, reason = state.is_valid_assignment(var2, val2)
    assert not is_valid
    assert "Student Group GRP_CSE_A has concurrent session" in reason

def test_audit_cross_department_shared_cohort_collision(project_data):
    """
    Audit Test 4: Cross-department shared-resource collision.
    Students from GRP_CSE_A attend both CSE courses and GRP_MDC_B1 (Multidisciplinary Cohort B1).
    Test whether the current system detects or prevents scheduling GRP_CSE_A and GRP_MDC_B1 simultaneously.
    """
    state = ScheduleState(faculty_max_daily={"FAC01": 4, "FAC16": 4})
    var_cse = SessionVariable(
        var_id="CUR_01_S1", curriculum_id="CUR_01", course_id="CS101", course_name="Programming",
        group_id="GRP_CSE_A", faculty_id="FAC01", faculty_name="Dr. Raman",
        session_index=1, required_room_type="LectureHall", enrolled_count=55, is_lab=False
    )
    var_mdc = SessionVariable(
        var_id="CUR_35_S1", curriculum_id="CUR_35", course_id="NEP_MDC01", course_name="Digital Humanities",
        group_id="GRP_MDC_B1", faculty_id="FAC16", faculty_name="Dr. Sen",
        session_index=1, required_room_type="Classroom", enrolled_count=35, is_lab=False
    )
    val_cse = AssignmentValue(day="Monday", slot_id=2, room_id="ROOM_LH101")
    val_mdc = AssignmentValue(day="Monday", slot_id=2, room_id="ROOM_CR201")
    
    state.assign(var_cse, val_cse)
    # The state check ONLY checks group_id == 'GRP_MDC_B1'
    is_valid, reason = state.is_valid_assignment(var_mdc, val_mdc)
    
    # Forensic finding: is_valid is True because student overlap is NOT modeled!
    assert is_valid is True, "Confirmed: State treats shared cohorts as disjoint, allowing concurrent clash!"

def test_audit_makeup_versus_regular_lecture_collision():
    """
    Audit Test 5: Test makeup class collision.
    There is no makeup scheduling API in the system.
    If a makeup session is introduced into the existing schedule state, does the system support dynamic insertion?
    """
    state = ScheduleState(faculty_max_daily={"FAC01": 4})
    regular_var = SessionVariable(
        var_id="REG_01", curriculum_id="C1", course_id="CS101", course_name="CS",
        group_id="GRP_CSE_A", faculty_id="FAC01", faculty_name="Dr. Raman",
        session_index=1, required_room_type="Classroom", enrolled_count=40, is_lab=False
    )
    reg_val = AssignmentValue(day="Wednesday", slot_id=3, room_id="ROOM_CR201")
    state.assign(regular_var, reg_val)

    # Candidate makeup class for different course wanting same room
    makeup_var = SessionVariable(
        var_id="MAKEUP_01", curriculum_id="C2", course_id="MA101", course_name="Math Makeup",
        group_id="GRP_CSE_B", faculty_id="FAC10", faculty_name="Dr. Patel",
        session_index=1, required_room_type="Classroom", enrolled_count=40, is_lab=False
    )
    # Candidate makeup requesting same room and slot
    is_valid, reason = state.is_valid_assignment(makeup_var, reg_val)
    assert not is_valid
    assert "Room ROOM_CR201 already booked" in reason

def test_audit_duplicate_booking(project_data):
    """Audit Test 6: Verify duplicate booking of same session variable."""
    state = ScheduleState(faculty_max_daily={"FAC01": 4})
    var = SessionVariable(
        var_id="V1", curriculum_id="C1", course_id="CS101", course_name="CS",
        group_id="GRP_CSE_A", faculty_id="FAC01", faculty_name="Dr. Raman",
        session_index=1, required_room_type="Classroom", enrolled_count=40, is_lab=False
    )
    val = AssignmentValue(day="Tuesday", slot_id=2, room_id="ROOM_CR201")
    state.assign(var, val)
    # Attempt assigning exact same variable to same slot again
    is_valid, reason = state.is_valid_assignment(var, val)
    assert not is_valid, "State must reject duplicate assignment of already assigned faculty/group/room"

def test_audit_capacity_violations(project_data):
    """Audit Test 7: Verify capacity violations."""
    # Room CR205 has capacity 50. Group GRP_CSE_A has strength 55.
    rooms_df = project_data["rooms"].set_index("room_id")
    assert rooms_df.loc["ROOM_CR205", "capacity"] == 50
    
    records = [
        {
            "variable_id": "V1", "curriculum_id": "CUR_01", "course_id": "CS101",
            "group_id": "GRP_CSE_A", "faculty_id": "FAC01", "day": "Monday",
            "slot_id": 1, "room_id": "ROOM_CR205", "room_type": "Classroom",
            "enrolled_strength": 55 # Exceeds capacity 50
        }
    ]
    is_val_passed, val_errs = IndependentTimetableValidator.validate(records, project_data)
    assert not is_val_passed
    assert any("Room ROOM_CR205 cap=50 < enrolled=55" in e for e in val_errs)

def test_audit_faculty_workload_violations(project_data):
    """Audit Test 8: Verify faculty workload limit > 4 hours."""
    state = ScheduleState(faculty_max_daily={"FAC01": 4})
    var = SessionVariable(
        var_id="V1", curriculum_id="C1", course_id="CS101", course_name="CS",
        group_id="GRP_CSE_A", faculty_id="FAC01", faculty_name="Dr. Raman",
        session_index=1, required_room_type="Classroom", enrolled_count=40, is_lab=False
    )
    for s in [1, 2, 3, 4]:
        v = SessionVariable(
            var_id=f"V{s}", curriculum_id="C1", course_id="CS101", course_name="CS",
            group_id=f"GRP_{s}", faculty_id="FAC01", faculty_name="Dr. Raman",
            session_index=s, required_room_type="Classroom", enrolled_count=40, is_lab=False
        )
        val = AssignmentValue(day="Monday", slot_id=s, room_id=f"ROOM_CR20{s}")
        state.assign(v, val)
        
    v5 = SessionVariable(
        var_id="V5", curriculum_id="C1", course_id="CS101", course_name="CS",
        group_id="GRP_5", faculty_id="FAC01", faculty_name="Dr. Raman",
        session_index=5, required_room_type="Classroom", enrolled_count=40, is_lab=False
    )
    val5 = AssignmentValue(day="Monday", slot_id=5, room_id="ROOM_CR205")
    is_valid, reason = state.is_valid_assignment(v5, val5)
    assert not is_valid
    assert "exceeds daily workload limit" in reason

def test_audit_timetable_synchronization_stale_exports():
    """
    Audit Test 9: Verify timetable synchronization defect.
    When a new schedule is generated, does outputs/master_timetable.csv get updated?
    """
    out_csv = os.path.join(BASE_DIR, "outputs", "master_timetable.csv")
    assert os.path.exists(out_csv)
    mtime_before = os.path.getmtime(out_csv)
    
    loader = TimetableDataLoader(data_dir=os.path.join(BASE_DIR, "data", "synthetic"))
    data_dict = loader.load_all()
    solver = TimetableCSPSolver(data_dict=data_dict, solver_mode="baseline", max_backtracks=500)
    res = solver.solve()
    
    # Solver execution only produces memory dict res["schedule_records"].
    # It does NOT write to disk automatically.
    mtime_after = os.path.getmtime(out_csv)
    assert mtime_before == mtime_after, "Confirmed: Solver solve() does not persist to disk, leaving exports stale!"
