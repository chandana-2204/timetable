"""Solver package init"""
from .ortools_solver import TimetableCPSATSolver
