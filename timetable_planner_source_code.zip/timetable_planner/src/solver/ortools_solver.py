"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Google OR-Tools CP-SAT Solver Integration with Certified Mathematical Optimality (SOL-01)

SIH 2025 | Problem Statement SIH25091
"""

import time
import pandas as pd
from typing import Dict, Any, List, Optional
from ortools.sat.python import cp_model
from ..csp.constraints import AssignmentValue
from ..csp.overlap import CohortOverlapManager

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
SLOTS = [1, 2, 3, 4, 5, 6, 7]

class TimetableCPSATSolver:
    """
    Certified Constraint Programming (CP-SAT) Solver for University Timetable Scheduling.
    Formulates timetable as a boolean integer linear program and minimizes soft penalties
    with mathematical proof of optimality (or certified feasible bounds).
    """

    def __init__(
        self,
        data_dict: Dict[str, pd.DataFrame],
        time_limit_seconds: float = 25.0,
        overlap_manager: Optional[CohortOverlapManager] = None,
        late_slot_weight: int = 15,
        capacity_waste_weight: int = 1
    ):
        self.data_dict = data_dict
        self.time_limit_seconds = time_limit_seconds
        self.late_slot_weight = late_slot_weight
        self.capacity_waste_weight = capacity_waste_weight

        # Cohort overlap manager
        if overlap_manager is None and "cohort_memberships" in data_dict and data_dict["cohort_memberships"] is not None:
            raw_mem = data_dict["cohort_memberships"]
            if isinstance(raw_mem, CohortOverlapManager):
                overlap_manager = raw_mem
            elif isinstance(raw_mem, dict):
                overlap_manager = CohortOverlapManager.from_dict(raw_mem)
        self.overlap_manager = overlap_manager

        self.model = cp_model.CpModel()
        self.solver = cp_model.CpSolver()
        self.solver.parameters.max_time_in_seconds = float(time_limit_seconds)
        self.solver.parameters.num_search_workers = 4

    def solve(self) -> Dict[str, Any]:
        """Formulate and solve CP-SAT model. Reports true mathematical optimality status."""
        start_time = time.time()
        
        curriculum_df = self.data_dict["curriculum"]
        courses_df = self.data_dict["courses"].set_index("course_id")
        rooms_df = self.data_dict["rooms"]
        faculty_df = self.data_dict["faculty"].set_index("faculty_id")
        groups_df = self.data_dict["student_groups"].set_index("group_id")
        existing_df = self.data_dict.get("existing_schedule")

        # 1. Build lookup tables
        rooms_dict = {}
        for _, r in rooms_df.iterrows():
            rooms_dict[r["room_id"]] = {
                "name": r.get("name", r["room_id"]),
                "type": r["type"],
                "capacity": int(r["capacity"]),
                "building": r.get("building", "")
            }

        # 2. Extract Session Units
        sessions = []
        for _, row in curriculum_df.iterrows():
            cid = row["course_id"]
            gid = row["group_id"]
            fid = row["faculty_id"]
            c_info = courses_df.loc[cid] if cid in courses_df.index else {}
            c_name = c_info.get("name", cid) if hasattr(c_info, "get") else cid
            req_type = row["required_room_type"]
            enrolled = int(groups_df.loc[gid, "strength"]) if gid in groups_df.index else 50
            is_lab = ("Lab" in req_type) or ("lab" in str(cid).lower())

            # Candidate rooms matching type & capacity
            suitable_rooms = [
                rid for rid, rdata in rooms_dict.items()
                if rdata["type"] == req_type and rdata["capacity"] >= enrolled
            ]

            unavail_str = str(faculty_df.loc[fid, "unavailable_slots"]) if fid in faculty_df.index else ""
            unavail_set = set(unavail_str.split(";")) if unavail_str and unavail_str != "nan" else set()

            for s_idx in range(1, int(row["sessions_per_week"]) + 1):
                sessions.append({
                    "session_id": f"{row['curriculum_id']}_S{s_idx}",
                    "curriculum_id": row["curriculum_id"],
                    "course_id": cid,
                    "course_name": c_name,
                    "group_id": gid,
                    "faculty_id": fid,
                    "faculty_name": str(faculty_df.loc[fid, "name"]) if fid in faculty_df.index else fid,
                    "session_index": s_idx,
                    "room_type": req_type,
                    "enrolled_strength": enrolled,
                    "is_lab": is_lab,
                    "suitable_rooms": suitable_rooms,
                    "unavail_slots": unavail_set
                })

        # 3. Create CP-SAT Boolean Decision Variables x[i, day, slot, room]
        # x_vars[(s_idx, day, slot, room_id)] = BoolVar
        x_vars = {}
        session_candidates = {}

        for s_i, sess in enumerate(sessions):
            session_candidates[s_i] = []
            for day in DAYS:
                for slot in SLOTS:
                    if f"{day}:{slot}" in sess["unavail_slots"]:
                        continue # Faculty blackout
                    for rid in sess["suitable_rooms"]:
                        var = self.model.NewBoolVar(f"x_{s_i}_{day}_{slot}_{rid}")
                        x_vars[(s_i, day, slot, rid)] = var
                        session_candidates[s_i].append((day, slot, rid, var))

        # Constraint 1: Exactly one assignment per session
        for s_i, cand_list in session_candidates.items():
            if not cand_list:
                return {
                    "status": "INFEASIBLE",
                    "solver_algorithm": "GOOGLE_ORTOOLS_CPSAT",
                    "is_optimal": False,
                    "is_complete": False,
                    "message": f"Session {sessions[s_i]['session_id']} has 0 valid domain values."
                }
            self.model.AddExactlyOne([v for (_, _, _, v) in cand_list])

        # Constraint 2: Room collision (at most 1 class per room per day & slot)
        for rid in rooms_dict.keys():
            for day in DAYS:
                for slot in SLOTS:
                    room_slot_vars = [
                        var for (s_i, d, s, r), var in x_vars.items()
                        if d == day and s == slot and r == rid
                    ]
                    if len(room_slot_vars) > 1:
                        self.model.AddAtMostOne(room_slot_vars)

        # Constraint 3: Faculty collision (at most 1 class per faculty per day & slot)
        fac_ids = faculty_df.index.unique()
        for fid in fac_ids:
            for day in DAYS:
                for slot in SLOTS:
                    fac_slot_vars = [
                        var for (s_i, d, s, r), var in x_vars.items()
                        if d == day and s == slot and sessions[s_i]["faculty_id"] == fid
                    ]
                    if len(fac_slot_vars) > 1:
                        self.model.AddAtMostOne(fac_slot_vars)

        # Constraint 4: Student group & Overlapping cohort collision
        for day in DAYS:
            for slot in SLOTS:
                if self.overlap_manager is not None:
                    # Enforce that no two conflicting cohorts can be active at the same time
                    all_active_groups = list(groups_df.index)
                    for i_g, g1 in enumerate(all_active_groups):
                        conflicts = self.overlap_manager.get_conflicting_cohorts(g1)
                        # All vars belonging to any conflicting cohort at this day & slot
                        cohort_vars = [
                            var for (s_i, d, s, r), var in x_vars.items()
                            if d == day and s == slot and sessions[s_i]["group_id"] in conflicts
                        ]
                        if len(cohort_vars) > 1:
                            self.model.AddAtMostOne(cohort_vars)
                else:
                    # Standard group disjoint check
                    for gid in groups_df.index:
                        grp_slot_vars = [
                            var for (s_i, d, s, r), var in x_vars.items()
                            if d == day and s == slot and sessions[s_i]["group_id"] == gid
                        ]
                        if len(grp_slot_vars) > 1:
                            self.model.AddAtMostOne(grp_slot_vars)

        # Constraint 5: Faculty daily workload limit
        for fid in fac_ids:
            max_daily = int(faculty_df.loc[fid].get("max_hours_per_day", 4))
            for day in DAYS:
                daily_vars = [
                    var for (s_i, d, s, r), var in x_vars.items()
                    if d == day and sessions[s_i]["faculty_id"] == fid
                ]
                if daily_vars:
                    self.model.Add(sum(daily_vars) <= max_daily)

        # Constraint 6: Lock pre-fixed allocations
        if existing_df is not None and not existing_df.empty:
            for _, fix in existing_df.iterrows():
                target_cid = fix["course_id"]
                target_gid = fix["group_id"]
                target_fid = fix["faculty_id"]
                t_day, t_slot, t_rid = fix["day"], int(fix["slot_id"]), fix["room_id"]
                # Match session
                for s_i, sess in enumerate(sessions):
                    if (sess["course_id"] == target_cid and sess["group_id"] == target_gid and 
                        sess["faculty_id"] == target_fid):
                        if (s_i, t_day, t_slot, t_rid) in x_vars:
                            self.model.Add(x_vars[(s_i, t_day, t_slot, t_rid)] == 1)
                        break

        # 4. Objective Function: Minimize Soft Constraint Penalties
        objective_terms = []
        for (s_i, day, slot, rid), var in x_vars.items():
            sess = sessions[s_i]
            # Late slot penalty (Slot 7)
            if slot == 7:
                objective_terms.append(var * self.late_slot_weight)
            # Capacity waste penalty
            waste = max(0, rooms_dict[rid]["capacity"] - sess["enrolled_strength"])
            if waste > 0:
                objective_terms.append(var * (waste // 5))

        if objective_terms:
            self.model.Minimize(sum(objective_terms))

        # 5. Execute CP-SAT Solve
        status = self.solver.Solve(self.model)
        elapsed = time.time() - start_time

        # Status mapping with true mathematical semantics
        if status == cp_model.OPTIMAL:
            res_status = "OPTIMAL"
            is_optimal = True
        elif status == cp_model.FEASIBLE:
            res_status = "FEASIBLE"
            is_optimal = False
        elif status == cp_model.INFEASIBLE:
            res_status = "INFEASIBLE"
            is_optimal = False
        elif status == cp_model.MODEL_INVALID:
            res_status = "UNKNOWN"
            is_optimal = False
        else:
            res_status = "TIMEOUT"
            is_optimal = False

        records = []
        if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            for (s_i, day, slot, rid), var in x_vars.items():
                if self.solver.Value(var) == 1:
                    sess = sessions[s_i]
                    records.append({
                        "variable_id": sess["session_id"],
                        "curriculum_id": sess["curriculum_id"],
                        "course_id": sess["course_id"],
                        "course_name": sess["course_name"],
                        "group_id": sess["group_id"],
                        "group_name": groups_df.loc[sess["group_id"], "name"] if sess["group_id"] in groups_df.index else sess["group_id"],
                        "faculty_id": sess["faculty_id"],
                        "faculty_name": sess["faculty_name"],
                        "session_number": sess["session_index"],
                        "day": day,
                        "slot_id": slot,
                        "time_label": f"Slot {slot}",
                        "room_id": rid,
                        "room_name": rooms_dict[rid]["name"],
                        "room_type": rooms_dict[rid]["type"],
                        "enrolled_strength": sess["enrolled_strength"],
                        "room_capacity": rooms_dict[rid]["capacity"],
                        "is_fixed": False
                    })

        return {
            "status": res_status,
            "solver_algorithm": "GOOGLE_ORTOOLS_CPSAT",
            "is_optimal": is_optimal,
            "is_complete": len(records) == len(sessions),
            "objective_value": self.solver.ObjectiveValue() if status in (cp_model.OPTIMAL, cp_model.FEASIBLE) else None,
            "best_bound": self.solver.BestObjectiveBound() if status in (cp_model.OPTIMAL, cp_model.FEASIBLE) else None,
            "assigned_sessions": len(records),
            "total_sessions": len(sessions),
            "completeness_pct": round((len(records) / len(sessions)) * 100.0, 2) if sessions else 0.0,
            "execution_time_seconds": round(elapsed, 4),
            "wall_time": self.solver.WallTime(),
            "schedule_records": records
        }
