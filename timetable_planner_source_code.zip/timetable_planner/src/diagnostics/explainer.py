"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Explainable Conflict Diagnostics & Recommendation Engine

SIH 2025 | Problem Statement SIH25091
Team: Gandikota Sai Chandana (12511912) & Inayat (12512142)
Subject Code: K3P25IL
"""

import pandas as pd
from typing import Dict, List, Tuple, Any, Optional
from ..csp.constraints import SessionVariable, AssignmentValue

class ConflictExplainer:
    """
    Analyzes partial schedules or unassigned variables to identify the root cause
    of infeasibility, isolating specific hard-constraint bottlenecks and suggesting actionable remedies.
    """

    @staticmethod
    def diagnose_unassigned_sessions(
        unassigned_vars: List[SessionVariable],
        data_dict: Dict[str, pd.DataFrame],
        rooms_dict: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """
        Produce human-readable diagnostic explanations for why specific sessions could not be scheduled.
        Identifies:
        1. Faculty availability exhaustion
        2. Room capacity shortfall
        3. Room type unavailability
        4. Faculty daily workload ceiling
        5. Group slot exhaustion
        """
        diagnostics = []
        faculty_df = data_dict["faculty"]
        
        for var in unassigned_vars:
            # Check domain size
            if len(var.domain) == 0:
                # Initial domain was empty
                # Check room type match
                matching_rooms = [
                    rid for rid, rdata in rooms_dict.items()
                    if rdata["type"] == var.required_room_type
                ]
                if not matching_rooms:
                    diagnostics.append({
                        "variable_id": var.var_id,
                        "course_id": var.course_id,
                        "course_name": var.course_name,
                        "group_id": var.group_id,
                        "faculty_id": var.faculty_id,
                        "constraint_category": "HARD_CONSTRAINT",
                        "constraint_violated": "Room Type Unavailability",
                        "root_cause": f"No rooms exist with required room type '{var.required_room_type}' for course {var.course_name}.",
                        "severity": "CRITICAL",
                        "actionable_recommendation": f"Designate at least one facility as '{var.required_room_type}' or reclassify course requirements."
                    })
                    continue

                # Check capacity
                capacity_fitting_rooms = [
                    rid for rid in matching_rooms
                    if rooms_dict[rid]["capacity"] >= var.enrolled_count
                ]
                if not capacity_fitting_rooms:
                    max_cap = max(rooms_dict[rid]["capacity"] for rid in matching_rooms)
                    diagnostics.append({
                        "variable_id": var.var_id,
                        "course_id": var.course_id,
                        "course_name": var.course_name,
                        "group_id": var.group_id,
                        "faculty_id": var.faculty_id,
                        "constraint_category": "HARD_CONSTRAINT",
                        "constraint_violated": "Room Capacity Shortfall",
                        "root_cause": f"Enrolled student strength ({var.enrolled_count}) exceeds capacity of all '{var.required_room_type}' rooms (Max capacity available: {max_cap}).",
                        "severity": "HIGH",
                        "actionable_recommendation": f"Split group {var.group_id} into smaller tutorial batches or assign to Sir C.V. Raman Auditorium (ROOM_LH101)."
                    })
                    continue

                # Check faculty availability
                fac_row = faculty_df[faculty_df["faculty_id"] == var.faculty_id]
                unavail = str(fac_row["unavailable_slots"].iloc[0]) if not fac_row.empty else ""
                unavail_count = len(unavail.split(";")) if unavail and unavail != "nan" else 0
                if unavail_count >= 25:
                    diagnostics.append({
                        "variable_id": var.var_id,
                        "course_id": var.course_id,
                        "course_name": var.course_name,
                        "group_id": var.group_id,
                        "faculty_id": var.faculty_id,
                        "constraint_category": "HARD_CONSTRAINT",
                        "constraint_violated": "Faculty Availability Exhaustion",
                        "root_cause": f"Faculty {var.faculty_name} ({var.faculty_id}) has excessive blackout windows ({unavail_count} unavailable slots).",
                        "severity": "CRITICAL",
                        "actionable_recommendation": f"Adjust availability profile for {var.faculty_name} or co-assign a secondary instructor."
                    })
                    continue

            # If domain had values but search failed to assign
            diagnostics.append({
                "variable_id": var.var_id,
                "course_id": var.course_id,
                "course_name": var.course_name,
                "group_id": var.group_id,
                "faculty_id": var.faculty_id,
                "constraint_category": "HARD_CONSTRAINT",
                "constraint_violated": "Concurrent Resource Saturation",
                "root_cause": f"All {len(var.domain)} candidate slots for {var.course_name} collided with prior group assignments or faculty daily limits.",
                "severity": "MEDIUM",
                "actionable_recommendation": "Increase solver backtrack limit or distribute elective sessions into afternoon slots (Slots 5-6)."
            })

        return diagnostics

    @staticmethod
    def audit_full_schedule(
        scheduled_records: List[Dict[str, Any]],
        data_dict: Dict[str, pd.DataFrame]
    ) -> Dict[str, Any]:
        """
        Independent comprehensive audit of a timetable.
        Verifies all 10 hard constraints and computes soft constraint statistics.
        """
        hard_violations = []
        soft_observations = []
        
        # 1. Faculty collisions
        fac_time_map: Dict[Tuple[str, int], List[Dict[str, Any]]] = {}
        # 2. Room collisions
        room_time_map: Dict[Tuple[str, int], List[Dict[str, Any]]] = {}
        # 3. Group collisions
        group_time_map: Dict[Tuple[str, int], List[Dict[str, Any]]] = {}
        # 4. Faculty daily workload
        fac_daily_hours: Dict[Tuple[str, str], int] = {}

        for rec in scheduled_records:
            t_key = (rec["day"], rec["slot_id"])
            fac_time_map.setdefault(t_key, []).append(rec)
            room_time_map.setdefault(t_key, []).append(rec)
            group_time_map.setdefault(t_key, []).append(rec)

            fd_key = (rec["faculty_id"], rec["day"])
            fac_daily_hours[fd_key] = fac_daily_hours.get(fd_key, 0) + 1

        # Check faculty collisions
        for (day, slot), items in fac_time_map.items():
            facs = [x["faculty_id"] for x in items]
            if len(facs) != len(set(facs)):
                seen = set()
                for x in items:
                    if x["faculty_id"] in seen:
                        hard_violations.append({
                            "type": "FACULTY_COLLISION",
                            "description": f"Faculty {x['faculty_id']} scheduled multiple times on {day} Slot {slot}.",
                            "item": x
                        })
                    seen.add(x["faculty_id"])

        # Check room collisions
        for (day, slot), items in room_time_map.items():
            rooms = [x["room_id"] for x in items]
            if len(rooms) != len(set(rooms)):
                seen = set()
                for x in items:
                    if x["room_id"] in seen:
                        hard_violations.append({
                            "type": "ROOM_COLLISION",
                            "description": f"Room {x['room_id']} booked concurrently on {day} Slot {slot}.",
                            "item": x
                        })
                    seen.add(x["room_id"])

        # Check group collisions
        for (day, slot), items in group_time_map.items():
            groups = [x["group_id"] for x in items]
            if len(groups) != len(set(groups)):
                seen = set()
                for x in items:
                    if x["group_id"] in seen:
                        hard_violations.append({
                            "type": "GROUP_COLLISION",
                            "description": f"Group {x['group_id']} scheduled concurrently on {day} Slot {slot}.",
                            "item": x
                        })
                    seen.add(x["group_id"])

        # Check faculty daily limits (> 4 hours)
        for (fid, day), hrs in fac_daily_hours.items():
            if hrs > 4:
                hard_violations.append({
                    "type": "FACULTY_WORKLOAD_EXCEEDED",
                    "description": f"Faculty {fid} assigned {hrs} hours on {day} (limit: 4h).",
                    "faculty_id": fid,
                    "day": day,
                    "hours": hrs
                })

        # Check room capacity & type
        rooms_df = data_dict["rooms"].set_index("room_id")
        for rec in scheduled_records:
            rid = rec["room_id"]
            if rid in rooms_df.index:
                r_cap = rooms_df.loc[rid, "capacity"]
                r_type = rooms_df.loc[rid, "type"]
                if rec["enrolled_strength"] > r_cap:
                    hard_violations.append({
                        "type": "CAPACITY_VIOLATION",
                        "description": f"Room {rid} (capacity {r_cap}) cannot hold {rec['enrolled_strength']} students of {rec['group_id']}.",
                        "item": rec
                    })
                if rec["room_type"] != r_type:
                    hard_violations.append({
                        "type": "ROOM_TYPE_MISMATCH",
                        "description": f"Course requires {rec['room_type']} but assigned to {r_type} ({rid}).",
                        "item": rec
                    })

        is_valid = (len(hard_violations) == 0)
        return {
            "is_valid": is_valid,
            "total_hard_violations": len(hard_violations),
            "hard_violations": hard_violations,
            "audit_status": "PASSED (Zero Hard Violations)" if is_valid else "FAILED (Hard Violations Detected)"
        }
