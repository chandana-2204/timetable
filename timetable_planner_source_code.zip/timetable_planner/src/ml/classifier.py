"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Lightweight Supervised ML Classifier Module (Conflict Prediction & Prioritization)

SIH 2025 | Problem Statement SIH25091
Team: Gandikota Sai Chandana (12511912) & Inayat (12512142)
Subject Code: K3P25IL
"""

import os
import json
import joblib
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Any, Optional
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, roc_auc_score

FEATURE_COLUMNS = [
    "day_index",
    "slot_index",
    "is_peak_slot",
    "is_late_slot",
    "enrolled_students",
    "room_capacity",
    "room_capacity_ratio",
    "room_type_match",
    "is_lab_course",
    "faculty_daily_load",
    "faculty_weekly_load",
    "faculty_available",
    "group_daily_load",
    "group_has_window_gap",
    "historical_collision_score"
]

TARGET_COLUMN = "is_conflict"

class TimetableConflictClassifier:
    """
    Lightweight supervised machine learning classifier for predicting conflict probability
    of candidate timetable allocations during CSP heuristic search.
    """
    
    def __init__(self, model_dir: Optional[str] = None):
        if model_dir is None:
            base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
            model_dir = os.path.join(base_dir, "models")
        self.model_dir = model_dir
        os.makedirs(self.model_dir, exist_ok=True)
        
        self.model: Optional[RandomForestClassifier] = None
        self.metrics: Dict[str, Any] = {}
        self.feature_importances: Dict[str, float] = {}
        self.model_path = os.path.join(self.model_dir, "conflict_predictor.joblib")
        self.metrics_path = os.path.join(self.model_dir, "model_metrics.json")
        
    def train(self, data_df: pd.DataFrame, random_state: int = 42) -> Dict[str, Any]:
        """
        Train the classifier on synthetic historical scheduling records
        using a leakage-safe 80/20 train-test split.
        """
        X = data_df[FEATURE_COLUMNS]
        y = data_df[TARGET_COLUMN]
        
        # Leakage-safe 80/20 stratified split
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.20, random_state=random_state, stratify=y
        )
        
        # Train lightweight Random Forest Classifier
        clf = RandomForestClassifier(
            n_estimators=100,
            max_depth=8,
            min_samples_split=4,
            random_state=random_state,
            n_jobs=-1
        )
        clf.fit(X_train, y_train)
        self.model = clf
        
        # Test set predictions
        y_pred = clf.predict(X_test)
        y_prob = clf.predict_proba(X_test)[:, 1]
        
        acc = accuracy_score(y_test, y_pred)
        prec = precision_score(y_test, y_pred, zero_division=0)
        rec = recall_score(y_test, y_pred, zero_division=0)
        f1 = f1_score(y_test, y_pred, zero_division=0)
        roc_auc = roc_auc_score(y_test, y_prob)
        cm = confusion_matrix(y_test, y_pred).tolist()
        
        # Feature importances
        importances = clf.feature_importances_
        feat_imp = {feat: round(float(imp), 4) for feat, imp in zip(FEATURE_COLUMNS, importances)}
        # Sort descending
        feat_imp = dict(sorted(feat_imp.items(), key=lambda item: item[1], reverse=True))
        
        self.metrics = {
            "model_type": "RandomForestClassifier",
            "train_samples": len(X_train),
            "test_samples": len(X_test),
            "accuracy": round(float(acc), 4),
            "precision": round(float(prec), 4),
            "recall": round(float(rec), 4),
            "f1_score": round(float(f1), 4),
            "roc_auc": round(float(roc_auc), 4),
            "confusion_matrix": cm,
            "class_distribution": {
                "feasible_samples": int((y == 0).sum()),
                "conflict_samples": int((y == 1).sum()),
                "conflict_rate": round(float(y.mean()), 4)
            },
            "feature_importances": feat_imp
        }
        self.feature_importances = feat_imp
        
        # Persist model and metrics
        joblib.dump(self.model, self.model_path)
        with open(self.metrics_path, "w") as f:
            json.dump(self.metrics, f, indent=2)
            
        print(f"[ML Classifier] Model successfully trained: Accuracy={acc:.4f}, F1={f1:.4f}, AUC={roc_auc:.4f}")
        return self.metrics

    def load_model(self) -> bool:
        """Load trained model and metrics from disk if available."""
        if os.path.exists(self.model_path) and os.path.exists(self.metrics_path):
            self.model = joblib.load(self.model_path)
            with open(self.metrics_path, "r") as f:
                self.metrics = json.load(f)
            self.feature_importances = self.metrics.get("feature_importances", {})
            return True
        return False

    def batch_predict_conflict_probabilities(
        self,
        var: Any,
        candidates: List[Any],
        state: Any,
        rooms_dict: Dict[str, Any],
        faculty_df: pd.DataFrame
    ) -> List[float]:
        """
        Vectorized high-performance inference for candidate (day, slot, room) assignments.
        Builds a numpy feature matrix and predicts in one vectorized call.
        """
        if not candidates:
            return []
            
        if self.model is None:
            if not self.load_model():
                return [0.5] * len(candidates)
                
        days_map = {"Monday": 0, "Tuesday": 1, "Wednesday": 2, "Thursday": 3, "Friday": 4}
        
        fac_row = faculty_df[faculty_df["faculty_id"] == var.faculty_id]
        unavail = str(fac_row["unavailable_slots"].iloc[0]) if not fac_row.empty else ""
        unavail_set = set(unavail.split(";")) if unavail and unavail != "nan" else set()
        
        # Precompute faculty current load
        fac_weekly_load = sum(
            state.faculty_daily_hours.get((var.faculty_id, d), 0) for d in days_map.keys()
        )
        
        # Precompute current assignment count for group load proxy
        grp_daily_load_base = sum(
            1 for (_, k_val) in state.assignments.items()
            if hasattr(k_val, 'day')
        ) // 4
        
        matrix = np.zeros((len(candidates), len(FEATURE_COLUMNS)), dtype=np.float32)
        
        for i, val in enumerate(candidates):
            day_idx = days_map.get(val.day, 0)
            slot_idx = val.slot_id
            is_peak = 1.0 if slot_idx in [2, 3, 4, 5] else 0.0
            is_late = 1.0 if slot_idx == 7 else 0.0
            
            room_info = rooms_dict.get(val.room_id, {})
            room_cap = float(room_info.get("capacity", 50))
            room_type = room_info.get("type", "Classroom")
            cap_ratio = round(var.enrolled_count / max(1.0, room_cap), 3)
            room_type_match = 1.0 if room_type == var.required_room_type else 0.0
            
            fac_daily_load = float(state.faculty_daily_hours.get((var.faculty_id, val.day), 0))
            time_token = f"{val.day}:{val.slot_id}"
            fac_avail = 0.0 if time_token in unavail_set else 1.0
            
            grp_window_gap = 1.0 if is_late else 0.0
            hist_collision = 0.7 if is_peak else 0.3
            
            # Row mapping to FEATURE_COLUMNS:
            # 0: day_index, 1: slot_index, 2: is_peak_slot, 3: is_late_slot,
            # 4: enrolled_students, 5: room_capacity, 6: room_capacity_ratio,
            # 7: room_type_match, 8: is_lab_course, 9: faculty_daily_load,
            # 10: faculty_weekly_load, 11: faculty_available, 12: group_daily_load,
            # 13: group_has_window_gap, 14: historical_collision_score
            matrix[i, 0] = day_idx
            matrix[i, 1] = slot_idx
            matrix[i, 2] = is_peak
            matrix[i, 3] = is_late
            matrix[i, 4] = var.enrolled_count
            matrix[i, 5] = room_cap
            matrix[i, 6] = cap_ratio
            matrix[i, 7] = room_type_match
            matrix[i, 8] = 1.0 if var.is_lab else 0.0
            matrix[i, 9] = fac_daily_load
            matrix[i, 10] = fac_weekly_load
            matrix[i, 11] = fac_avail
            matrix[i, 12] = grp_daily_load_base
            matrix[i, 13] = grp_window_gap
            matrix[i, 14] = hist_collision

        # Vectorized prediction with feature column names to avoid warnings
        features_df = pd.DataFrame(matrix, columns=FEATURE_COLUMNS)
        probs = self.model.predict_proba(features_df)[:, 1]
        return [float(p) for p in probs]
