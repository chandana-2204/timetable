"""UI View Components."""
from .tools_view import render_tools_center
from .reports_view import render_reports_center

__all__ = ["render_tools_center", "render_reports_center"]
