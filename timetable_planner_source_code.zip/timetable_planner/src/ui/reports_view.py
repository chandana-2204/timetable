"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Reports Center UI View Component (Comprehensive Catalog, Dedicated Report Viewer & Multi-Format Exports)

SIH 2025 | Problem Statement SIH25091
"""

import streamlit as st
import pandas as pd
import datetime
import io
import plotly.express as px
from typing import Dict, Any, List, Optional

from ..reports.service import ReportService
from ..exports.exporter import TimetableExporter

REPORT_CATALOG: List[Dict[str, Any]] = [
    # ── CATEGORY A: TIMETABLE REPORTS ──
    {
        "id": "rep_master_timetable",
        "category": "Timetable Reports",
        "name": "Master Academic Timetable Report",
        "description": "Comprehensive schedule of all institutional sessions across all departments, sections, faculty, and rooms.",
        "why_use": "Provides the complete institutional overview for deans, registrar, and academic scheduling committee.",
        "filters": ["Department", "Student Section", "Faculty Member", "Room", "Day of Week"],
        "exports": ["CSV", "Excel (.xlsx)", "PDF Document"],
        "icon": "📑"
    },
    {
        "id": "rep_section_grid",
        "category": "Timetable Reports",
        "name": "Student Section Weekly Grid Schedule",
        "description": "Weekly 5-day x 7-slot matrix for individual student cohorts, displaying courses, venues, and instructors.",
        "why_use": "Printed and shared directly with students and class coordinators as their official weekly routine.",
        "filters": ["Student Section (Cohort)"],
        "exports": ["CSV", "Excel (.xlsx)", "PDF Document"],
        "icon": "👥"
    },
    {
        "id": "rep_faculty_grid",
        "category": "Timetable Reports",
        "name": "Faculty Teaching Schedule Grid",
        "description": "Personalized weekly schedule grid for faculty members showing assigned slots, course codes, sections, and venues.",
        "why_use": "Assists faculty in personal lesson planning and prevents scheduling overlapping departmental commitments.",
        "filters": ["Faculty Member"],
        "exports": ["CSV", "Excel (.xlsx)", "PDF Document"],
        "icon": "👨‍🏫"
    },
    {
        "id": "rep_room_grid",
        "category": "Timetable Reports",
        "name": "Room & Laboratory Occupancy Grid",
        "description": "Slot-by-slot weekly utilization schedule for lecture halls, smart classrooms, and specialized laboratories.",
        "why_use": "Enables facility managers and estate officers to identify free periods for maintenance or ad-hoc events.",
        "filters": ["Room / Laboratory"],
        "exports": ["CSV", "Excel (.xlsx)", "PDF Document"],
        "icon": "🏛️"
    },

    # ── CATEGORY B: SCHEDULING QUALITY REPORTS ──
    {
        "id": "rep_quality_telemetry",
        "category": "Scheduling Quality Reports",
        "name": "Scheduling Quality & Constraint Verification Report",
        "description": "Audits hard-constraint compliance, soft-penalty objective distribution, and CSP solver search telemetry.",
        "why_use": "Validates that the timetable meets all accreditation standards with 0 room/faculty collisions before publishing.",
        "filters": ["Timetable Version"],
        "exports": ["CSV", "Excel (.xlsx)"],
        "icon": "📊"
    },
    {
        "id": "rep_curriculum_coverage",
        "category": "Scheduling Quality Reports",
        "name": "Curriculum Requirements & Coverage Audit",
        "description": "Compares NEP-2020 weekly sessions mandated in syllabus against actually scheduled class periods.",
        "why_use": "Ensures no mandatory core course (DSC) or multidisciplinary elective (MDC/VAC) has missing credit hours.",
        "filters": ["Course Category", "Department"],
        "exports": ["CSV", "Excel (.xlsx)"],
        "icon": "📋"
    },

    # ── CATEGORY C: FACULTY REPORTS ──
    {
        "id": "rep_faculty_workload",
        "category": "Faculty Reports",
        "name": "Faculty Workload & Utilization Report",
        "description": "Detailed breakdown of weekly teaching hours, daily workload ceilings, free periods, and overload status.",
        "why_use": "Ensures equitable teaching allocation and compliance with UGC/AICTE maximum weekly workload caps.",
        "filters": ["Department"],
        "exports": ["CSV", "Excel (.xlsx)"],
        "icon": "⚖️"
    },

    # ── CATEGORY D: ROOM UTILIZATION REPORTS ──
    {
        "id": "rep_room_utilization",
        "category": "Room Utilization Reports",
        "name": "Room Occupancy & Utilization Efficiency",
        "description": "Occupied vs free slot ratios across the 35 weekly standard slots, average seat fill rate, and capacity sizing.",
        "why_use": "Highlights underutilized spaces and prevents booking large auditoriums for small elective batches.",
        "filters": ["Room Type (Classroom, Lab, LectureHall)", "Building"],
        "exports": ["CSV", "Excel (.xlsx)"],
        "icon": "🏢"
    },

    # ── CATEGORY E: ACADEMIC OPERATIONS REPORTS ──
    {
        "id": "rep_operations_audit",
        "category": "Academic Operations Reports",
        "name": "Academic Operations & Substitutions History",
        "description": "Historical audit of faculty leave declarations, substitute matching assignments, and makeup session approvals.",
        "why_use": "Provides HODs and deans with a single verifiable compliance log of all ad-hoc operational adjustments.",
        "filters": ["Operation Type (Absence, Makeup, Rescheduling)"],
        "exports": ["CSV", "Excel (.xlsx)"],
        "icon": "🔄"
    },

    # ── CATEGORY F: SYSTEM REPORTS ──
    {
        "id": "rep_system_audit",
        "category": "System Reports",
        "name": "Timetable Release Versions & Security Audit Trail",
        "description": "Complete version control ledger of draft vs published timetables, quality scores, and security event logs.",
        "why_use": "Essential for institutional governance, auditing who published or rescheduled sessions and when.",
        "filters": ["Event Category"],
        "exports": ["CSV", "Excel (.xlsx)"],
        "icon": "🛡️"
    }
]


def render_reports_center(data_dict: Dict[str, Any]):
    """Render the Reports Center with categories, cards, and full interactive viewer."""
    st.markdown("""
    <div style="margin-bottom:20px;">
        <h2 style="font-size:1.6rem; font-weight:800; color:#0B0D17; margin:0 0 4px 0;">📑 Official Academic Reporting Center</h2>
        <p style="font-size:0.875rem; color:#64748B; margin:0;">
            Institutional analytics, accredited timetable schedules, faculty workload audits, and room occupancy reports with live multi-format exports.
        </p>
    </div>
    """, unsafe_allow_html=True)

    if "active_report_id" not in st.session_state:
        st.session_state["active_report_id"] = None

    # If a report is currently opened, display the Report Viewer
    active_rep_id = st.session_state["active_report_id"]
    if active_rep_id:
        render_report_viewer(active_rep_id, data_dict)
        return

    # Category filter and search
    categories = [
        "All Categories", "Timetable Reports", "Scheduling Quality Reports",
        "Faculty Reports", "Room Utilization Reports", "Academic Operations Reports", "System Reports"
    ]
    c1, c2 = st.columns([1, 2])
    with c1:
        sel_cat = st.selectbox("Category", categories, label_visibility="collapsed")
    with c2:
        search_q = st.text_input("Search reports by title, contents, or keywords...", placeholder="Search reports...", label_visibility="collapsed")

    filtered = REPORT_CATALOG
    if sel_cat != "All Categories":
        filtered = [r for r in filtered if r["category"] == sel_cat]
    if search_q:
        q = search_q.lower()
        filtered = [r for r in filtered if q in r["name"].lower() or q in r["description"].lower() or q in r["why_use"].lower()]

    st.markdown(f"<div style='font-size:0.8rem; color:#64748B; margin-bottom:14px;'>Available standard reports: <b>{len(filtered)}</b></div>", unsafe_allow_html=True)

    # Render report cards in 2-column grid
    for i in range(0, len(filtered), 2):
        row_reps = filtered[i:i+2]
        cols = st.columns(len(row_reps))
        for col_idx, rep in enumerate(row_reps):
            with cols[col_idx]:
                render_report_card(rep)


def render_report_card(rep: Dict[str, Any]):
    """Render a structured report card with description, purpose, filters, and action."""
    filters_str = ", ".join(rep["filters"])
    exports_str = ", ".join(rep["exports"])

    st.markdown(f"""
    <div class="surface-card" style="height:100%; display:flex; flex-direction:column; justify-content:space-between; margin-bottom:16px;">
        <div>
            <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:6px;">
                <span style="font-size:1.8rem;">{rep['icon']}</span>
                <span style="background:#EEF2FF; color:#3730A3; padding:2px 8px; border-radius:999px; font-size:0.7rem; font-weight:700;">{rep['category']}</span>
            </div>
            <h3 style="margin:0 0 6px 0; font-size:1.05rem; font-weight:800; color:#0B0D17;">{rep['name']}</h3>
            <p style="font-size:0.825rem; color:#334155; line-height:1.4; margin-bottom:10px;">{rep['description']}</p>
            <div style="background:#F8FAFC; border-radius:8px; padding:10px 12px; font-size:0.75rem; color:#475569; margin-bottom:12px; line-height:1.5;">
                <div style="margin-bottom:4px;"><b>Why use:</b> {rep['why_use']}</div>
                <div style="margin-bottom:4px;"><b>Available Filters:</b> {filters_str}</div>
                <div><b>Exports:</b> {exports_str}</div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    if st.button(f"View Report: {rep['name']}", key=f"btn_view_{rep['id']}", type="primary", use_container_width=True):
        st.session_state["active_report_id"] = rep["id"]
        st.rerun()


def render_report_viewer(rep_id: str, data_dict: Dict[str, Any]):
    """Dedicated Report Viewer component with active filters, KPI metrics, tables, charts, and exports."""
    # Find report metadata
    rep = next((r for r in REPORT_CATALOG if r["id"] == rep_id), None)
    if not rep:
        st.error("Report not found.")
        st.session_state["active_report_id"] = None
        st.rerun()

    # Back button
    if st.button("← Back to Reports Center", key="btn_back_reports"):
        st.session_state["active_report_id"] = None
        st.rerun()

    records = st.session_state.get("schedule_records", [])
    rep_svc = ReportService(data_dict=data_dict, schedule_records=records)
    today_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Viewer Header
    st.markdown(f"""
    <div class="surface-card" style="border-left:5px solid #0D9488; margin-bottom:16px;">
        <div style="display:flex; justify-content:space-between; align-items:flex-start;">
            <div>
                <div style="font-size:0.75rem; font-weight:700; text-transform:uppercase; letter-spacing:0.08em; color:#0D9488;">{rep['category']}</div>
                <h2 style="margin:0 0 4px 0; font-size:1.35rem; font-weight:800; color:#0B0D17;">{rep['name']}</h2>
                <div style="font-size:0.85rem; color:#475569;">{rep['description']}</div>
            </div>
            <div style="text-align:right; font-size:0.75rem; color:#64748B;">
                <div><b>Generated:</b> {today_str}</div>
                <div><b>Academic Year:</b> 2026–2027</div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # Route report rendering by ID
    if rep_id == "rep_master_timetable":
        _render_rep_master_timetable(rep_svc, data_dict, records)
    elif rep_id == "rep_section_grid":
        _render_rep_section_grid(rep_svc, data_dict, records)
    elif rep_id == "rep_faculty_grid":
        _render_rep_faculty_grid(rep_svc, data_dict, records)
    elif rep_id == "rep_room_grid":
        _render_rep_room_grid(rep_svc, data_dict, records)
    elif rep_id == "rep_quality_telemetry":
        _render_rep_quality_telemetry(rep_svc)
    elif rep_id == "rep_curriculum_coverage":
        _render_rep_curriculum_coverage(rep_svc, data_dict)
    elif rep_id == "rep_faculty_workload":
        _render_rep_faculty_workload(rep_svc, data_dict)
    elif rep_id == "rep_room_utilization":
        _render_rep_room_utilization(rep_svc, data_dict)
    elif rep_id == "rep_operations_audit":
        _render_rep_operations_audit(rep_svc)
    elif rep_id == "rep_system_audit":
        _render_rep_system_audit(rep_svc)


# ─────────────────────────────────────────────────────────────────────────────
# REPORT VIEWER IMPLEMENTATIONS (REAL DATA ONLY)
# ─────────────────────────────────────────────────────────────────────────────

def _render_rep_master_timetable(rep_svc: ReportService, data_dict: Dict[str, Any], records: List[Dict[str, Any]]):
    f1, f2, f3, f4 = st.columns(4)
    with f1:
        groups = ["All"] + data_dict["student_groups"]["group_id"].tolist()
        sel_grp = st.selectbox("Section", groups)
    with f2:
        fac = ["All"] + data_dict["faculty"]["faculty_id"].tolist()
        sel_fac = st.selectbox("Faculty", fac)
    with f3:
        rooms = ["All"] + data_dict["rooms"]["room_id"].tolist()
        sel_room = st.selectbox("Room", rooms)
    with f4:
        days = ["All", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
        sel_day = st.selectbox("Day", days)

    res = rep_svc.master_timetable(group_id=sel_grp, faculty_id=sel_fac, room_id=sel_room, day=sel_day)
    df = res.get("dataframe", pd.DataFrame())

    m1, m2, m3 = st.columns(3)
    m1.metric("Matching Sessions", res["total_sessions"])
    m2.metric("Total Scheduled", len(records))
    m3.metric("Filter Coverage", f"{round(res['total_sessions']/max(len(records),1)*100, 1)}%")

    if not df.empty:
        st.markdown('<div class="data-table-container">', unsafe_allow_html=True)
        st.dataframe(df, use_container_width=True, height=360)
        st.markdown('</div>', unsafe_allow_html=True)
        _render_export_buttons(df, res.get("records", []), file_basename="master_timetable_report")
    else:
        st.info("No scheduled sessions match the selected filters.")


def _render_rep_section_grid(rep_svc: ReportService, data_dict: Dict[str, Any], records: List[Dict[str, Any]]):
    groups = data_dict["student_groups"]["group_id"].tolist()
    sel_grp = st.selectbox("Select Student Section (Cohort)", groups, index=0)
    grid_res = rep_svc.grid_timetable("group", sel_grp)

    st.metric("Total Weekly Sessions for Cohort", grid_res["total_assigned"])
    _render_html_grid(grid_res["grid"], entity_label=sel_grp)

    # Filtered dataframe for export
    sub_df = pd.DataFrame([r for r in records if r.get("group_id") == sel_grp])
    if not sub_df.empty:
        _render_export_buttons(sub_df, sub_df.to_dict("records"), file_basename=f"timetable_grid_{sel_grp}")


def _render_rep_faculty_grid(rep_svc: ReportService, data_dict: Dict[str, Any], records: List[Dict[str, Any]]):
    fac_df = data_dict["faculty"]
    sel_fac = st.selectbox("Select Faculty Member", fac_df["faculty_id"].tolist(), format_func=lambda x: f"{x} - {fac_df[fac_df['faculty_id']==x]['name'].iloc[0]}")
    grid_res = rep_svc.grid_timetable("faculty", sel_fac)

    st.metric("Total Weekly Teaching Periods", grid_res["total_assigned"])
    _render_html_grid(grid_res["grid"], entity_label=sel_fac)

    sub_df = pd.DataFrame([r for r in records if r.get("faculty_id") == sel_fac])
    if not sub_df.empty:
        _render_export_buttons(sub_df, sub_df.to_dict("records"), file_basename=f"faculty_grid_{sel_fac}")


def _render_rep_room_grid(rep_svc: ReportService, data_dict: Dict[str, Any], records: List[Dict[str, Any]]):
    rooms_df = data_dict["rooms"]
    sel_room = st.selectbox("Select Room / Laboratory", rooms_df["room_id"].tolist(), format_func=lambda x: f"{x} - {rooms_df[rooms_df['room_id']==x]['name'].iloc[0]} ({rooms_df[rooms_df['room_id']==x]['type'].iloc[0]})")
    grid_res = rep_svc.grid_timetable("room", sel_room)

    c1, c2 = st.columns(2)
    c1.metric("Occupied Periods", f"{grid_res['total_assigned']} / 35")
    c2.metric("Utilization Rate", f"{round(grid_res['total_assigned']/35*100, 1)}%")
    _render_html_grid(grid_res["grid"], entity_label=sel_room)

    sub_df = pd.DataFrame([r for r in records if r.get("room_id") == sel_room])
    if not sub_df.empty:
        _render_export_buttons(sub_df, sub_df.to_dict("records"), file_basename=f"room_grid_{sel_room}")


def _render_rep_quality_telemetry(rep_svc: ReportService):
    sched = st.session_state.get("current_schedule", {})
    q = rep_svc.quality_and_conflict_summary(sched)

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Status", q["status"])
    m2.metric("Assigned Sessions", f"{q['assigned_sessions']} / {q['total_sessions']}")
    m3.metric("Completeness", f"{q['completeness_pct']}%")
    m4.metric("Quality Score", f"{q['quality_score']:.1f}/100")

    t1, t2, t3, t4 = st.columns(4)
    t1.metric("Execution Time", f"{q['execution_time_seconds']:.3f} s")
    t2.metric("Backtracks Count", q["backtracks_count"])
    t3.metric("Hard Violations", q["hard_violations_count"])
    t4.metric("Validation Gate", "✅ PASSED" if q["independent_validation_passed"] else "❌ FAILED")

    if q["penalties_breakdown"]:
        st.markdown('<div class="surface-card"><h3>Soft Penalty Objective Penalties Breakdown</h3>', unsafe_allow_html=True)
        df_pen = pd.DataFrame(q["penalties_breakdown"])
        st.dataframe(df_pen, use_container_width=True)
        st.markdown('</div>', unsafe_allow_html=True)
        _render_export_buttons(df_pen, q["penalties_breakdown"], file_basename="quality_penalties_report")


def _render_rep_curriculum_coverage(rep_svc: ReportService, data_dict: Dict[str, Any]):
    res = rep_svc.curriculum_coverage()
    rows = res["rows"]
    df = pd.DataFrame(rows)

    m1, m2, m3 = st.columns(3)
    m1.metric("Curriculum Entries", res["total_requirements"])
    m2.metric("Fully Met Quotas", f"{res['fully_met']} ({res['coverage_pct']}%)")
    m3.metric("Unscheduled Entries", res["unscheduled"])

    st.markdown('<div class="data-table-container">', unsafe_allow_html=True)
    st.dataframe(df, use_container_width=True)
    st.markdown('</div>', unsafe_allow_html=True)
    _render_export_buttons(df, rows, file_basename="curriculum_coverage_report")


def _render_rep_faculty_workload(rep_svc: ReportService, data_dict: Dict[str, Any]):
    depts = ["All"] + sorted(data_dict["faculty"]["department"].unique().tolist())
    sel_dept = st.selectbox("Filter Department", depts)
    res = rep_svc.faculty_workload_report(department=sel_dept)
    df = res["dataframe"]

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Total Faculty", res["total_faculty"])
    m2.metric("Active Instructors", res["active_teaching_faculty"])
    m3.metric("Overloaded (>16h/wk or >4h/day)", res["overloaded_count"])
    m4.metric("Avg Teaching Utilization", f"{res['average_utilization']}%")

    if not df.empty:
        # Chart
        fig = px.bar(
            df.sort_values(by="weekly_assigned", ascending=False),
            x="name", y=["weekly_assigned", "max_hours_per_week"],
            barmode="overlay",
            title="Faculty Weekly Assigned Hours vs Maximum Weekly Capacity (16h)",
            color_discrete_sequence=["#0A24E9", "#E2E8F0"]
        )
        st.plotly_chart(fig, use_container_width=True)

        st.markdown('<div class="data-table-container">', unsafe_allow_html=True)
        st.dataframe(df, use_container_width=True)
        st.markdown('</div>', unsafe_allow_html=True)
        _render_export_buttons(df, df.to_dict("records"), file_basename="faculty_workload_report")


def _render_rep_room_utilization(rep_svc: ReportService, data_dict: Dict[str, Any]):
    types = ["All"] + sorted(data_dict["rooms"]["type"].unique().tolist())
    sel_type = st.selectbox("Room Archetype", types)
    res = rep_svc.room_utilization_report(room_type=sel_type)
    df = res["dataframe"]

    m1, m2, m3 = st.columns(3)
    m1.metric("Total Venues", res["total_rooms"])
    m2.metric("Average Slot Utilization", f"{res['avg_utilization']}%")
    m3.metric("High Demand Venues (>=70%)", res["high_demand_count"])

    if not df.empty:
        fig = px.bar(
            df.sort_values(by="utilization_pct", ascending=False),
            x="name", y="utilization_pct",
            color="type",
            title="Room Weekly Utilization Percentage (across 35 standard weekly slots)",
            color_discrete_sequence=["#0A24E9", "#5C9764", "#7C3AED", "#F59E0B"]
        )
        st.plotly_chart(fig, use_container_width=True)

        st.markdown('<div class="data-table-container">', unsafe_allow_html=True)
        st.dataframe(df, use_container_width=True)
        st.markdown('</div>', unsafe_allow_html=True)
        _render_export_buttons(df, df.to_dict("records"), file_basename="room_utilization_report")


def _render_rep_operations_audit(rep_svc: ReportService):
    st.info("Querying production database tables for faculty absences, substitute assignments, and makeup classes.")
    res = rep_svc.operations_audit_report()

    m1, m2, m3 = st.columns(3)
    m1.metric("Registered Absences", res["total_absences"])
    m2.metric("Makeup Requests", res["total_makeups"])
    m3.metric("Reschedule Audits", res["total_reschedules"])

    tab1, tab2, tab3 = st.tabs(["📋 Faculty Absences", "🔄 Makeup Requests", "📆 Rescheduling History"])
    with tab1:
        if not res["absences_df"].empty:
            st.dataframe(res["absences_df"], use_container_width=True)
            _render_export_buttons(res["absences_df"], res["absences_df"].to_dict("records"), "faculty_absences_audit")
        else:
            st.caption("No absence records logged yet.")

    with tab2:
        if not res["makeups_df"].empty:
            st.dataframe(res["makeups_df"], use_container_width=True)
            _render_export_buttons(res["makeups_df"], res["makeups_df"].to_dict("records"), "makeup_requests_audit")
        else:
            st.caption("No makeup class requests logged yet.")

    with tab3:
        if not res["reschedules_df"].empty:
            st.dataframe(res["reschedules_df"], use_container_width=True)
            _render_export_buttons(res["reschedules_df"], res["reschedules_df"].to_dict("records"), "rescheduling_audit")
        else:
            st.caption("No rescheduling events recorded in audit log yet.")


def _render_rep_system_audit(rep_svc: ReportService):
    st.info("Querying system tables for published timetable versions, certification statuses, and user audit trails.")
    res = rep_svc.system_version_and_audit_report()

    m1, m2 = st.columns(2)
    m1.metric("Total Timetable Versions", res["total_versions"])
    m2.metric("Total Audit Events Logged", res["total_logs"])

    t1, t2 = st.tabs(["🏷️ Timetable Versions Ledger", "🛡️ Security & Activity Audit Trail"])
    with t1:
        if not res["versions_df"].empty:
            st.dataframe(res["versions_df"], use_container_width=True)
            _render_export_buttons(res["versions_df"], res["versions_df"].to_dict("records"), "timetable_versions_ledger")
        else:
            st.caption("No timetable versions registered yet.")

    with t2:
        if not res["audit_logs_df"].empty:
            st.dataframe(res["audit_logs_df"], use_container_width=True)
            _render_export_buttons(res["audit_logs_df"], res["audit_logs_df"].to_dict("records"), "system_security_audit")
        else:
            st.caption("No audit events recorded yet.")


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: HTML WEEKLY GRID RENDERING
# ─────────────────────────────────────────────────────────────────────────────

def _render_html_grid(grid: Dict[str, Dict[int, Any]], entity_label: str):
    DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
    SLOTS = list(range(1, 8))

    html = '<div style="overflow-x:auto; margin-bottom:16px;"><table style="width:100%; border-collapse:collapse; background:#FFF; border-radius:12px; overflow:hidden; box-shadow:0 1px 3px rgba(0,0,0,0.08); font-size:0.75rem;">'
    html += '<tr style="background:#29315D; color:#FFF; font-weight:700; text-align:center;">'
    html += '<th style="padding:10px 8px; border:1px solid #CBD5E1;">Day / Slot</th>'
    for s in SLOTS:
        times = ["09:00-10:00", "10:00-11:00", "11:15-12:15", "12:15-13:15", "14:00-15:00", "15:00-16:00", "16:00-17:00"]
        html += f'<th style="padding:8px 6px; border:1px solid #CBD5E1;">Slot {s}<br/><span style="font-size:0.65rem; font-weight:400; opacity:0.8;">{times[s-1]}</span></th>'
    html += '</tr>'

    for d in DAYS:
        html += f'<tr><td style="padding:10px 8px; font-weight:700; background:#F8FAFC; border:1px solid #CBD5E1; text-align:center;">{d}</td>'
        for s in SLOTS:
            cell = grid.get(d, {}).get(s)
            if cell:
                cid = cell.get("course_id", "")
                rid = cell.get("room_id", "")
                fac = cell.get("faculty_name", cell.get("faculty_id", ""))
                grp = cell.get("group_id", "")
                sub_label = f"[{grp}]" if grp else f"({fac.split()[-1] if fac else ''})"
                html += f'<td style="padding:6px; border:1px solid #CBD5E1; background:#EEF2FF; text-align:center;"><div style="font-weight:700; color:#0A24E9;">{cid}</div><div style="font-size:0.67rem; color:#475569;">{rid} {sub_label}</div></td>'
            else:
                html += '<td style="padding:6px; border:1px solid #CBD5E1; text-align:center; color:#94A3B8; font-size:0.68rem;">FREE</td>'
        html += '</tr>'
    html += '</table></div>'
    st.markdown(html, unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: DYNAMIC IN-MEMORY EXPORT BUTTONS
# ─────────────────────────────────────────────────────────────────────────────

def _render_export_buttons(df: pd.DataFrame, records: List[Dict[str, Any]], file_basename: str):
    """Render in-memory CSV, Excel, and PDF download buttons directly from the displayed dataset."""
    st.markdown('<div style="display:flex; gap:12px; margin-top:12px; flex-wrap:wrap;">', unsafe_allow_html=True)
    e1, e2, e3 = st.columns(3)

    with e1:
        csv_buf = TimetableExporter.export_to_csv_buffer(records if records else df.to_dict("records"))
        st.download_button(
            "⬇️ Export Report (CSV)",
            data=csv_buf.getvalue(),
            file_name=f"{file_basename}.csv",
            mime="text/csv",
            use_container_width=True
        )

    with e2:
        excel_buf = TimetableExporter.export_to_excel_buffer(records if records else df.to_dict("records"))
        st.download_button(
            "⬇️ Export Report (Excel .xlsx)",
            data=excel_buf.getvalue(),
            file_name=f"{file_basename}.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True
        )

    with e3:
        if "course_id" in df.columns and "day" in df.columns:
            pdf_buf = TimetableExporter.export_to_pdf_buffer(records if records else df.to_dict("records"), title=file_basename.replace("_", " ").title())
            st.download_button(
                "⬇️ Export Report (PDF)",
                data=pdf_buf.getvalue(),
                file_name=f"{file_basename}.pdf",
                mime="application/pdf",
                use_container_width=True
            )
        else:
            st.caption("PDF available for schedule grid formats.")
    st.markdown('</div>', unsafe_allow_html=True)
