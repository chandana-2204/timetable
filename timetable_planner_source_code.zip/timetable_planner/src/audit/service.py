"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Immutable Governance Audit Logging Service (P2)

SIH 2025 | Problem Statement SIH25091
"""

import json
from typing import Dict, Any, List, Optional
from ..database.connection import db_manager, DatabaseConnectionManager

class AuditService:
    """Records immutable audit trail of all governance, scheduling, and administrative actions."""

    def __init__(self, db_mgr: Optional[DatabaseConnectionManager] = None):
        self.db_mgr = db_mgr if db_mgr is not None else db_manager

    def log_action(
        self,
        action: str,
        entity_name: str,
        entity_id: str,
        user_id: Optional[str] = None,
        old_state: Optional[Dict[str, Any]] = None,
        new_state: Optional[Dict[str, Any]] = None,
        ip_address: Optional[str] = None
    ) -> int:
        """Record an administrative action in the immutable audit log."""
        # Sanitize sensitive fields
        clean_old = self._sanitize(old_state) if old_state else None
        clean_new = self._sanitize(new_state) if new_state else None

        with self.db_mgr.transaction() as conn:
            cur = conn.execute(
                """
                INSERT INTO audit_logs (user_id, action, entity_name, entity_id, old_state, new_state, ip_address)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    user_id,
                    action,
                    entity_name,
                    entity_id,
                    json.dumps(clean_old) if clean_old else None,
                    json.dumps(clean_new) if clean_new else None,
                    ip_address
                )
            )
            return cur.lastrowid

    def get_entity_history(self, entity_name: str, entity_id: str) -> List[Dict[str, Any]]:
        """Retrieve audit history for a specific entity."""
        conn = self.db_mgr.get_connection()
        try:
            rows = conn.execute(
                """
                SELECT log_id, user_id, action, entity_name, entity_id, old_state, new_state, created_at
                FROM audit_logs
                WHERE entity_name = ? AND entity_id = ?
                ORDER BY log_id DESC
                """,
                (entity_name, entity_id)
            ).fetchall()
            res = []
            for r in rows:
                d = dict(r)
                d["old_state"] = json.loads(d["old_state"]) if d["old_state"] else None
                d["new_state"] = json.loads(d["new_state"]) if d["new_state"] else None
                res.append(d)
            return res
        finally:
            conn.close()

    def _sanitize(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Strip password or secret tokens from audit entries."""
        sensitive = {"password", "password_hash", "token", "secret", "key"}
        clean = {}
        for k, v in data.items():
            if any(s in k.lower() for s in sensitive):
                clean[k] = "[REDACTED]"
            elif isinstance(v, dict):
                clean[k] = self._sanitize(v)
            else:
                clean[k] = v
        return clean
