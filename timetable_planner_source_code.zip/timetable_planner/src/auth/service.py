"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Authentication & Role-Based Authorization Service (PBKDF2-HMAC-SHA256 Cryptographic Hashing)

SIH 2025 | Problem Statement SIH25091
"""

import os
import secrets
import hashlib
import uuid
from typing import Optional, Dict, Any, List
from ..database.connection import db_manager, DatabaseConnectionManager

class PasswordHasher:
    """Cryptographically secure PBKDF2-HMAC-SHA256 hasher with 100,000 iterations and per-user salt."""

    ITERATIONS = 100_000

    @classmethod
    def hash_password(cls, password: str) -> str:
        """Hash a plaintext password with a random 16-byte salt."""
        salt = secrets.token_hex(16)
        key = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt.encode("utf-8"),
            cls.ITERATIONS
        )
        return f"{salt}${key.hex()}"

    @classmethod
    def verify_password(cls, password: str, stored_hash: str) -> bool:
        """Verify candidate plaintext password against stored salt$key hash."""
        try:
            salt, key_hex = stored_hash.split("$", 1)
            candidate_key = hashlib.pbkdf2_hmac(
                "sha256",
                password.encode("utf-8"),
                salt.encode("utf-8"),
                cls.ITERATIONS
            )
            return secrets.compare_digest(candidate_key.hex(), key_hex)
        except Exception:
            return False


class AuthService:
    """Authentication and role-based authorization service."""

    def __init__(self, db_mgr: Optional[DatabaseConnectionManager] = None):
        self.db_mgr = db_mgr if db_mgr is not None else db_manager

    def register_user(
        self,
        username: str,
        email: str,
        password: str,
        first_name: str,
        last_name: str,
        roles: List[str]
    ) -> Dict[str, Any]:
        """Register a new user with hashed password and assign roles."""
        user_id = str(uuid.uuid4())
        pwd_hash = PasswordHasher.hash_password(password)

        with self.db_mgr.transaction() as conn:
            # Check unique username and email
            existing = conn.execute("SELECT 1 FROM users WHERE username = ? OR email = ?", (username, email)).fetchone()
            if existing is not None:
                raise ValueError(f"User with username '{username}' or email '{email}' already exists.")

            conn.execute(
                """
                INSERT INTO users (user_id, username, email, password_hash, first_name, last_name, is_active)
                VALUES (?, ?, ?, ?, ?, ?, 1)
                """,
                (user_id, username, email, pwd_hash, first_name, last_name)
            )

            for role_id in roles:
                conn.execute(
                    "INSERT INTO user_roles (user_id, role_id) VALUES (?, ?)",
                    (user_id, role_id)
                )

        return {"user_id": user_id, "username": username, "email": email, "roles": roles}

    def authenticate(self, username: str, password: str) -> Optional[Dict[str, Any]]:
        """Verify user credentials and return user profile with roles if valid and active."""
        conn = self.db_mgr.get_connection()
        try:
            row = conn.execute(
                "SELECT user_id, username, email, password_hash, first_name, last_name, is_active FROM users WHERE username = ?",
                (username,)
            ).fetchone()

            if row is None:
                return None

            if not row["is_active"]:
                return None # Disabled user cannot authenticate

            if not PasswordHasher.verify_password(password, row["password_hash"]):
                return None

            roles_rows = conn.execute(
                "SELECT role_id FROM user_roles WHERE user_id = ?",
                (row["user_id"],)
            ).fetchall()
            roles = [r["role_id"] for r in roles_rows]

            return {
                "user_id": row["user_id"],
                "username": row["username"],
                "email": row["email"],
                "first_name": row["first_name"],
                "last_name": row["last_name"],
                "roles": roles
            }
        finally:
            conn.close()

    def set_user_active_status(self, user_id: str, is_active: bool):
        """Enable or disable a user account."""
        with self.db_mgr.transaction() as conn:
            conn.execute("UPDATE users SET is_active = ? WHERE user_id = ?", (1 if is_active else 0, user_id))

    def has_role(self, user_id: str, required_role: str) -> bool:
        """Check if user possesses a specific role."""
        conn = self.db_mgr.get_connection()
        try:
            row = conn.execute(
                "SELECT 1 FROM user_roles WHERE user_id = ? AND role_id = ?",
                (user_id, required_role)
            ).fetchone()
            return row is not None
        finally:
            conn.close()

    def has_permission(self, user_id: str, required_permission: str) -> bool:
        """Check if any of user's roles grants the requested permission."""
        conn = self.db_mgr.get_connection()
        try:
            row = conn.execute(
                """
                SELECT 1 FROM user_roles ur
                JOIN role_permissions rp ON ur.role_id = rp.role_id
                WHERE ur.user_id = ? AND rp.permission_id = ?
                """,
                (user_id, required_permission)
            ).fetchone()
            return row is not None
        finally:
            conn.close()

    def provision_initial_admin(self, username: str, email: str, password: str) -> Dict[str, Any]:
        """Explicit, documented initial administrator provisioning without default hardcoded credentials."""
        conn = self.db_mgr.get_connection()
        try:
            admin_exists = conn.execute(
                """
                SELECT 1 FROM users u
                JOIN user_roles ur ON u.user_id = ur.user_id
                WHERE ur.role_id = 'ADMIN'
                """
            ).fetchone()
            if admin_exists is not None:
                raise ValueError("An administrator user already exists in the system.")
        finally:
            conn.close()

        return self.register_user(
            username=username,
            email=email,
            password=password,
            first_name="System",
            last_name="Administrator",
            roles=["ADMIN"]
        )
