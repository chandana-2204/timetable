"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Persistent Notification Service & Dispatch Interface (P2)

SIH 2025 | Problem Statement SIH25091
"""

import uuid
from typing import Dict, Any, List, Optional
from ..database.connection import db_manager, DatabaseConnectionManager

class NotificationService:
    """Manages persistent in-app notifications and provides an extensible dispatch interface."""

    def __init__(self, db_mgr: Optional[DatabaseConnectionManager] = None):
        self.db_mgr = db_mgr if db_mgr is not None else db_manager

    def create_notification(
        self,
        recipient_user_id: str,
        title: str,
        message: str,
        category: str # 'TIMETABLE_CHANGE', 'MAKEUP_CLASS', 'SUBSTITUTION', 'ABSENCE'
    ) -> str:
        """Create and persist an in-app notification record."""
        notification_id = str(uuid.uuid4())
        with self.db_mgr.transaction() as conn:
            conn.execute(
                """
                INSERT INTO notifications (notification_id, recipient_user_id, title, message, category, is_read)
                VALUES (?, ?, ?, ?, ?, 0)
                """,
                (notification_id, recipient_user_id, title, message, category)
            )
        return notification_id

    def notify_cohort_students(
        self,
        group_id: str,
        title: str,
        message: str,
        category: str
    ) -> int:
        """Dispatch notifications to all students belonging to a group."""
        conn = self.db_mgr.get_connection()
        try:
            students = conn.execute(
                "SELECT user_id FROM students WHERE section_id = ? AND user_id IS NOT NULL",
                (group_id,)
            ).fetchall()
            count = 0
            for s in students:
                self.create_notification(s["user_id"], title, message, category)
                count += 1
            return count
        finally:
            conn.close()

    def get_unread_notifications(self, user_id: str) -> List[Dict[str, Any]]:
        """Fetch all unread notifications for a user."""
        conn = self.db_mgr.get_connection()
        try:
            rows = conn.execute(
                """
                SELECT notification_id, title, message, category, created_at
                FROM notifications
                WHERE recipient_user_id = ? AND is_read = 0
                ORDER BY created_at DESC
                """,
                (user_id,)
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def mark_as_read(self, notification_id: str):
        """Mark a notification as read."""
        with self.db_mgr.transaction() as conn:
            conn.execute("UPDATE notifications SET is_read = 1 WHERE notification_id = ?", (notification_id,))
