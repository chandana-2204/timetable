"""Notifications package init"""
from .service import NotificationService
