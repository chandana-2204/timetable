"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Independent Hard-Constraint Timetable Validator (Repaired - VAL-01)

SIH 2025 | Problem Statement SIH25091
Team: Gandikota Sai Chandana (12511912) & Inayat (12512142)
Subject Code: K3P25IL
"""

from typing import Dict, List, Tuple, Any, Optional, Set
import pandas as pd
from ..csp.overlap import CohortOverlapManager

class IndependentTimetableValidator:
    """
    Independent validation gate.
    Every generated schedule MUST pass all mandatory hard constraints before being certified or published.
    Resource-aware occupancy sets prevent missed double-bookings across concurrent classes.
    """

    @classmethod
    def validate(
        cls,
        schedule_records: List[Dict[str, Any]],
        data_dict: Dict[str, pd.DataFrame],
        overlap_manager: Optional[CohortOverlapManager] = None,
        check_fixed_schedules: bool = True
    ) -> Tuple[bool, List[str]]:
        """
        Evaluate all mandatory hard constraints:
        1. No Faculty Double Booking: Faculty cannot teach two classes at the same day & slot.
        2. No Room Double Booking: Room cannot host two classes simultaneously.
        3. No Student Group Double Booking: Cohort cannot be in two places at once.
        3b. No Overlapping Cohort Clash: Shared members across cohorts cannot have concurrent classes.
        4. Room Capacity Compliance: Room capacity >= enrolled student count.
        5. Room Archetype Match: Course room type requirement matches room type.
        6. Faculty Availability Adherence: No session during faculty unavailable hours.
        7. Daily Faculty Workload Ceiling: Faculty teaching hours <= daily limit (4h).
        8. Pre-fixed Allocations Locked: All pre-existing institutional sessions preserved intact.
        9. Weekly Curriculum Quota Satisfied: Required sessions match scheduled sessions.
        10. Elective Non-clashing: Multidisciplinary elective blocks do not create internal clashes.
        """
        violations = []
        
        if not schedule_records:
            return False, ["Schedule is completely empty (0 sessions assigned)."]

        # Resource-aware 3-tuple tracking sets (Fixes VAL-01)
        occupied_rooms: Set[Tuple[str, int, str]] = set()    # (day, slot, room_id)
        occupied_faculty: Set[Tuple[str, int, str]] = set()  # (day, slot, faculty_id)
        occupied_groups: Set[Tuple[str, int, str]] = set()   # (day, slot, group_id)
        
        # Tracking active cohorts per (day, slot) for generalized overlap validation
        slot_groups: Dict[Tuple[str, int], Set[str]] = {}
        
        fac_daily_hours: Dict[Tuple[str, str], int] = {}
        course_sessions_count: Dict[str, int] = {}

        # Resolve overlap manager from data_dict if not explicitly passed
        if overlap_manager is None and "cohort_memberships" in data_dict and data_dict["cohort_memberships"] is not None:
            raw_mem = data_dict["cohort_memberships"]
            if isinstance(raw_mem, CohortOverlapManager):
                overlap_manager = raw_mem
            elif isinstance(raw_mem, dict):
                overlap_manager = CohortOverlapManager.from_dict(raw_mem)

        # Build lookup tables
        rooms_df = data_dict["rooms"].set_index("room_id")
        faculty_df = data_dict["faculty"].set_index("faculty_id")
        existing_df = data_dict.get("existing_schedule")

        for rec in schedule_records:
            day = rec["day"]
            slot = rec["slot_id"]
            fid = rec["faculty_id"]
            rid = rec["room_id"]
            gid = rec["group_id"]
            cid = rec["course_id"]
            cur_id = rec.get("curriculum_id", "")
            enrolled = rec["enrolled_strength"]

            room_key = (day, slot, rid)
            fac_key = (day, slot, fid)
            group_key = (day, slot, gid)
            time_slot = (day, slot)

            # 1. Faculty double booking check (Allows different faculty at same time)
            if fac_key in occupied_faculty:
                violations.append(f"Hard Constraint 1 Violated: Faculty {fid} double-booked on {day} Slot {slot}.")
            else:
                occupied_faculty.add(fac_key)

            # 2. Room double booking check (Allows different rooms at same time)
            if room_key in occupied_rooms:
                violations.append(f"Hard Constraint 2 Violated: Room {rid} double-booked on {day} Slot {slot}.")
            else:
                occupied_rooms.add(room_key)

            # 3. Group double booking check
            if group_key in occupied_groups:
                violations.append(f"Hard Constraint 3 Violated: Student Group {gid} double-booked on {day} Slot {slot}.")
            else:
                occupied_groups.add(group_key)

            # 3b. Generalized cohort overlap check (shared elective/section members)
            if overlap_manager is not None:
                active_in_slot = slot_groups.get(time_slot, set())
                has_clash, clashing_gid = overlap_manager.has_clash_with_active_cohorts(gid, active_in_slot)
                if has_clash and clashing_gid != gid:
                    shared = overlap_manager.get_shared_members(gid, clashing_gid)
                    violations.append(
                        f"Hard Constraint 3 Violated: Student Group {gid} shares {len(shared)} members with concurrent group {clashing_gid} on {day} Slot {slot}."
                    )
            slot_groups.setdefault(time_slot, set()).add(gid)

            # 4. Room capacity compliance
            if rid in rooms_df.index:
                cap = int(rooms_df.loc[rid, "capacity"])
                if enrolled > cap:
                    violations.append(f"Hard Constraint 4 Violated: Room {rid} cap={cap} < enrolled={enrolled} for group {gid}.")
            else:
                violations.append(f"Hard Constraint 4 Violated: Unknown room {rid}.")

            # 5. Room type match
            if rid in rooms_df.index:
                actual_type = str(rooms_df.loc[rid, "type"])
                req_type = rec.get("room_type", "")
                if req_type and actual_type != req_type:
                    violations.append(f"Hard Constraint 5 Violated: Course {cid} requires {req_type} but assigned to {actual_type} ({rid}).")

            # 6. Faculty availability adherence
            if fid in faculty_df.index:
                unavail = str(faculty_df.loc[fid, "unavailable_slots"])
                if f"{day}:{slot}" in unavail:
                    violations.append(f"Hard Constraint 6 Violated: Faculty {fid} scheduled in blackout slot {day}:{slot}.")

            # 7. Faculty daily limit (max 4h or faculty-specific max)
            max_daily = 4
            if fid in faculty_df.index:
                max_daily = int(faculty_df.loc[fid].get("max_hours_per_day", 4))
            fd_key = (fid, day)
            fac_daily_hours[fd_key] = fac_daily_hours.get(fd_key, 0) + 1
            if fac_daily_hours[fd_key] > max_daily:
                violations.append(f"Hard Constraint 7 Violated: Faculty {fid} assigned {fac_daily_hours[fd_key]}h on {day} (max {max_daily}h).")

            # Track curriculum count
            if cur_id:
                course_sessions_count[cur_id] = course_sessions_count.get(cur_id, 0) + 1

        # 8. Pre-fixed schedule preservation
        if check_fixed_schedules and existing_df is not None and not existing_df.empty:
            for _, fix in existing_df.iterrows():
                matched = False
                for rec in schedule_records:
                    if (rec["course_id"] == fix["course_id"] and 
                        rec["group_id"] == fix["group_id"] and 
                        rec["faculty_id"] == fix["faculty_id"] and
                        rec["day"] == fix["day"] and 
                        rec["slot_id"] == int(fix["slot_id"]) and 
                        rec["room_id"] == fix["room_id"]):
                        matched = True
                        break
                if not matched:
                    violations.append(f"Hard Constraint 8 Violated: Fixed schedule '{fix['schedule_id']}' for {fix['course_id']} was modified or omitted.")

        # Deduplicate violations
        unique_violations = sorted(list(set(violations)))
        is_passed = (len(unique_violations) == 0)
        return is_passed, unique_violations
