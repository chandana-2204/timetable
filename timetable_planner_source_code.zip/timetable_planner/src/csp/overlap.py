"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Generalized Cohort Overlap & Student Membership Conflict Manager (CSP-01)

SIH 2025 | Problem Statement SIH25091
"""

from typing import Dict, List, Set, Tuple, Optional, Iterable, Any

class CohortOverlapManager:
    """
    Manages generalized student cohort memberships and precomputes conflict graphs.
    Supports department sections, multidisciplinary elective cohorts, minor baskets,
    lab sub-groups, and individual student-level enrollments across arbitrary IDs.
    """

    def __init__(self, memberships: Optional[Dict[str, Set[str]]] = None):
        """
        Initialize with explicit cohort memberships.
        memberships: Dict mapping cohort_id (str) -> Set of student_id / atomic cluster_id (str).
        """
        self._memberships: Dict[str, Set[str]] = {}
        self._conflict_map: Dict[str, Set[str]] = {}
        self._unresolved_cohorts: Set[str] = set()

        if memberships:
            for cohort_id, members in memberships.items():
                self.register_cohort(cohort_id, members)

    def register_cohort(self, cohort_id: str, members: Iterable[str]):
        """Register a cohort with its explicit set of member student IDs or cluster IDs."""
        cohort_id = str(cohort_id).strip()
        member_set = {str(m).strip() for m in members if str(m).strip()}
        if not member_set:
            self._unresolved_cohorts.add(cohort_id)
            self._memberships[cohort_id] = set()
        else:
            self._memberships[cohort_id] = member_set
            self._unresolved_cohorts.discard(cohort_id)
        self._recompute_conflicts()

    def register_student_enrollment(self, student_id: str, cohort_id: str):
        """Register an individual student's membership in a cohort."""
        sid = str(student_id).strip()
        cid = str(cohort_id).strip()
        if not sid or not cid:
            return
        self._memberships.setdefault(cid, set()).add(sid)
        self._unresolved_cohorts.discard(cid)
        self._recompute_conflicts()

    def _recompute_conflicts(self):
        """Precompute conflict adjacency map for O(1) clash lookups."""
        self._conflict_map = {}
        cohort_ids = list(self._memberships.keys())
        
        for c1 in cohort_ids:
            s1 = self._memberships[c1]
            conflicts = {c1} # A cohort always conflicts with itself
            if s1: # Only compute overlaps if explicit members exist
                for c2 in cohort_ids:
                    if c1 != c2:
                        s2 = self._memberships[c2]
                        if s2 and not s1.isdisjoint(s2):
                            conflicts.add(c2)
            self._conflict_map[c1] = conflicts

    def have_overlap(self, cohort_a: str, cohort_b: str) -> bool:
        """
        Returns True if cohort_a and cohort_b share at least one student or cluster.
        Identity check: cohort_a == cohort_b always returns True.
        """
        ca, cb = str(cohort_a).strip(), str(cohort_b).strip()
        if ca == cb:
            return True
        conflicts = self._conflict_map.get(ca)
        if conflicts is not None:
            return cb in conflicts
        # Fallback to direct set intersection if not precomputed
        sa = self._memberships.get(ca)
        sb = self._memberships.get(cb)
        if sa and sb:
            return not sa.isdisjoint(sb)
        return False

    def get_conflicting_cohorts(self, cohort_id: str) -> Set[str]:
        """Return all cohort IDs that share members with cohort_id (including itself)."""
        cid = str(cohort_id).strip()
        return set(self._conflict_map.get(cid, {cid}))

    def get_shared_members(self, cohort_a: str, cohort_b: str) -> Set[str]:
        """Return the exact set of student/cluster IDs shared between two cohorts."""
        ca, cb = str(cohort_a).strip(), str(cohort_b).strip()
        sa = self._memberships.get(ca, set())
        sb = self._memberships.get(cb, set())
        return sa.intersection(sb)

    def has_clash_with_active_cohorts(self, cohort_id: str, active_cohorts: Iterable[str]) -> Tuple[bool, Optional[str]]:
        """
        Check if cohort_id clashes with any currently active cohort in a time slot.
        Returns: (True, conflicting_cohort_id) or (False, None)
        """
        cid = str(cohort_id).strip()
        conflicts = self.get_conflicting_cohorts(cid)
        for active in active_cohorts:
            act_str = str(active).strip()
            if act_str in conflicts:
                return True, act_str
        return False, None

    def is_unresolved(self, cohort_id: str) -> bool:
        """Returns True if this cohort has no explicit student membership registered."""
        cid = str(cohort_id).strip()
        return cid in self._unresolved_cohorts or cid not in self._memberships or len(self._memberships[cid]) == 0

    def get_unresolved_cohorts(self, cohort_ids: Optional[Iterable[str]] = None) -> List[str]:
        """Return list of cohort IDs lacking explicit membership data."""
        if cohort_ids is None:
            return sorted(list(self._unresolved_cohorts))
        return [str(c).strip() for c in cohort_ids if self.is_unresolved(c)]

    @classmethod
    def from_student_enrollments(cls, enrollment_records: List[Dict[str, str]]) -> "CohortOverlapManager":
        """Factory: build manager from student enrollment list: [{'student_id': '...', 'group_id': '...'}, ...]"""
        mgr = cls()
        for rec in enrollment_records:
            mgr.register_student_enrollment(rec["student_id"], rec["group_id"])
        return mgr

    @classmethod
    def from_dict(cls, data: Dict[str, List[str]]) -> "CohortOverlapManager":
        """Factory: build manager from dict: {cohort_id: [student_id1, student_id2, ...]}"""
        memberships = {k: set(v) for k, v in data.items()}
        return cls(memberships)
