"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Normalized Relational Schema & DDL Specifications (3NF SQLite/PostgreSQL Compatible)

SIH 2025 | Problem Statement SIH25091
"""

DDL_STATEMENTS = [
    # 1. Users
    """
    CREATE TABLE IF NOT EXISTS users (
        user_id TEXT PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        is_active INTEGER DEFAULT 1 NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP NOT NULL,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP NOT NULL
    );
    """,
    # 2. Roles
    """
    CREATE TABLE IF NOT EXISTS roles (
        role_id TEXT PRIMARY KEY,
        role_name TEXT NOT NULL,
        description TEXT
    );
    """,
    # 3. Permissions
    """
    CREATE TABLE IF NOT EXISTS permissions (
        permission_id TEXT PRIMARY KEY,
        module TEXT NOT NULL,
        description TEXT
    );
    """,
    # 4. User Roles Mapping
    """
    CREATE TABLE IF NOT EXISTS user_roles (
        user_id TEXT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
        role_id TEXT NOT NULL REFERENCES roles(role_id) ON DELETE CASCADE,
        assigned_at TEXT DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY (user_id, role_id)
    );
    """,
    # 5. Role Permissions Mapping
    """
    CREATE TABLE IF NOT EXISTS role_permissions (
        role_id TEXT NOT NULL REFERENCES roles(role_id) ON DELETE CASCADE,
        permission_id TEXT NOT NULL REFERENCES permissions(permission_id) ON DELETE CASCADE,
        PRIMARY KEY (role_id, permission_id)
    );
    """,
    # 6. Departments
    """
    CREATE TABLE IF NOT EXISTS departments (
        department_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        code TEXT UNIQUE NOT NULL,
        hod_faculty_id TEXT,
        building TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP NOT NULL
    );
    """,
    # 7. Programmes
    """
    CREATE TABLE IF NOT EXISTS programmes (
        programme_id TEXT PRIMARY KEY,
        department_id TEXT NOT NULL REFERENCES departments(department_id) ON DELETE RESTRICT,
        name TEXT NOT NULL,
        degree_level TEXT NOT NULL,
        total_semesters INTEGER DEFAULT 8 NOT NULL
    );
    """,
    # 8. Semesters
    """
    CREATE TABLE IF NOT EXISTS semesters (
        semester_id TEXT PRIMARY KEY,
        academic_year TEXT NOT NULL,
        term TEXT NOT NULL,
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        is_active INTEGER DEFAULT 0 NOT NULL
    );
    """,
    # 9. Sections (Student Cohorts)
    """
    CREATE TABLE IF NOT EXISTS sections (
        section_id TEXT PRIMARY KEY,
        programme_id TEXT REFERENCES programmes(programme_id) ON DELETE RESTRICT,
        department_id TEXT REFERENCES departments(department_id) ON DELETE RESTRICT,
        semester_number INTEGER NOT NULL,
        name TEXT NOT NULL,
        capacity INTEGER DEFAULT 60 NOT NULL,
        academic_term_id TEXT REFERENCES semesters(semester_id) ON DELETE RESTRICT
    );
    """,
    # 10. Students
    """
    CREATE TABLE IF NOT EXISTS students (
        student_id TEXT PRIMARY KEY,
        user_id TEXT UNIQUE REFERENCES users(user_id) ON DELETE SET NULL,
        roll_number TEXT UNIQUE NOT NULL,
        programme_id TEXT REFERENCES programmes(programme_id) ON DELETE RESTRICT,
        section_id TEXT REFERENCES sections(section_id) ON DELETE RESTRICT,
        admission_year INTEGER NOT NULL,
        current_semester INTEGER NOT NULL
    );
    """,
    # 11. Courses (NEP-2020 Compliant)
    """
    CREATE TABLE IF NOT EXISTS courses (
        course_id TEXT PRIMARY KEY,
        code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        department_id TEXT REFERENCES departments(department_id) ON DELETE RESTRICT,
        nep_category TEXT NOT NULL,
        credits INTEGER DEFAULT 3 NOT NULL,
        sessions_per_week INTEGER DEFAULT 3 NOT NULL,
        required_room_type TEXT DEFAULT 'Classroom' NOT NULL
    );
    """,
    # 12. Student Course Enrollments (Resolves Cross-Department Shared Cohort Clashes)
    """
    CREATE TABLE IF NOT EXISTS enrollments (
        enrollment_id TEXT PRIMARY KEY,
        student_id TEXT NOT NULL REFERENCES students(student_id) ON DELETE CASCADE,
        course_id TEXT NOT NULL REFERENCES courses(course_id) ON DELETE RESTRICT,
        cohort_id TEXT REFERENCES sections(section_id) ON DELETE RESTRICT,
        semester_id TEXT REFERENCES semesters(semester_id) ON DELETE RESTRICT,
        enrolled_at TEXT DEFAULT CURRENT_TIMESTAMP NOT NULL,
        status TEXT DEFAULT 'ACTIVE' NOT NULL,
        UNIQUE (student_id, course_id, semester_id)
    );
    """,
    # 13. Faculty
    """
    CREATE TABLE IF NOT EXISTS faculty (
        faculty_id TEXT PRIMARY KEY,
        user_id TEXT UNIQUE REFERENCES users(user_id) ON DELETE SET NULL,
        name TEXT NOT NULL,
        department_id TEXT REFERENCES departments(department_id) ON DELETE RESTRICT,
        designation TEXT NOT NULL,
        email TEXT,
        max_hours_per_day INTEGER DEFAULT 4 NOT NULL,
        max_hours_per_week INTEGER DEFAULT 16 NOT NULL,
        unavailable_slots TEXT,
        is_active INTEGER DEFAULT 1 NOT NULL
    );
    """,
    # 14. Faculty Availability (Blackouts & Office Hours)
    """
    CREATE TABLE IF NOT EXISTS faculty_availability (
        availability_id TEXT PRIMARY KEY,
        faculty_id TEXT NOT NULL REFERENCES faculty(faculty_id) ON DELETE CASCADE,
        day_of_week TEXT NOT NULL,
        slot_id INTEGER NOT NULL,
        is_available INTEGER DEFAULT 0 NOT NULL,
        reason TEXT,
        UNIQUE (faculty_id, day_of_week, slot_id)
    );
    """,
    # 15. Rooms & Laboratories
    """
    CREATE TABLE IF NOT EXISTS rooms (
        room_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT NOT NULL,
        capacity INTEGER NOT NULL,
        building TEXT NOT NULL,
        floor INTEGER DEFAULT 1 NOT NULL,
        is_active INTEGER DEFAULT 1 NOT NULL
    );
    """,
    # 16. Room Maintenance
    """
    CREATE TABLE IF NOT EXISTS room_maintenance (
        maintenance_id TEXT PRIMARY KEY,
        room_id TEXT NOT NULL REFERENCES rooms(room_id) ON DELETE CASCADE,
        day_of_week TEXT NOT NULL,
        slot_id INTEGER NOT NULL,
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        reason TEXT NOT NULL,
        UNIQUE (room_id, day_of_week, slot_id, start_date)
    );
    """,
    # 17. Curriculum Requirements (Planning Units)
    """
    CREATE TABLE IF NOT EXISTS curriculum_requirements (
        requirement_id TEXT PRIMARY KEY,
        semester_id TEXT REFERENCES semesters(semester_id) ON DELETE RESTRICT,
        group_id TEXT NOT NULL REFERENCES sections(section_id) ON DELETE RESTRICT,
        course_id TEXT NOT NULL REFERENCES courses(course_id) ON DELETE RESTRICT,
        faculty_id TEXT NOT NULL REFERENCES faculty(faculty_id) ON DELETE RESTRICT,
        sessions_per_week INTEGER NOT NULL,
        required_room_type TEXT NOT NULL,
        enrolled_strength INTEGER NOT NULL,
        is_fixed INTEGER DEFAULT 0 NOT NULL
    );
    """,
    # 18. Timetable Versions
    """
    CREATE TABLE IF NOT EXISTS timetable_versions (
        version_id TEXT PRIMARY KEY,
        semester_id TEXT REFERENCES semesters(semester_id) ON DELETE RESTRICT,
        version_number INTEGER NOT NULL,
        title TEXT NOT NULL,
        solver_mode TEXT NOT NULL,
        status TEXT DEFAULT 'DRAFT' NOT NULL,
        quality_score REAL,
        hard_violations INTEGER DEFAULT 0 NOT NULL,
        generated_at TEXT DEFAULT CURRENT_TIMESTAMP NOT NULL,
        published_at TEXT,
        published_by TEXT REFERENCES users(user_id)
    );
    """,
    # 19. Scheduled Sessions
    """
    CREATE TABLE IF NOT EXISTS scheduled_sessions (
        session_id TEXT PRIMARY KEY,
        version_id TEXT NOT NULL REFERENCES timetable_versions(version_id) ON DELETE CASCADE,
        requirement_id TEXT REFERENCES curriculum_requirements(requirement_id) ON DELETE RESTRICT,
        course_id TEXT NOT NULL REFERENCES courses(course_id) ON DELETE RESTRICT,
        group_id TEXT NOT NULL REFERENCES sections(section_id) ON DELETE RESTRICT,
        faculty_id TEXT NOT NULL REFERENCES faculty(faculty_id) ON DELETE RESTRICT,
        room_id TEXT NOT NULL REFERENCES rooms(room_id) ON DELETE RESTRICT,
        session_index INTEGER NOT NULL,
        day_of_week TEXT NOT NULL,
        slot_id INTEGER NOT NULL,
        is_locked INTEGER DEFAULT 0 NOT NULL,
        status TEXT DEFAULT 'ACTIVE' NOT NULL
    );
    """,
    # 20. Ad-Hoc Resource Bookings
    """
    CREATE TABLE IF NOT EXISTS resource_bookings (
        booking_id TEXT PRIMARY KEY,
        room_id TEXT NOT NULL REFERENCES rooms(room_id) ON DELETE RESTRICT,
        booked_by_user_id TEXT REFERENCES users(user_id) ON DELETE SET NULL,
        event_name TEXT NOT NULL,
        booking_date TEXT NOT NULL,
        day_of_week TEXT NOT NULL,
        slot_id INTEGER NOT NULL,
        status TEXT DEFAULT 'PENDING' NOT NULL,
        approved_by TEXT REFERENCES users(user_id),
        UNIQUE (room_id, booking_date, slot_id)
    );
    """,
    # 21. Faculty Absences
    """
    CREATE TABLE IF NOT EXISTS faculty_absences (
        absence_id TEXT PRIMARY KEY,
        faculty_id TEXT NOT NULL REFERENCES faculty(faculty_id) ON DELETE CASCADE,
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        reason TEXT NOT NULL,
        status TEXT DEFAULT 'PENDING' NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP NOT NULL
    );
    """,
    # 22. Substitutions
    """
    CREATE TABLE IF NOT EXISTS substitutions (
        substitution_id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL REFERENCES scheduled_sessions(session_id) ON DELETE CASCADE,
        absence_id TEXT REFERENCES faculty_absences(absence_id) ON DELETE SET NULL,
        original_faculty_id TEXT NOT NULL REFERENCES faculty(faculty_id) ON DELETE RESTRICT,
        substitute_faculty_id TEXT REFERENCES faculty(faculty_id) ON DELETE RESTRICT,
        date TEXT NOT NULL,
        slot_id INTEGER NOT NULL,
        status TEXT DEFAULT 'PROPOSED' NOT NULL,
        match_score REAL,
        confirmed_at TEXT
    );
    """,
    # 23. Makeup Class Requests
    """
    CREATE TABLE IF NOT EXISTS makeup_requests (
        request_id TEXT PRIMARY KEY,
        original_session_id TEXT REFERENCES scheduled_sessions(session_id) ON DELETE SET NULL,
        faculty_id TEXT NOT NULL REFERENCES faculty(faculty_id) ON DELETE RESTRICT,
        group_id TEXT NOT NULL REFERENCES sections(section_id) ON DELETE RESTRICT,
        room_id TEXT NOT NULL REFERENCES rooms(room_id) ON DELETE RESTRICT,
        course_id TEXT NOT NULL REFERENCES courses(course_id) ON DELETE RESTRICT,
        proposed_date TEXT NOT NULL,
        day_of_week TEXT NOT NULL,
        slot_id INTEGER NOT NULL,
        reason TEXT NOT NULL,
        status TEXT DEFAULT 'PENDING' NOT NULL,
        approved_by TEXT REFERENCES users(user_id),
        created_at TEXT DEFAULT CURRENT_TIMESTAMP NOT NULL,
        UNIQUE (room_id, proposed_date, slot_id)
    );
    """,
    # 24. Notifications
    """
    CREATE TABLE IF NOT EXISTS notifications (
        notification_id TEXT PRIMARY KEY,
        recipient_user_id TEXT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        category TEXT NOT NULL,
        is_read INTEGER DEFAULT 0 NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP NOT NULL
    );
    """,
    # 25. Audit Logs
    """
    CREATE TABLE IF NOT EXISTS audit_logs (
        log_id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT REFERENCES users(user_id) ON DELETE SET NULL,
        action TEXT NOT NULL,
        entity_name TEXT NOT NULL,
        entity_id TEXT NOT NULL,
        old_state TEXT,
        new_state TEXT,
        ip_address TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP NOT NULL
    );
    """
]

INDEX_STATEMENTS = [
    "CREATE INDEX IF NOT EXISTS idx_sched_version ON scheduled_sessions(version_id);",
    "CREATE INDEX IF NOT EXISTS idx_sched_faculty ON scheduled_sessions(faculty_id);",
    "CREATE INDEX IF NOT EXISTS idx_sched_group ON scheduled_sessions(group_id);",
    "CREATE INDEX IF NOT EXISTS idx_sched_room ON scheduled_sessions(room_id);",
    "CREATE INDEX IF NOT EXISTS idx_sched_timeslot ON scheduled_sessions(day_of_week, slot_id);",
    "CREATE INDEX IF NOT EXISTS idx_notif_recipient ON notifications(recipient_user_id, is_read);",
    "CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_logs(entity_name, entity_id);",
    "CREATE INDEX IF NOT EXISTS idx_makeup_date ON makeup_requests(proposed_date, slot_id);"
]
