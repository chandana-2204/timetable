"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Database Connection & Transaction Manager with SQLite Foreign Key Enforcement

SIH 2025 | Problem Statement SIH25091
"""

import os
import sqlite3
from typing import Optional
from contextlib import contextmanager
from .schema import DDL_STATEMENTS, INDEX_STATEMENTS

DEFAULT_DB_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "timetable.db"))

class DatabaseConnectionManager:
    """Manages SQLite connections, schema initialization, and transactional boundaries."""

    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path if db_path is not None else DEFAULT_DB_PATH
        self._ensure_initialized()

    def get_connection(self) -> sqlite3.Connection:
        """Create and return a connection with foreign keys and dict-like row factory enabled."""
        conn = sqlite3.connect(self.db_path, timeout=30.0, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        # Non-negotiable database integrity rule:
        conn.execute("PRAGMA foreign_keys = ON;")
        conn.execute("PRAGMA journal_mode = WAL;")
        return conn

    def _ensure_initialized(self):
        """Create tables and indexes if they do not exist."""
        conn = self.get_connection()
        try:
            with conn:
                for ddl in DDL_STATEMENTS:
                    conn.execute(ddl)
                for idx in INDEX_STATEMENTS:
                    conn.execute(idx)
        finally:
            conn.close()

    @contextmanager
    def transaction(self):
        """
        Transactional context manager with immediate write locking (BEGIN IMMEDIATE).
        Guarantees atomic rollback on exception and auto-commit on success.
        """
        conn = self.get_connection()
        try:
            conn.execute("BEGIN IMMEDIATE;")
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

# Global default instance
db_manager = DatabaseConnectionManager()
