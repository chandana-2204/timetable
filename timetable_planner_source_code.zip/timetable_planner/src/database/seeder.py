"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Non-Destructive, Idempotent CSV Data Importer & Database Seeder

SIH 2025 | Problem Statement SIH25091
"""

import os
import pandas as pd
from typing import Dict, Any, List, Optional
from .connection import db_manager, DatabaseConnectionManager
from ..data.loader import TimetableDataLoader, DataValidator

class DatabaseSeeder:
    """Imports existing CSV datasets into normalized relational tables idempotently."""

    def __init__(self, data_dir: Optional[str] = None, db_mgr: Optional[DatabaseConnectionManager] = None):
        if data_dir is None:
            base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
            data_dir = os.path.join(base_dir, "data", "synthetic")
        self.data_dir = data_dir
        self.db_mgr = db_mgr if db_mgr is not None else db_manager

    def seed_all(self) -> Dict[str, Any]:
        """
        Execute topological, transaction-enclosed import of all CSV entities.
        Returns a comprehensive import summary with inserted, skipped, and rejected counts.
        """
        loader = TimetableDataLoader(data_dir=self.data_dir)
        data_dict = loader.load_all()

        # Step 1: Pre-validation of schema and referential integrity
        is_schema_ok, schema_errs = DataValidator.validate_schema(data_dict)
        if not is_schema_ok:
            raise ValueError(f"CSV Schema Validation Failed: {schema_errs}")

        is_ref_ok, ref_errs = DataValidator.validate_referential_integrity(data_dict)
        if not is_ref_ok:
            raise ValueError(f"CSV Referential Integrity Failed: {ref_errs}")

        summary = {
            "departments": {"inserted": 0, "skipped": 0},
            "roles": {"inserted": 0, "skipped": 0},
            "rooms": {"inserted": 0, "skipped": 0},
            "faculty": {"inserted": 0, "skipped": 0},
            "student_groups": {"inserted": 0, "skipped": 0},
            "courses": {"inserted": 0, "skipped": 0},
            "curriculum": {"inserted": 0, "skipped": 0},
            "existing_schedule": {"inserted": 0, "skipped": 0},
            "status": "SUCCESS"
        }

        # Step 2: Atomic Transactional Ingestion in Topological Order
        with self.db_mgr.transaction() as conn:
            # 1. Standard Roles
            roles = [
                ("ADMIN", "System Administrator", "Full access to settings, users, and publishing"),
                ("DEAN", "Academic Dean", "University-wide schedule overview and reports"),
                ("HOD", "Head of Department", "Departmental faculty, course, and absence management"),
                ("FACULTY", "Faculty Member", "Personal schedule, availability, and makeup requests"),
                ("STUDENT", "Student", "Cohort and elective timetable viewer")
            ]
            for rid, rname, rdesc in roles:
                cur = conn.execute("SELECT 1 FROM roles WHERE role_id = ?", (rid,)).fetchone()
                if cur is None:
                    conn.execute("INSERT INTO roles (role_id, role_name, description) VALUES (?, ?, ?)", (rid, rname, rdesc))
                    summary["roles"]["inserted"] += 1
                else:
                    summary["roles"]["skipped"] += 1

            # 2. Departments (Derived from faculty and courses)
            dept_names = {
                "CSE": "Computer Science & Engineering",
                "AI&DS": "Artificial Intelligence & Data Science",
                "Data Science": "Data Science & Analytics",
                "ECE": "Electronics & Communication Engineering",
                "Mathematics": "Department of Mathematics",
                "Physics": "Department of Physics",
                "Chemistry": "Department of Chemistry",
                "Humanities": "Department of Humanities & Social Sciences",
                "Management": "Department of Management Studies",
                "Multidisciplinary": "Multidisciplinary Academic Hub",
                "Skill Hub": "Centre for Skill Enhancement"
            }
            for code, name in dept_names.items():
                cur = conn.execute("SELECT 1 FROM departments WHERE department_id = ?", (code,)).fetchone()
                if cur is None:
                    conn.execute(
                        "INSERT INTO departments (department_id, name, code) VALUES (?, ?, ?)",
                        (code, name, code)
                    )
                    summary["departments"]["inserted"] += 1
                else:
                    summary["departments"]["skipped"] += 1

            # 3. Rooms
            rooms_df = data_dict["rooms"]
            for _, r in rooms_df.iterrows():
                rid = str(r["room_id"])
                cur = conn.execute("SELECT 1 FROM rooms WHERE room_id = ?", (rid,)).fetchone()
                if cur is None:
                    conn.execute(
                        "INSERT INTO rooms (room_id, name, type, capacity, building, floor) VALUES (?, ?, ?, ?, ?, ?)",
                        (rid, str(r.get("name", rid)), str(r["type"]), int(r["capacity"]), str(r.get("building", "Academic Complex")), int(r.get("floor", 1)))
                    )
                    summary["rooms"]["inserted"] += 1
                else:
                    summary["rooms"]["skipped"] += 1

            # 4. Faculty
            faculty_df = data_dict["faculty"]
            for _, f in faculty_df.iterrows():
                fid = str(f["faculty_id"])
                cur = conn.execute("SELECT 1 FROM faculty WHERE faculty_id = ?", (fid,)).fetchone()
                if cur is None:
                    dept = str(f.get("department", "CSE"))
                    conn.execute(
                        """
                        INSERT INTO faculty 
                        (faculty_id, name, department_id, designation, email, max_hours_per_day, max_hours_per_week, unavailable_slots)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (fid, str(f["name"]), dept, str(f["designation"]), str(f.get("email", "")), int(f.get("max_hours_per_day", 4)), int(f.get("max_hours_per_week", 16)), str(f.get("unavailable_slots", "")))
                    )
                    summary["faculty"]["inserted"] += 1
                else:
                    summary["faculty"]["skipped"] += 1

            # 5. Student Groups (Sections)
            groups_df = data_dict["student_groups"]
            for _, g in groups_df.iterrows():
                gid = str(g["group_id"])
                cur = conn.execute("SELECT 1 FROM sections WHERE section_id = ?", (gid,)).fetchone()
                if cur is None:
                    dept = str(g.get("department", "CSE"))
                    conn.execute(
                        "INSERT INTO sections (section_id, department_id, semester_number, name, capacity) VALUES (?, ?, ?, ?, ?)",
                        (gid, dept, int(g.get("semester", 3)), str(g["name"]), int(g["strength"]))
                    )
                    summary["student_groups"]["inserted"] += 1
                else:
                    summary["student_groups"]["skipped"] += 1

            # 6. Courses
            courses_df = data_dict["courses"]
            for _, c in courses_df.iterrows():
                cid = str(c["course_id"])
                cur = conn.execute("SELECT 1 FROM courses WHERE course_id = ?", (cid,)).fetchone()
                if cur is None:
                    dept = str(c.get("department", "CSE"))
                    conn.execute(
                        """
                        INSERT INTO courses 
                        (course_id, code, name, department_id, nep_category, credits, sessions_per_week, required_room_type)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (cid, cid, str(c["name"]), dept, str(c["category"]), int(c.get("credits", 3)), int(c.get("sessions_per_week", 3)), str(c["required_room_type"]))
                    )
                    summary["courses"]["inserted"] += 1
                else:
                    summary["courses"]["skipped"] += 1

            # 7. Curriculum Requirements
            curriculum_df = data_dict["curriculum"]
            for _, cur_row in curriculum_df.iterrows():
                req_id = str(cur_row["curriculum_id"])
                cur = conn.execute("SELECT 1 FROM curriculum_requirements WHERE requirement_id = ?", (req_id,)).fetchone()
                if cur is None:
                    conn.execute(
                        """
                        INSERT INTO curriculum_requirements
                        (requirement_id, group_id, course_id, faculty_id, sessions_per_week, required_room_type, enrolled_strength)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                        """,
                        (req_id, str(cur_row["group_id"]), str(cur_row["course_id"]), str(cur_row["faculty_id"]), int(cur_row["sessions_per_week"]), str(cur_row["required_room_type"]), 50)
                    )
                    summary["curriculum"]["inserted"] += 1
                else:
                    summary["curriculum"]["skipped"] += 1

        return summary
