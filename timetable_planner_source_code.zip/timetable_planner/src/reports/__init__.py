"""Reports package."""
from .service import ReportService

__all__ = ["ReportService"]
