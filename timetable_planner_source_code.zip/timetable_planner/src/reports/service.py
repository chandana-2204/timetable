"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Live Report Data Aggregation Service (Real Data & Verified Backends)

SIH 2025 | Problem Statement SIH25091
"""

from typing import Dict, Any, List, Optional
import pandas as pd
from ..database.connection import db_manager, DatabaseConnectionManager

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
SLOTS = [1, 2, 3, 4, 5, 6, 7]
SLOT_TIMES = {
    1: "09:00–10:00", 2: "10:00–11:00", 3: "11:15–12:15",
    4: "12:15–13:15", 5: "14:00–15:00", 6: "15:00–16:00", 7: "16:00–17:00"
}


class ReportService:
    """Aggregates real timetable data, solver telemetry, and database records into structured report payloads."""

    def __init__(
        self,
        data_dict: Dict[str, Any],
        schedule_records: Optional[List[Dict[str, Any]]] = None,
        db_mgr: Optional[DatabaseConnectionManager] = None
    ):
        self.data_dict = data_dict
        self.records = schedule_records or []
        self.df = pd.DataFrame(self.records) if self.records else pd.DataFrame()
        self.db_mgr = db_mgr or db_manager

    # ─────────────────────────────────────────────────────────────────
    # A. TIMETABLE REPORTS
    # ─────────────────────────────────────────────────────────────────

    def master_timetable(
        self,
        group_id: Optional[str] = None,
        faculty_id: Optional[str] = None,
        room_id: Optional[str] = None,
        day: Optional[str] = None
    ) -> Dict[str, Any]:
        """Return filtered master timetable records with descriptive columns."""
        if self.df.empty:
            return {"records": [], "total_sessions": 0, "summary": "No schedule records available."}

        df = self.df.copy()
        if group_id and group_id != "All":
            df = df[df["group_id"] == group_id]
        if faculty_id and faculty_id != "All":
            df = df[df["faculty_id"] == faculty_id]
        if room_id and room_id != "All":
            df = df[df["room_id"] == room_id]
        if day and day != "All":
            df = df[df["day"] == day]

        cols = [c for c in [
            "day", "slot_id", "time_label", "course_id", "course_name",
            "group_id", "group_name", "faculty_id", "faculty_name",
            "room_id", "room_name", "room_type", "enrolled_strength", "is_fixed"
        ] if c in df.columns]
        display_df = df[cols].sort_values(by=["day", "slot_id"]) if cols else df

        return {
            "records": display_df.to_dict("records"),
            "dataframe": display_df,
            "total_sessions": len(display_df),
            "filters_applied": {
                "group_id": group_id, "faculty_id": faculty_id,
                "room_id": room_id, "day": day
            }
        }

    def grid_timetable(self, entity_type: str, entity_id: str) -> Dict[str, Any]:
        """
        Build day x slot 2D grid matrix for an entity (Section, Faculty, or Room).
        entity_type: 'group' | 'faculty' | 'room'
        """
        grid = {d: {s: None for s in SLOTS} for d in DAYS}
        if self.df.empty:
            return {"grid": grid, "entity_type": entity_type, "entity_id": entity_id, "slot_times": SLOT_TIMES}

        col_map = {"group": "group_id", "faculty": "faculty_id", "room": "room_id"}
        col = col_map.get(entity_type, "group_id")
        sub = self.df[self.df[col] == entity_id]

        for _, r in sub.iterrows():
            d = r.get("day")
            s = int(r.get("slot_id", 0))
            if d in grid and s in grid[d]:
                grid[d][s] = {
                    "course_id": r.get("course_id", ""),
                    "course_name": r.get("course_name", ""),
                    "faculty_id": r.get("faculty_id", ""),
                    "faculty_name": r.get("faculty_name", ""),
                    "group_id": r.get("group_id", ""),
                    "group_name": r.get("group_name", ""),
                    "room_id": r.get("room_id", ""),
                    "room_name": r.get("room_name", r.get("room_id", "")),
                    "is_fixed": bool(r.get("is_fixed", False))
                }

        return {
            "grid": grid,
            "entity_type": entity_type,
            "entity_id": entity_id,
            "total_assigned": len(sub),
            "slot_times": SLOT_TIMES
        }

    # ─────────────────────────────────────────────────────────────────
    # B. SCHEDULING QUALITY REPORTS
    # ─────────────────────────────────────────────────────────────────

    def curriculum_coverage(self) -> Dict[str, Any]:
        """
        Compare required sessions_per_week (from curriculum) with actually
        scheduled sessions per curriculum entry.
        """
        curr_df = self.data_dict.get("curriculum", pd.DataFrame()).copy()
        rows = []
        for _, crow in curr_df.iterrows():
            cid = crow["curriculum_id"]
            gid = crow["group_id"]
            crs = crow["course_id"]
            required = int(crow.get("sessions_per_week", 3))
            if not self.df.empty:
                scheduled = len(self.df[
                    (self.df["curriculum_id"] == cid) if "curriculum_id" in self.df.columns
                    else (self.df["group_id"] == gid) & (self.df["course_id"] == crs)
                ])
            else:
                scheduled = 0
            gap = required - scheduled
            rows.append({
                "curriculum_id": cid,
                "group_id": gid,
                "course_id": crs,
                "faculty_id": crow.get("faculty_id", ""),
                "required_sessions": required,
                "scheduled_sessions": scheduled,
                "gap": gap,
                "status": "✅ Met" if gap == 0 else ("⚠️ Partial" if scheduled > 0 else "❌ Missing")
            })
        fully_met = sum(1 for r in rows if r["gap"] == 0)
        return {
            "rows": rows,
            "total_requirements": len(rows),
            "fully_met": fully_met,
            "partially_met": sum(1 for r in rows if 0 < r["scheduled_sessions"] < r["required_sessions"]),
            "unscheduled": sum(1 for r in rows if r["scheduled_sessions"] == 0),
            "coverage_pct": round(fully_met / max(len(rows), 1) * 100, 1),
        }

    def quality_and_conflict_summary(self, solver_res: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Synthesize algorithmic quality metrics, constraint checks, and violation breakdown."""
        res = solver_res or {}
        assigned = res.get("assigned_sessions", len(self.df))
        total = res.get("total_sessions", len(self.data_dict.get("curriculum", [])))
        if total == 0:
            total = assigned

        penalties = res.get("soft_penalties_breakdown", {})
        penalty_rows = [
            {"Penalty Category": k.replace("_", " ").title(), "Penalty Points": v}
            for k, v in penalties.items()
        ]

        violations = res.get("violations_list", [])
        return {
            "status": res.get("status", "FEASIBLE" if assigned == total else "PARTIAL"),
            "solver_mode": res.get("solver_mode", "CSP Baseline"),
            "assigned_sessions": assigned,
            "total_sessions": total,
            "unassigned_sessions": max(0, total - assigned),
            "completeness_pct": round(assigned / max(total, 1) * 100, 2),
            "quality_score": res.get("quality_score", 85.0),
            "total_soft_penalty": res.get("total_soft_penalty", sum(penalties.values())),
            "execution_time_seconds": res.get("execution_time_seconds", 0.0),
            "backtracks_count": res.get("backtracks_count", 0),
            "nodes_explored": res.get("nodes_explored", 0),
            "forward_checking_prunings": res.get("forward_checking_prunings", 0),
            "constraint_checks": res.get("constraint_checks", 0),
            "hard_violations_count": len(violations),
            "violations_list": violations,
            "penalties_breakdown": penalty_rows,
            "independent_validation_passed": res.get("independent_validation_passed", len(violations) == 0)
        }

    # ─────────────────────────────────────────────────────────────────
    # C. FACULTY WORKLOAD & AVAILABILITY REPORTS
    # ─────────────────────────────────────────────────────────────────

    def faculty_workload_report(self, department: Optional[str] = None) -> Dict[str, Any]:
        """Generate faculty workload distribution, daily loads, and compliance metrics."""
        fac_df = self.data_dict["faculty"].copy()
        if department and department != "All":
            fac_df = fac_df[fac_df["department"] == department]

        rows = []
        for _, f in fac_df.iterrows():
            fid = f["faculty_id"]
            max_w = int(f.get("max_hours_per_week", 16))
            max_d = int(f.get("max_hours_per_day", 4))
            sessions = self.df[self.df["faculty_id"] == fid] if not self.df.empty else pd.DataFrame()
            total_hours = len(sessions)

            daily = {d: 0 for d in DAYS}
            if not sessions.empty and "day" in sessions.columns:
                for d, g in sessions.groupby("day"):
                    if d in daily:
                        daily[d] = len(g)

            is_overloaded = total_hours > max_w or any(v > max_d for v in daily.values())

            rows.append({
                "faculty_id": fid,
                "name": f.get("name", fid),
                "department": f.get("department", ""),
                "designation": f.get("designation", ""),
                "weekly_assigned": total_hours,
                "max_hours_per_week": max_w,
                "max_hours_per_day": max_d,
                "utilization_pct": round(total_hours / max(max_w, 1) * 100, 1),
                "mon": daily["Monday"],
                "tue": daily["Tuesday"],
                "wed": daily["Wednesday"],
                "thu": daily["Thursday"],
                "fri": daily["Friday"],
                "status": "⚠️ Overloaded" if is_overloaded else ("🟢 Normal" if total_hours > 0 else "⚪ Unassigned")
            })

        df_out = pd.DataFrame(rows)
        return {
            "dataframe": df_out,
            "total_faculty": len(rows),
            "active_teaching_faculty": sum(1 for r in rows if r["weekly_assigned"] > 0),
            "overloaded_count": sum(1 for r in rows if "Overloaded" in r["status"]),
            "average_utilization": round(df_out["utilization_pct"].mean(), 1) if not df_out.empty else 0.0
        }

    # ─────────────────────────────────────────────────────────────────
    # D. ROOM UTILIZATION REPORTS
    # ─────────────────────────────────────────────────────────────────

    def room_utilization_report(self, room_type: Optional[str] = None) -> Dict[str, Any]:
        """Calculate exact room utilization across the standard 35 weekly slots."""
        TOTAL_SLOTS = 35 # 5 days * 7 slots
        rooms_df = self.data_dict["rooms"].copy()
        if room_type and room_type != "All":
            rooms_df = rooms_df[rooms_df["type"] == room_type]

        rows = []
        for _, r in rooms_df.iterrows():
            rid = r["room_id"]
            cap = int(r.get("capacity", 0))
            sub = self.df[self.df["room_id"] == rid] if not self.df.empty else pd.DataFrame()
            occupied = len(sub)
            free = TOTAL_SLOTS - occupied

            # Average seat occupancy when room is booked
            avg_students = round(sub["enrolled_strength"].mean(), 1) if not sub.empty and "enrolled_strength" in sub.columns else 0

            rows.append({
                "room_id": rid,
                "name": r.get("name", rid),
                "type": r.get("type", ""),
                "building": r.get("building", ""),
                "capacity": cap,
                "occupied_slots": occupied,
                "free_slots": free,
                "utilization_pct": round(occupied / TOTAL_SLOTS * 100, 1),
                "avg_enrolled": avg_students,
                "seat_fill_rate": round(avg_students / max(cap, 1) * 100, 1) if cap > 0 else 0
            })

        df_out = pd.DataFrame(rows)
        return {
            "dataframe": df_out,
            "total_rooms": len(rows),
            "avg_utilization": round(df_out["utilization_pct"].mean(), 1) if not df_out.empty else 0.0,
            "underutilized_count": sum(1 for r in rows if r["utilization_pct"] < 30.0),
            "high_demand_count": sum(1 for r in rows if r["utilization_pct"] >= 70.0)
        }

    # ─────────────────────────────────────────────────────────────────
    # E. ACADEMIC OPERATIONS REPORTS (FROM DATABASE)
    # ─────────────────────────────────────────────────────────────────

    def operations_audit_report(self) -> Dict[str, Any]:
        """Query real database tables for absences, substitutions, and makeup requests."""
        conn = self.db_mgr.get_connection()
        try:
            # 1. Absences & Substitutions
            absences = conn.execute(
                """
                SELECT a.absence_id, a.faculty_id, f.name as faculty_name, a.start_date, a.end_date, a.reason, a.status,
                       s.substitution_id, s.substitute_faculty_id, sub_f.name as substitute_name, s.status as sub_status, s.match_score
                FROM faculty_absences a
                LEFT JOIN faculty f ON a.faculty_id = f.faculty_id
                LEFT JOIN substitutions s ON a.absence_id = s.absence_id
                LEFT JOIN faculty sub_f ON s.substitute_faculty_id = sub_f.faculty_id
                ORDER BY a.created_at DESC LIMIT 50
                """
            ).fetchall()

            # 2. Makeup Requests
            makeups = conn.execute(
                """
                SELECT m.request_id, m.faculty_id, f.name as faculty_name, m.group_id, m.course_id,
                       m.room_id, r.name as room_name, m.proposed_date, m.day_of_week, m.slot_id,
                       m.reason, m.status, m.approved_by, m.created_at
                FROM makeup_requests m
                LEFT JOIN faculty f ON m.faculty_id = f.faculty_id
                LEFT JOIN rooms r ON m.room_id = r.room_id
                ORDER BY m.created_at DESC LIMIT 50
                """
            ).fetchall()

            # 3. Rescheduling Log
            reschedules = conn.execute(
                """
                SELECT log_id, user_id, action, entity_id, old_state, new_state, created_at
                FROM audit_logs
                WHERE action = 'RESCHEDULE_SESSION'
                ORDER BY created_at DESC LIMIT 50
                """
            ).fetchall()

            return {
                "absences_df": pd.DataFrame([dict(r) for r in absences]),
                "makeups_df": pd.DataFrame([dict(r) for r in makeups]),
                "reschedules_df": pd.DataFrame([dict(r) for r in reschedules]),
                "total_absences": len(absences),
                "total_makeups": len(makeups),
                "total_reschedules": len(reschedules)
            }
        finally:
            conn.close()

    # ─────────────────────────────────────────────────────────────────
    # F. SYSTEM REPORTS (VERSIONS & AUDIT LOGS)
    # ─────────────────────────────────────────────────────────────────

    def system_version_and_audit_report(self) -> Dict[str, Any]:
        """Query real database tables for published timetable versions and security audit logs."""
        conn = self.db_mgr.get_connection()
        try:
            versions = conn.execute(
                """
                SELECT version_id, version_number, title, solver_mode, status, quality_score,
                       hard_violations, generated_at, published_at, published_by
                FROM timetable_versions
                ORDER BY version_number DESC
                """
            ).fetchall()

            audit_logs = conn.execute(
                """
                SELECT log_id, user_id, action, entity_name, entity_id, created_at
                FROM audit_logs
                ORDER BY created_at DESC LIMIT 100
                """
            ).fetchall()

            return {
                "versions_df": pd.DataFrame([dict(r) for r in versions]),
                "audit_logs_df": pd.DataFrame([dict(r) for r in audit_logs]),
                "total_versions": len(versions),
                "total_logs": len(audit_logs)
            }
        finally:
            conn.close()
