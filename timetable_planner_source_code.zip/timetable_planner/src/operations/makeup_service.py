"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Makeup Class Scheduling & Joint-Feasibility Verification Service (P1)

SIH 2025 | Problem Statement SIH25091
"""

import uuid
from typing import Dict, Any, List, Optional, Tuple
from ..database.connection import db_manager, DatabaseConnectionManager
from ..csp.overlap import CohortOverlapManager

class MakeupSchedulingService:
    """
    Manages faculty makeup class requests and performs joint multi-resource feasibility checks
    across rooms, faculty, student cohorts, maintenance windows, and regular lectures.
    """

    def __init__(self, db_mgr: Optional[DatabaseConnectionManager] = None, overlap_mgr: Optional[CohortOverlapManager] = None):
        self.db_mgr = db_mgr if db_mgr is not None else db_manager
        self.overlap_mgr = overlap_mgr

    def evaluate_makeup_feasibility(
        self,
        proposed_date: str,
        day_of_week: str,
        slot_id: int,
        room_id: str,
        faculty_id: str,
        group_id: str,
        course_id: str,
        version_id: Optional[str] = None
    ) -> Tuple[bool, List[str]]:
        """
        Evaluate joint availability across room, faculty, and student cohort.
        Returns: (is_feasible, list_of_conflicts)
        """
        conflicts = []
        conn = self.db_mgr.get_connection()
        try:
            # 1. Room regular lecture collision check
            v_clause = "AND version_id = ?" if version_id else ""
            params = [day_of_week, slot_id, room_id] + ([version_id] if version_id else [])
            
            room_clash = conn.execute(
                f"""
                SELECT session_id, course_id, group_id, faculty_id 
                FROM scheduled_sessions 
                WHERE day_of_week = ? AND slot_id = ? AND room_id = ? AND status = 'ACTIVE' {v_clause}
                """,
                params
            ).fetchone()
            if room_clash is not None:
                conflicts.append(
                    f"Room Conflict: Room {room_id} is already occupied on {day_of_week} Slot {slot_id} "
                    f"by regular course {room_clash['course_id']} (Group {room_clash['group_id']})."
                )

            # 2. Room ad-hoc booking collision check
            booking_clash = conn.execute(
                """
                SELECT event_name FROM resource_bookings
                WHERE room_id = ? AND booking_date = ? AND slot_id = ? AND status = 'APPROVED'
                """,
                (room_id, proposed_date, slot_id)
            ).fetchone()
            if booking_clash is not None:
                conflicts.append(
                    f"Room Event Conflict: Room {room_id} is reserved on {proposed_date} Slot {slot_id} for '{booking_clash['event_name']}'."
                )

            # 3. Room maintenance blackout check
            maint_clash = conn.execute(
                """
                SELECT reason FROM room_maintenance
                WHERE room_id = ? AND day_of_week = ? AND slot_id = ? 
                AND start_date <= ? AND end_date >= ?
                """,
                (room_id, day_of_week, slot_id, proposed_date, proposed_date)
            ).fetchone()
            if maint_clash is not None:
                conflicts.append(
                    f"Room Maintenance Conflict: Room {room_id} is closed for maintenance on {day_of_week} Slot {slot_id} ({maint_clash['reason']})."
                )

            # 4. Faculty regular lecture collision check
            fac_params = [day_of_week, slot_id, faculty_id] + ([version_id] if version_id else [])
            fac_clash = conn.execute(
                f"""
                SELECT session_id, course_id, group_id 
                FROM scheduled_sessions 
                WHERE day_of_week = ? AND slot_id = ? AND faculty_id = ? AND status = 'ACTIVE' {v_clause}
                """,
                fac_params
            ).fetchone()
            if fac_clash is not None:
                conflicts.append(
                    f"Faculty Conflict: Faculty {faculty_id} is already teaching course {fac_clash['course_id']} "
                    f"to Group {fac_clash['group_id']} on {day_of_week} Slot {slot_id}."
                )

            # 5. Faculty absence check
            absence_clash = conn.execute(
                """
                SELECT reason FROM faculty_absences
                WHERE faculty_id = ? AND start_date <= ? AND end_date >= ? AND status != 'CANCELLED'
                """,
                (faculty_id, proposed_date, proposed_date)
            ).fetchone()
            if absence_clash is not None:
                conflicts.append(
                    f"Faculty Absence Conflict: Faculty {faculty_id} is on registered absence on {proposed_date} ({absence_clash['reason']})."
                )

            # 6. Faculty blackout slot adherence
            fac_row = conn.execute("SELECT unavailable_slots FROM faculty WHERE faculty_id = ?", (faculty_id,)).fetchone()
            if fac_row and fac_row["unavailable_slots"]:
                unavail = str(fac_row["unavailable_slots"])
                if f"{day_of_week}:{slot_id}" in unavail:
                    conflicts.append(f"Faculty Availability Conflict: {day_of_week} Slot {slot_id} is in Faculty {faculty_id}'s declared blackout window.")

            # 7. Student group regular lecture collision check
            grp_params = [day_of_week, slot_id, group_id] + ([version_id] if version_id else [])
            grp_clash = conn.execute(
                f"""
                SELECT session_id, course_id, faculty_id 
                FROM scheduled_sessions 
                WHERE day_of_week = ? AND slot_id = ? AND group_id = ? AND status = 'ACTIVE' {v_clause}
                """,
                grp_params
            ).fetchone()
            if grp_clash is not None:
                conflicts.append(
                    f"Student Cohort Conflict: Group {group_id} already has scheduled class {grp_clash['course_id']} on {day_of_week} Slot {slot_id}."
                )

            # 7b. Generalized cohort overlap check
            if self.overlap_mgr is not None:
                active_at_slot = conn.execute(
                    f"SELECT DISTINCT group_id FROM scheduled_sessions WHERE day_of_week = ? AND slot_id = ? AND status = 'ACTIVE' {v_clause}",
                    [day_of_week, slot_id] + ([version_id] if version_id else [])
                ).fetchall()
                active_gids = [r["group_id"] for r in active_at_slot]
                has_clash, clashing_gid = self.overlap_mgr.has_clash_with_active_cohorts(group_id, active_gids)
                if has_clash and clashing_gid != group_id:
                    shared = self.overlap_mgr.get_shared_members(group_id, clashing_gid)
                    conflicts.append(
                        f"Student Overlap Conflict: Group {group_id} shares {len(shared)} students with concurrent group {clashing_gid} on {day_of_week} Slot {slot_id}."
                    )

            # 8. Another approved makeup request at the same room and slot
            existing_makeup = conn.execute(
                """
                SELECT request_id, faculty_id, course_id, group_id 
                FROM makeup_requests 
                WHERE room_id = ? AND proposed_date = ? AND slot_id = ? AND status = 'APPROVED'
                """,
                (room_id, proposed_date, slot_id)
            ).fetchone()
            if existing_makeup is not None:
                conflicts.append(
                    f"Makeup Collision: Room {room_id} has an approved makeup class on {proposed_date} Slot {slot_id} "
                    f"for {existing_makeup['course_id']}."
                )

            # 9. Room capacity compliance
            room_row = conn.execute("SELECT capacity, type FROM rooms WHERE room_id = ?", (room_id,)).fetchone()
            sec_row = conn.execute("SELECT capacity FROM sections WHERE section_id = ?", (group_id,)).fetchone()
            if room_row and sec_row:
                if int(sec_row["capacity"]) > int(room_row["capacity"]):
                    conflicts.append(
                        f"Room Capacity Conflict: Group strength ({sec_row['capacity']}) exceeds Room {room_id} capacity ({room_row['capacity']})."
                    )

            is_feasible = (len(conflicts) == 0)
            return is_feasible, conflicts
        finally:
            conn.close()

    def submit_makeup_request(
        self,
        faculty_id: str,
        group_id: str,
        room_id: str,
        course_id: str,
        proposed_date: str,
        day_of_week: str,
        slot_id: int,
        reason: str,
        original_session_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """Submit and validate a makeup class request."""
        is_feasible, conflicts = self.evaluate_makeup_feasibility(
            proposed_date, day_of_week, slot_id, room_id, faculty_id, group_id, course_id
        )

        request_id = str(uuid.uuid4())
        initial_status = "PENDING"

        with self.db_mgr.transaction() as conn:
            conn.execute(
                """
                INSERT INTO makeup_requests
                (request_id, original_session_id, faculty_id, group_id, room_id, course_id, proposed_date, day_of_week, slot_id, reason, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (request_id, original_session_id, faculty_id, group_id, room_id, course_id, proposed_date, day_of_week, slot_id, reason, initial_status)
            )

        return {
            "request_id": request_id,
            "status": initial_status,
            "is_feasible": is_feasible,
            "conflicts": conflicts
        }

    def approve_makeup_request(self, request_id: str, approver_user_id: str) -> Dict[str, Any]:
        """Approve a makeup request after final re-verification."""
        conn = self.db_mgr.get_connection()
        try:
            req = conn.execute("SELECT * FROM makeup_requests WHERE request_id = ?", (request_id,)).fetchone()
            if req is None:
                raise ValueError(f"Makeup request '{request_id}' not found.")
            if req["status"] == "APPROVED":
                return {"request_id": request_id, "status": "APPROVED", "message": "Already approved."}
        finally:
            conn.close()

        # Re-verify feasibility at approval time
        is_feasible, conflicts = self.evaluate_makeup_feasibility(
            req["proposed_date"], req["day_of_week"], req["slot_id"],
            req["room_id"], req["faculty_id"], req["group_id"], req["course_id"]
        )
        if not is_feasible:
            raise ValueError(f"Cannot approve makeup request due to conflicts: {conflicts}")

        with self.db_mgr.transaction() as conn:
            conn.execute(
                "UPDATE makeup_requests SET status = 'APPROVED', approved_by = ? WHERE request_id = ?",
                (approver_user_id, request_id)
            )

        return {"request_id": request_id, "status": "APPROVED", "message": "Makeup request approved successfully."}
