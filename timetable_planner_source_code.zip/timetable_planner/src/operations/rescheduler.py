"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Localized Single-Session Rescheduling Engine with Transactional Rollback (P1)

SIH 2025 | Problem Statement SIH25091
"""

import json
from typing import Dict, Any, Optional, List, Tuple
from ..database.connection import db_manager, DatabaseConnectionManager
from ..csp.overlap import CohortOverlapManager

class LocalizedRescheduler:
    """
    Reschedules an individual session to a new day, slot, or room atomically
    while preserving all unrelated sessions and guaranteeing zero newly introduced clashes.
    """

    def __init__(self, db_mgr: Optional[DatabaseConnectionManager] = None, overlap_mgr: Optional[CohortOverlapManager] = None):
        self.db_mgr = db_mgr if db_mgr is not None else db_manager
        self.overlap_mgr = overlap_mgr

    def validate_move(
        self,
        session_id: str,
        new_day: str,
        new_slot: int,
        new_room_id: Optional[str] = None
    ) -> Tuple[bool, List[str]]:
        """Verify that moving session_id to (new_day, new_slot, new_room_id) creates zero hard clashes."""
        conflicts = []
        conn = self.db_mgr.get_connection()
        try:
            curr = conn.execute("SELECT * FROM scheduled_sessions WHERE session_id = ?", (session_id,)).fetchone()
            if curr is None:
                raise ValueError(f"Session '{session_id}' does not exist.")

            fid = curr["faculty_id"]
            gid = curr["group_id"]
            cid = curr["course_id"]
            vid = curr["version_id"]
            target_room = new_room_id if new_room_id else curr["room_id"]

            # 1. Room collision at target slot
            room_clash = conn.execute(
                """
                SELECT session_id, course_id, group_id FROM scheduled_sessions
                WHERE version_id = ? AND day_of_week = ? AND slot_id = ? AND room_id = ? 
                AND session_id != ? AND status = 'ACTIVE'
                """,
                (vid, new_day, new_slot, target_room, session_id)
            ).fetchone()
            if room_clash is not None:
                conflicts.append(f"Room {target_room} is occupied by {room_clash['course_id']} (Group {room_clash['group_id']}).")

            # 2. Faculty collision at target slot
            fac_clash = conn.execute(
                """
                SELECT session_id, course_id, group_id FROM scheduled_sessions
                WHERE version_id = ? AND day_of_week = ? AND slot_id = ? AND faculty_id = ?
                AND session_id != ? AND status = 'ACTIVE'
                """,
                (vid, new_day, new_slot, fid, session_id)
            ).fetchone()
            if fac_clash is not None:
                conflicts.append(f"Faculty {fid} is already teaching {fac_clash['course_id']} to Group {fac_clash['group_id']}.")

            # 3. Faculty blackout window check
            fac_row = conn.execute("SELECT unavailable_slots, max_hours_per_day FROM faculty WHERE faculty_id = ?", (fid,)).fetchone()
            if fac_row and fac_row["unavailable_slots"]:
                if f"{new_day}:{new_slot}" in str(fac_row["unavailable_slots"]):
                    conflicts.append(f"Faculty {fid} has a declared blackout at {new_day}:{new_slot}.")

            # 4. Group collision at target slot
            grp_clash = conn.execute(
                """
                SELECT session_id, course_id FROM scheduled_sessions
                WHERE version_id = ? AND day_of_week = ? AND slot_id = ? AND group_id = ?
                AND session_id != ? AND status = 'ACTIVE'
                """,
                (vid, new_day, new_slot, gid, session_id)
            ).fetchone()
            if grp_clash is not None:
                conflicts.append(f"Group {gid} already has scheduled course {grp_clash['course_id']} at this time.")

            # 5. Overlapping cohorts check
            if self.overlap_mgr is not None:
                active_groups = conn.execute(
                    """
                    SELECT DISTINCT group_id FROM scheduled_sessions
                    WHERE version_id = ? AND day_of_week = ? AND slot_id = ? AND session_id != ? AND status = 'ACTIVE'
                    """,
                    (vid, new_day, new_slot, session_id)
                ).fetchall()
                active_gids = [r["group_id"] for r in active_groups]
                has_clash, clashing_gid = self.overlap_mgr.has_clash_with_active_cohorts(gid, active_gids)
                if has_clash and clashing_gid != gid:
                    conflicts.append(f"Group {gid} shares members with active cohort {clashing_gid} at this slot.")

            # 6. Room capacity and type compliance
            room_row = conn.execute("SELECT capacity, type FROM rooms WHERE room_id = ?", (target_room,)).fetchone()
            course_row = conn.execute("SELECT required_room_type FROM courses WHERE course_id = ?", (cid,)).fetchone()
            sec_row = conn.execute("SELECT capacity FROM sections WHERE section_id = ?", (gid,)).fetchone()
            if room_row and sec_row:
                if int(sec_row["capacity"]) > int(room_row["capacity"]):
                    conflicts.append(f"Room {target_room} capacity ({room_row['capacity']}) < enrolled ({sec_row['capacity']}).")
            if room_row and course_row:
                req_t = course_row["required_room_type"]
                if req_t and room_row["type"] != req_t:
                    conflicts.append(f"Course {cid} requires {req_t} but room {target_room} is {room_row['type']}.")

            return (len(conflicts) == 0), conflicts
        finally:
            conn.close()

    def reschedule_session(
        self,
        session_id: str,
        new_day: str,
        new_slot: int,
        new_room_id: Optional[str] = None,
        user_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Execute atomic localized reschedule.
        Throws ValueError and rolls back if any conflict is detected.
        """
        is_valid, conflicts = self.validate_move(session_id, new_day, new_slot, new_room_id)
        if not is_valid:
            raise ValueError(f"Cannot reschedule session {session_id}: {'; '.join(conflicts)}")

        with self.db_mgr.transaction() as conn:
            curr = conn.execute("SELECT * FROM scheduled_sessions WHERE session_id = ?", (session_id,)).fetchone()
            target_room = new_room_id if new_room_id else curr["room_id"]

            old_state = {
                "day_of_week": curr["day_of_week"],
                "slot_id": curr["slot_id"],
                "room_id": curr["room_id"]
            }
            new_state = {
                "day_of_week": new_day,
                "slot_id": new_slot,
                "room_id": target_room
            }

            conn.execute(
                """
                UPDATE scheduled_sessions
                SET day_of_week = ?, slot_id = ?, room_id = ?
                WHERE session_id = ?
                """,
                (new_day, new_slot, target_room, session_id)
            )

            # Audit log
            conn.execute(
                """
                INSERT INTO audit_logs (user_id, action, entity_name, entity_id, old_state, new_state)
                VALUES (?, 'RESCHEDULE_SESSION', 'scheduled_sessions', ?, ?, ?)
                """,
                (user_id, session_id, json.dumps(old_state), json.dumps(new_state))
            )

        return {
            "session_id": session_id,
            "status": "RESCHEDULED",
            "old_state": old_state,
            "new_state": new_state
        }
