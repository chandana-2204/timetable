"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Timetable Version Persistence, Independent Certification & Publishing Service (P1)

SIH 2025 | Problem Statement SIH25091
"""

import uuid
from typing import Dict, Any, List, Optional
from ..database.connection import db_manager, DatabaseConnectionManager
from ..validation.validator import IndependentTimetableValidator
from ..csp.overlap import CohortOverlapManager

class TimetablePublishingService:
    """
    Manages timetable draft persistence, independent certification gates,
    and atomic version publishing while preserving historical revisions.

    Design note on DRAFT storage:
    Drafts may contain resource conflicts (the validator will detect them at publish time).
    save_draft_version uses INSERT OR IGNORE so that sessions conflicting with any existing
    DB-level constraints are stored with status DRAFT_CONFLICT instead of raising an error.
    publish_version reads ALL sessions (ACTIVE and DRAFT_CONFLICT) so the validator sees
    every session and will correctly reject the publish if violations exist.
    """

    def __init__(self, db_mgr: Optional[DatabaseConnectionManager] = None):
        self.db_mgr = db_mgr if db_mgr is not None else db_manager

    def save_draft_version(
        self,
        schedule_records: List[Dict[str, Any]],
        title: str,
        solver_mode: str,
        quality_score: float = 0.0,
        semester_id: Optional[str] = None,
        author_user_id: Optional[str] = None
    ) -> str:
        """Persist a newly solved timetable as an uncertified DRAFT version.

        Conflicting sessions (same room/faculty/group at same time) are stored with
        status DRAFT_CONFLICT so the validator can detect them at publish time.
        """
        version_id = str(uuid.uuid4())

        with self.db_mgr.transaction() as conn:
            # Determine next version number
            last_ver = conn.execute(
                "SELECT MAX(version_number) as max_v FROM timetable_versions"
            ).fetchone()["max_v"]
            next_v = (last_ver or 0) + 1

            conn.execute(
                """
                INSERT INTO timetable_versions
                (version_id, semester_id, version_number, title, solver_mode, status, quality_score, published_by)
                VALUES (?, ?, ?, ?, ?, 'DRAFT', ?, ?)
                """,
                (version_id, semester_id, next_v, title, solver_mode, quality_score, author_user_id)
            )

            # Track already-inserted keys for this draft to detect intra-draft conflicts
            inserted_room_keys = set()   # (day, slot, room_id)
            inserted_faculty_keys = set()  # (day, slot, faculty_id)
            inserted_group_keys = set()    # (day, slot, group_id)

            for rec in schedule_records:
                session_id = str(uuid.uuid4())
                raw_req = rec.get("curriculum_id")
                req_id = None
                if raw_req:
                    chk = conn.execute(
                        "SELECT 1 FROM curriculum_requirements WHERE requirement_id = ?",
                        (raw_req,)
                    ).fetchone()
                    if chk is not None:
                        req_id = raw_req

                day = rec["day"]
                slot = int(rec["slot_id"])
                room_id = rec["room_id"]
                faculty_id = rec["faculty_id"]
                group_id = rec["group_id"]

                room_key = (day, slot, room_id)
                fac_key = (day, slot, faculty_id)
                grp_key = (day, slot, group_id)

                # Detect intra-draft conflicts; store conflicting records with DRAFT_CONFLICT status
                is_conflict = (
                    room_key in inserted_room_keys or
                    fac_key in inserted_faculty_keys or
                    grp_key in inserted_group_keys
                )
                status = "DRAFT_CONFLICT" if is_conflict else "ACTIVE"

                if not is_conflict:
                    inserted_room_keys.add(room_key)
                    inserted_faculty_keys.add(fac_key)
                    inserted_group_keys.add(grp_key)

                conn.execute(
                    """
                    INSERT INTO scheduled_sessions
                    (session_id, version_id, requirement_id, course_id, group_id, faculty_id, room_id,
                     session_index, day_of_week, slot_id, is_locked, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        session_id,
                        version_id,
                        req_id,
                        rec["course_id"],
                        group_id,
                        faculty_id,
                        room_id,
                        int(rec.get("session_number", 1)),
                        day,
                        slot,
                        1 if rec.get("is_fixed") else 0,
                        status
                    )
                )

        return version_id

    def publish_version(
        self,
        version_id: str,
        data_dict: Dict[str, Any],
        publisher_user_id: str,
        overlap_manager: Optional[CohortOverlapManager] = None
    ) -> Dict[str, Any]:
        """
        Validate schedule through IndependentTimetableValidator gate.
        Refuses publication if ANY hard violation exists.
        Atomically archives previous PUBLISHED versions and marks version_id as PUBLISHED.
        """
        conn = self.db_mgr.get_connection()
        try:
            # Include DRAFT_CONFLICT sessions so the validator sees ALL records (including violations)
            sessions = conn.execute(
                """
                SELECT session_id, course_id, group_id, faculty_id, room_id,
                       day_of_week as day, slot_id, is_locked as is_fixed, status
                FROM scheduled_sessions
                WHERE version_id = ? AND status IN ('ACTIVE', 'DRAFT_CONFLICT')
                """,
                (version_id,)
            ).fetchall()

            if not sessions:
                raise ValueError(f"Draft version '{version_id}' has no scheduled sessions.")

            records = [dict(s) for s in sessions]
            rooms_map = data_dict["rooms"].set_index("room_id")
            groups_map = data_dict["student_groups"].set_index("group_id")
            for r in records:
                gid = r["group_id"]
                rid = r["room_id"]
                r["enrolled_strength"] = int(groups_map.loc[gid, "strength"]) if gid in groups_map.index else 50
                r["room_type"] = str(rooms_map.loc[rid, "type"]) if rid in rooms_map.index else "Classroom"
        finally:
            conn.close()

        # Step 2: Strict Independent Certification Gate
        is_passed, violations = IndependentTimetableValidator.validate(
            records, data_dict, overlap_manager=overlap_manager
        )

        if not is_passed:
            raise ValueError(
                f"Cannot publish schedule: Independent validation gate failed with "
                f"{len(violations)} violations: {violations[:3]}"
            )

        # Step 3: Atomic Publishing Transition
        with self.db_mgr.transaction() as conn:
            conn.execute("UPDATE timetable_versions SET status = 'ARCHIVED' WHERE status = 'PUBLISHED'")
            conn.execute(
                """
                UPDATE timetable_versions
                SET status = 'PUBLISHED', published_at = CURRENT_TIMESTAMP, published_by = ?, hard_violations = 0
                WHERE version_id = ?
                """,
                (publisher_user_id, version_id)
            )

        return {
            "version_id": version_id,
            "status": "PUBLISHED",
            "certified": True,
            "total_sessions": len(records),
            "hard_violations": 0
        }

    def get_active_published_timetable(self) -> Optional[Dict[str, Any]]:
        """Retrieve the currently active published timetable and its sessions."""
        conn = self.db_mgr.get_connection()
        try:
            ver = conn.execute(
                "SELECT * FROM timetable_versions WHERE status = 'PUBLISHED' ORDER BY version_number DESC LIMIT 1"
            ).fetchone()
            if ver is None:
                return None

            sessions = conn.execute(
                """
                SELECT s.*, f.name as faculty_name, r.name as room_name, c.name as course_name
                FROM scheduled_sessions s
                LEFT JOIN faculty f ON s.faculty_id = f.faculty_id
                LEFT JOIN rooms r ON s.room_id = r.room_id
                LEFT JOIN courses c ON s.course_id = c.course_id
                WHERE s.version_id = ? AND s.status = 'ACTIVE'
                """,
                (ver["version_id"],)
            ).fetchall()

            return {
                "version": dict(ver),
                "sessions": [dict(s) for s in sessions]
            }
        finally:
            conn.close()
