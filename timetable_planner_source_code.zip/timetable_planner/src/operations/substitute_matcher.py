"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Automated Faculty Substitute Recommendation & Matching Engine (P1)

SIH 2025 | Problem Statement SIH25091
"""

from typing import Dict, Any, List, Optional
from ..database.connection import db_manager, DatabaseConnectionManager

class SubstituteMatcher:
    """
    Ranks and matches qualified, conflict-free substitute faculty members
    for absent sessions based on department competence, daily workload, and availability.
    """

    def __init__(self, db_mgr: Optional[DatabaseConnectionManager] = None):
        self.db_mgr = db_mgr if db_mgr is not None else db_manager

    def find_substitutes(
        self,
        session_id: str,
        target_date: str,
        day_of_week: str,
        slot_id: int
    ) -> List[Dict[str, Any]]:
        """
        Identify and score all conflict-free candidate faculty eligible to cover the session.
        Returns ranked list of eligible substitutes.
        """
        conn = self.db_mgr.get_connection()
        try:
            # 1. Fetch session details
            session = conn.execute(
                """
                SELECT s.session_id, s.course_id, s.faculty_id, s.group_id, c.department_id, c.name as course_name
                FROM scheduled_sessions s
                JOIN courses c ON s.course_id = c.course_id
                WHERE s.session_id = ?
                """,
                (session_id,)
            ).fetchone()

            if session is None:
                raise ValueError(f"Session '{session_id}' not found.")

            orig_faculty_id = session["faculty_id"]
            dept_id = session["department_id"]

            # 2. Query all active faculty except the absent instructor
            all_faculty = conn.execute(
                """
                SELECT faculty_id, name, department_id, designation, max_hours_per_day, max_hours_per_week, unavailable_slots
                FROM faculty
                WHERE is_active = 1 AND faculty_id != ?
                """,
                (orig_faculty_id,)
            ).fetchall()

            candidates = []

            for fac in all_faculty:
                fid = fac["faculty_id"]

                # A. Check blackout slots
                unavail = str(fac["unavailable_slots"] or "")
                if f"{day_of_week}:{slot_id}" in unavail:
                    continue # In blackout slot

                # B. Check existing scheduled classes at this time
                busy = conn.execute(
                    """
                    SELECT 1 FROM scheduled_sessions
                    WHERE faculty_id = ? AND day_of_week = ? AND slot_id = ? AND status = 'ACTIVE'
                    """,
                    (fid, day_of_week, slot_id)
                ).fetchone()
                if busy is not None:
                    continue # Already teaching

                # C. Check registered absences on target_date
                on_leave = conn.execute(
                    """
                    SELECT 1 FROM faculty_absences
                    WHERE faculty_id = ? AND start_date <= ? AND end_date >= ? AND status != 'CANCELLED'
                    """,
                    (fid, target_date, target_date)
                ).fetchone()
                if on_leave is not None:
                    continue # On leave

                # D. Check daily workload ceiling on that day
                curr_daily = conn.execute(
                    """
                    SELECT COUNT(*) as cnt FROM scheduled_sessions
                    WHERE faculty_id = ? AND day_of_week = ? AND status = 'ACTIVE'
                    """,
                    (fid, day_of_week)
                ).fetchone()["cnt"]

                max_daily = fac["max_hours_per_day"]
                if curr_daily >= max_daily:
                    continue # Would exceed daily workload limit

                # E. Calculate competence match score
                score = 50.0 # Base score for being fully available and conflict-free
                reasons = ["Conflict-free at requested time slot", f"Workload within limit ({curr_daily}/{max_daily}h)"]

                if fac["department_id"] == dept_id:
                    score += 35.0
                    reasons.append(f"Same department affiliation ({dept_id})")

                # Check if faculty teaches the same course to another section
                teaches_same = conn.execute(
                    """
                    SELECT 1 FROM curriculum_requirements
                    WHERE faculty_id = ? AND course_id = ?
                    """,
                    (fid, session["course_id"])
                ).fetchone()
                if teaches_same is not None:
                    score += 15.0
                    reasons.append(f"Actively teaches {session['course_id']}")

                candidates.append({
                    "faculty_id": fid,
                    "name": fac["name"],
                    "department": fac["department_id"],
                    "designation": fac["designation"],
                    "current_daily_hours": curr_daily,
                    "max_daily_hours": max_daily,
                    "match_score": round(score, 1),
                    "reasons": reasons
                })

            # Sort descending by match score
            candidates.sort(key=lambda x: x["match_score"], reverse=True)
            return candidates
        finally:
            conn.close()

    def confirm_substitution(
        self,
        session_id: str,
        substitute_faculty_id: str,
        target_date: str,
        slot_id: int,
        authorized_by: str
    ) -> Dict[str, Any]:
        """Authorize and confirm a substitute assignment."""
        with self.db_mgr.transaction() as conn:
            # Verify substitute is still conflict-free
            busy = conn.execute(
                """
                SELECT 1 FROM scheduled_sessions
                WHERE faculty_id = ? AND slot_id = ? AND status = 'ACTIVE'
                """,
                (substitute_faculty_id, slot_id)
            ).fetchone()
            if busy is not None:
                raise ValueError(f"Substitute faculty {substitute_faculty_id} has a conflicting class.")

            conn.execute(
                """
                UPDATE substitutions
                SET substitute_faculty_id = ?, status = 'CONFIRMED', confirmed_at = CURRENT_TIMESTAMP
                WHERE session_id = ? AND date = ?
                """,
                (substitute_faculty_id, session_id, target_date)
            )

        return {
            "session_id": session_id,
            "substitute_faculty_id": substitute_faculty_id,
            "status": "CONFIRMED",
            "date": target_date
        }
