"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Data Generation Module (Synthetic Demonstration Dataset)

SIH 2025 | Problem Statement SIH25091
Team: Gandikota Sai Chandana (12511912) & Inayat (12512142)
Subject Code: K3P25IL
"""

import os
import json
import random
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Any

# Fixed random seed for complete reproducibility
RANDOM_SEED = 42

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
SLOTS = [
    {"slot_id": 1, "time_label": "09:00 - 10:00", "is_peak": False, "is_late": False},
    {"slot_id": 2, "time_label": "10:00 - 11:00", "is_peak": True, "is_late": False},
    {"slot_id": 3, "time_label": "11:15 - 12:15", "is_peak": True, "is_late": False},
    {"slot_id": 4, "time_label": "12:15 - 13:15", "is_peak": True, "is_late": False},
    {"slot_id": 5, "time_label": "14:00 - 15:00", "is_peak": True, "is_late": False},
    {"slot_id": 6, "time_label": "15:00 - 16:00", "is_peak": False, "is_late": False},
    {"slot_id": 7, "time_label": "16:00 - 17:00", "is_peak": False, "is_late": True},
]

ROOM_TYPES = ["LectureHall", "Classroom", "ComputerLab", "ElectronicsLab", "ScienceLab"]
NEP_CATEGORIES = ["Major Core (DSC)", "Minor Elective (DSE)", "Multidisciplinary (MDC)", 
                  "Ability Enhancement (AEC)", "Skill Enhancement (SEC)", "Value-Added (VAC)"]

def generate_courses() -> pd.DataFrame:
    """Generate 26 distinct academic courses under NEP-2020 curriculum guidelines."""
    courses_data = [
        {"course_id": "CS101", "name": "Programming Fundamentals", "category": "Major Core (DSC)", "credits": 4, "required_room_type": "LectureHall", "sessions_per_week": 3, "department": "CSE"},
        {"course_id": "CS102", "name": "Programming Laboratory", "category": "Major Core (DSC)", "credits": 2, "required_room_type": "ComputerLab", "sessions_per_week": 2, "department": "CSE"},
        {"course_id": "CS201", "name": "Data Structures & Algorithms", "category": "Major Core (DSC)", "credits": 4, "required_room_type": "LectureHall", "sessions_per_week": 3, "department": "CSE"},
        {"course_id": "CS202", "name": "Data Structures Laboratory", "category": "Major Core (DSC)", "credits": 2, "required_room_type": "ComputerLab", "sessions_per_week": 2, "department": "CSE"},
        {"course_id": "AI201", "name": "Artificial Intelligence Principles", "category": "Major Core (DSC)", "credits": 4, "required_room_type": "Classroom", "sessions_per_week": 3, "department": "AI&DS"},
        {"course_id": "AI202", "name": "AI & Heuristics Lab", "category": "Major Core (DSC)", "credits": 2, "required_room_type": "ComputerLab", "sessions_per_week": 2, "department": "AI&DS"},
        {"course_id": "DS101", "name": "Statistical Foundations for DS", "category": "Major Core (DSC)", "credits": 4, "required_room_type": "Classroom", "sessions_per_week": 3, "department": "Data Science"},
        {"course_id": "DS102", "name": "Data Science Workbench Lab", "category": "Major Core (DSC)", "credits": 2, "required_room_type": "ComputerLab", "sessions_per_week": 2, "department": "Data Science"},
        {"course_id": "EC101", "name": "Digital Logic & Microcontrollers", "category": "Major Core (DSC)", "credits": 4, "required_room_type": "Classroom", "sessions_per_week": 3, "department": "ECE"},
        {"course_id": "EC102", "name": "Digital Hardware Laboratory", "category": "Major Core (DSC)", "credits": 2, "required_room_type": "ElectronicsLab", "sessions_per_week": 2, "department": "ECE"},
        {"course_id": "MA101", "name": "Linear Algebra & Calculus", "category": "Major Core (DSC)", "credits": 4, "required_room_type": "LectureHall", "sessions_per_week": 3, "department": "Mathematics"},
        {"course_id": "MA201", "name": "Discrete Mathematics & Graph Theory", "category": "Major Core (DSC)", "credits": 3, "required_room_type": "Classroom", "sessions_per_week": 3, "department": "Mathematics"},
        {"course_id": "PH101", "name": "Applied Physics for Engineers", "category": "Major Core (DSC)", "credits": 3, "required_room_type": "Classroom", "sessions_per_week": 2, "department": "Physics"},
        {"course_id": "PH102", "name": "Applied Physics Laboratory", "category": "Major Core (DSC)", "credits": 2, "required_room_type": "ScienceLab", "sessions_per_week": 2, "department": "Physics"},
        {"course_id": "CY101", "name": "Environmental Chemistry", "category": "Major Core (DSC)", "credits": 3, "required_room_type": "Classroom", "sessions_per_week": 2, "department": "Chemistry"},
        {"course_id": "CY102", "name": "Chemical Analysis Laboratory", "category": "Major Core (DSC)", "credits": 2, "required_room_type": "ScienceLab", "sessions_per_week": 2, "department": "Chemistry"},
        {"course_id": "HS101", "name": "Professional Ethics & Human Values", "category": "Value-Added (VAC)", "credits": 2, "required_room_type": "Classroom", "sessions_per_week": 2, "department": "Humanities"},
        {"course_id": "HS201", "name": "Economics of Technology & Markets", "category": "Minor Elective (DSE)", "credits": 3, "required_room_type": "Classroom", "sessions_per_week": 2, "department": "Humanities"},
        {"course_id": "EN101", "name": "Technical Communication & Writing", "category": "Ability Enhancement (AEC)", "credits": 2, "required_room_type": "Classroom", "sessions_per_week": 2, "department": "Humanities"},
        {"course_id": "MG101", "name": "Entrepreneurship & Innovation", "category": "Minor Elective (DSE)", "credits": 3, "required_room_type": "Classroom", "sessions_per_week": 2, "department": "Management"},
        {"course_id": "NEP_MDC01", "name": "Digital Humanities & Culture", "category": "Multidisciplinary (MDC)", "credits": 3, "required_room_type": "Classroom", "sessions_per_week": 2, "department": "Humanities"},
        {"course_id": "NEP_MDC02", "name": "Environmental Tech & Sustainability", "category": "Multidisciplinary (MDC)", "credits": 3, "required_room_type": "Classroom", "sessions_per_week": 2, "department": "Chemistry"},
        {"course_id": "NEP_VAC01", "name": "Universal Human Values & Constitution", "category": "Value-Added (VAC)", "credits": 2, "required_room_type": "LectureHall", "sessions_per_week": 2, "department": "Humanities"},
        {"course_id": "NEP_SEC01", "name": "Python for Data Visualization", "category": "Skill Enhancement (SEC)", "credits": 2, "required_room_type": "ComputerLab", "sessions_per_week": 2, "department": "CSE"},
        {"course_id": "NEP_SEC02", "name": "Cloud Foundations & DevOps", "category": "Skill Enhancement (SEC)", "credits": 2, "required_room_type": "ComputerLab", "sessions_per_week": 2, "department": "AI&DS"},
        {"course_id": "NEP_AEC01", "name": "Modern Scientific Communication", "category": "Ability Enhancement (AEC)", "credits": 2, "required_room_type": "Classroom", "sessions_per_week": 2, "department": "Humanities"},
    ]
    return pd.DataFrame(courses_data)

def generate_faculty() -> pd.DataFrame:
    """Generate 20 faculty profiles with realistic constraints, departments, and designations."""
    random.seed(RANDOM_SEED)
    faculty_specs = [
        ("FAC01", "Dr. Rajesh Raman", "CSE", "Professor", 16, 4, ["Monday:1", "Friday:7"]),
        ("FAC02", "Dr. Sunita Sharma", "CSE", "Associate Professor", 18, 4, ["Wednesday:6", "Wednesday:7"]),
        ("FAC03", "Prof. Amit Verma", "CSE", "Assistant Professor", 18, 4, ["Tuesday:1"]),
        ("FAC04", "Dr. Kavita Nair", "AI&DS", "Associate Professor", 16, 4, ["Thursday:1", "Thursday:2"]),
        ("FAC05", "Prof. Rohan Sengupta", "AI&DS", "Assistant Professor", 18, 4, ["Monday:7"]),
        ("FAC06", "Dr. Priya Deshmukh", "Data Science", "Professor", 15, 3, ["Tuesday:7", "Friday:1"]),
        ("FAC07", "Prof. Manoj Kulkarni", "Data Science", "Assistant Professor", 18, 4, ["Wednesday:1"]),
        ("FAC08", "Dr. Suresh Menon", "ECE", "Professor", 16, 4, ["Monday:1", "Monday:2"]),
        ("FAC09", "Prof. Ananya Roy", "ECE", "Assistant Professor", 18, 4, ["Thursday:6", "Thursday:7"]),
        ("FAC10", "Dr. Harish Patel", "Mathematics", "Associate Professor", 18, 4, ["Friday:6", "Friday:7"]),
        ("FAC11", "Prof. Meera Swaminathan", "Mathematics", "Assistant Professor", 18, 4, ["Tuesday:6"]),
        ("FAC12", "Dr. Vikram Joshi", "Physics", "Associate Professor", 16, 4, ["Wednesday:1"]),
        ("FAC13", "Prof. Deepa Bhattacharya", "Physics", "Assistant Professor", 18, 4, ["Monday:6"]),
        ("FAC14", "Dr. Sanjay Mukherjee", "Chemistry", "Professor", 16, 4, ["Thursday:1"]),
        ("FAC15", "Prof. Ritu Agarwal", "Chemistry", "Assistant Professor", 18, 4, ["Tuesday:7"]),
        ("FAC16", "Dr. Gautam Sen", "Humanities", "Associate Professor", 16, 4, ["Friday:1"]),
        ("FAC17", "Prof. Sneha Pillai", "Humanities", "Assistant Professor", 18, 4, ["Wednesday:7"]),
        ("FAC18", "Dr. Ashok Sundaram", "Management", "Associate Professor", 16, 3, ["Monday:7", "Tuesday:1"]),
        ("FAC19", "Prof. Neha Gupta", "CSE", "Assistant Professor", 18, 4, ["Thursday:7"]),
        ("FAC20", "Prof. Arvind Rao", "AI&DS", "Assistant Professor", 18, 4, ["Friday:7"]),
    ]
    
    records = []
    for fid, name, dept, desig, max_w, max_d, unavail in faculty_specs:
        records.append({
            "faculty_id": fid,
            "name": name,
            "department": dept,
            "designation": desig,
            "max_hours_per_week": max_w,
            "max_hours_per_day": max_d,
            "unavailable_slots": ";".join(unavail),
            "email": f"{fid.lower()}@university.edu.in"
        })
    return pd.DataFrame(records)

def generate_rooms() -> pd.DataFrame:
    """Generate 14 academic rooms and laboratories with capacity and equipment specs."""
    rooms_data = [
        {"room_id": "ROOM_LH101", "name": "Sir C.V. Raman Auditorium", "type": "LectureHall", "capacity": 120, "building": "Academic Block A", "floor": 1},
        {"room_id": "ROOM_LH102", "name": "Dr. A.P.J. Abdul Kalam Hall", "type": "LectureHall", "capacity": 100, "building": "Academic Block A", "floor": 1},
        {"room_id": "ROOM_CR201", "name": "Classroom 201", "type": "Classroom", "capacity": 65, "building": "Academic Block B", "floor": 2},
        {"room_id": "ROOM_CR202", "name": "Classroom 202", "type": "Classroom", "capacity": 60, "building": "Academic Block B", "floor": 2},
        {"room_id": "ROOM_CR203", "name": "Classroom 203", "type": "Classroom", "capacity": 60, "building": "Academic Block B", "floor": 2},
        {"room_id": "ROOM_CR204", "name": "Classroom 204", "type": "Classroom", "capacity": 55, "building": "Academic Block B", "floor": 2},
        {"room_id": "ROOM_CR205", "name": "Seminar Room 205", "type": "Classroom", "capacity": 50, "building": "Academic Block B", "floor": 2},
        {"room_id": "ROOM_CL301", "name": "Alan Turing Computer Lab", "type": "ComputerLab", "capacity": 60, "building": "Computing Complex", "floor": 3},
        {"room_id": "ROOM_CL302", "name": "Ada Lovelace Computing Lab", "type": "ComputerLab", "capacity": 60, "building": "Computing Complex", "floor": 3},
        {"room_id": "ROOM_CL303", "name": "Data Analytics Sandbox Lab", "type": "ComputerLab", "capacity": 55, "building": "Computing Complex", "floor": 3},
        {"room_id": "ROOM_EL401", "name": "VLSI & Embedded Systems Lab", "type": "ElectronicsLab", "capacity": 55, "building": "Engineering Block", "floor": 4},
        {"room_id": "ROOM_EL402", "name": "Signals & IoT Hardware Lab", "type": "ElectronicsLab", "capacity": 55, "building": "Engineering Block", "floor": 4},
        {"room_id": "ROOM_SL501", "name": "Applied Physics Laboratory", "type": "ScienceLab", "capacity": 60, "building": "Science Complex", "floor": 5},
        {"room_id": "ROOM_SL502", "name": "Applied Chemistry Laboratory", "type": "ScienceLab", "capacity": 60, "building": "Science Complex", "floor": 5},
    ]
    return pd.DataFrame(rooms_data)

def generate_student_groups() -> pd.DataFrame:
    """Generate 10 student groups across multidisciplinary disciplines."""
    groups_data = [
        {"group_id": "GRP_CSE_A", "name": "B.Tech CSE - Section A", "strength": 55, "department": "CSE", "semester": 3},
        {"group_id": "GRP_CSE_B", "name": "B.Tech CSE - Section B", "strength": 52, "department": "CSE", "semester": 3},
        {"group_id": "GRP_AIDS_A", "name": "B.Tech AI & Data Science", "strength": 48, "department": "AI&DS", "semester": 3},
        {"group_id": "GRP_DS_A", "name": "B.Sc Data Science & Analytics", "strength": 42, "department": "Data Science", "semester": 3},
        {"group_id": "GRP_ECE_A", "name": "B.Tech ECE - Section A", "strength": 40, "department": "ECE", "semester": 3},
        {"group_id": "GRP_ECE_B", "name": "B.Tech ECE - Section B", "strength": 38, "department": "ECE", "semester": 3},
        {"group_id": "GRP_MDC_B1", "name": "Multidisciplinary Cohort B1 (CSE/ECE)", "strength": 35, "department": "Multidisciplinary", "semester": 3},
        {"group_id": "GRP_MDC_B2", "name": "Multidisciplinary Cohort B2 (DS/AI)", "strength": 32, "department": "Multidisciplinary", "semester": 3},
        {"group_id": "GRP_SEC_01", "name": "Skill Enhancement Cohort Python", "strength": 30, "department": "Skill Hub", "semester": 3},
        {"group_id": "GRP_VAC_01", "name": "Value-Added Ethics Cohort", "strength": 28, "department": "Humanities", "semester": 3},
    ]
    return pd.DataFrame(groups_data)

def generate_curriculum_mapping() -> pd.DataFrame:
    """
    Map student groups to courses, assigned primary faculty, and required weekly sessions.
    This defines the full set of session variables that the CSP engine must allocate.
    """
    curriculum_records = [
        # GRP_CSE_A (Core + Labs + Math + MDC)
        {"curriculum_id": "CUR_01", "group_id": "GRP_CSE_A", "course_id": "CS101", "faculty_id": "FAC01", "sessions_per_week": 3, "required_room_type": "LectureHall"},
        {"curriculum_id": "CUR_02", "group_id": "GRP_CSE_A", "course_id": "CS102", "faculty_id": "FAC03", "sessions_per_week": 2, "required_room_type": "ComputerLab"},
        {"curriculum_id": "CUR_03", "group_id": "GRP_CSE_A", "course_id": "MA101", "faculty_id": "FAC10", "sessions_per_week": 3, "required_room_type": "LectureHall"},
        {"curriculum_id": "CUR_04", "group_id": "GRP_CSE_A", "course_id": "PH101", "faculty_id": "FAC12", "sessions_per_week": 2, "required_room_type": "Classroom"},
        {"curriculum_id": "CUR_05", "group_id": "GRP_CSE_A", "course_id": "PH102", "faculty_id": "FAC13", "sessions_per_week": 2, "required_room_type": "ScienceLab"},
        {"curriculum_id": "CUR_06", "group_id": "GRP_CSE_A", "course_id": "NEP_MDC01", "faculty_id": "FAC16", "sessions_per_week": 2, "required_room_type": "Classroom"},
        {"curriculum_id": "CUR_07", "group_id": "GRP_CSE_A", "course_id": "EN101", "faculty_id": "FAC17", "sessions_per_week": 2, "required_room_type": "Classroom"},

        # GRP_CSE_B (Core + Labs + Math + SEC)
        {"curriculum_id": "CUR_08", "group_id": "GRP_CSE_B", "course_id": "CS101", "faculty_id": "FAC02", "sessions_per_week": 3, "required_room_type": "LectureHall"},
        {"curriculum_id": "CUR_09", "group_id": "GRP_CSE_B", "course_id": "CS102", "faculty_id": "FAC19", "sessions_per_week": 2, "required_room_type": "ComputerLab"},
        {"curriculum_id": "CUR_10", "group_id": "GRP_CSE_B", "course_id": "MA101", "faculty_id": "FAC11", "sessions_per_week": 3, "required_room_type": "Classroom"},
        {"curriculum_id": "CUR_11", "group_id": "GRP_CSE_B", "course_id": "CY101", "faculty_id": "FAC14", "sessions_per_week": 2, "required_room_type": "Classroom"},
        {"curriculum_id": "CUR_12", "group_id": "GRP_CSE_B", "course_id": "CY102", "faculty_id": "FAC15", "sessions_per_week": 2, "required_room_type": "ScienceLab"},
        {"curriculum_id": "CUR_13", "group_id": "GRP_CSE_B", "course_id": "NEP_SEC01", "faculty_id": "FAC03", "sessions_per_week": 2, "required_room_type": "ComputerLab"},
        {"curriculum_id": "CUR_14", "group_id": "GRP_CSE_B", "course_id": "HS101", "faculty_id": "FAC16", "sessions_per_week": 2, "required_room_type": "Classroom"},

        # GRP_AIDS_A (AI Core + AI Lab + Discrete Math + Cloud)
        {"curriculum_id": "CUR_15", "group_id": "GRP_AIDS_A", "course_id": "AI201", "faculty_id": "FAC04", "sessions_per_week": 3, "required_room_type": "Classroom"},
        {"curriculum_id": "CUR_16", "group_id": "GRP_AIDS_A", "course_id": "AI202", "faculty_id": "FAC05", "sessions_per_week": 2, "required_room_type": "ComputerLab"},
        {"curriculum_id": "CUR_17", "group_id": "GRP_AIDS_A", "course_id": "MA201", "faculty_id": "FAC10", "sessions_per_week": 3, "required_room_type": "Classroom"},
        {"curriculum_id": "CUR_18", "group_id": "GRP_AIDS_A", "course_id": "NEP_SEC02", "faculty_id": "FAC20", "sessions_per_week": 2, "required_room_type": "ComputerLab"},
        {"curriculum_id": "CUR_19", "group_id": "GRP_AIDS_A", "course_id": "HS201", "faculty_id": "FAC18", "sessions_per_week": 2, "required_room_type": "Classroom"},
        {"curriculum_id": "CUR_20", "group_id": "GRP_AIDS_A", "course_id": "CS201", "faculty_id": "FAC02", "sessions_per_week": 3, "required_room_type": "LectureHall"},

        # GRP_DS_A (Data Science Core + Workbench Lab + Python + Stats)
        {"curriculum_id": "CUR_21", "group_id": "GRP_DS_A", "course_id": "DS101", "faculty_id": "FAC06", "sessions_per_week": 3, "required_room_type": "Classroom"},
        {"curriculum_id": "CUR_22", "group_id": "GRP_DS_A", "course_id": "DS102", "faculty_id": "FAC07", "sessions_per_week": 2, "required_room_type": "ComputerLab"},
        {"curriculum_id": "CUR_23", "group_id": "GRP_DS_A", "course_id": "MA201", "faculty_id": "FAC11", "sessions_per_week": 3, "required_room_type": "Classroom"},
        {"curriculum_id": "CUR_24", "group_id": "GRP_DS_A", "course_id": "NEP_MDC02", "faculty_id": "FAC14", "sessions_per_week": 2, "required_room_type": "Classroom"},
        {"curriculum_id": "CUR_25", "group_id": "GRP_DS_A", "course_id": "EN101", "faculty_id": "FAC17", "sessions_per_week": 2, "required_room_type": "Classroom"},

        # GRP_ECE_A (Digital Logic + Hardware Lab + Calculus + Entrepreneurship)
        {"curriculum_id": "CUR_26", "group_id": "GRP_ECE_A", "course_id": "EC101", "faculty_id": "FAC08", "sessions_per_week": 3, "required_room_type": "Classroom"},
        {"curriculum_id": "CUR_27", "group_id": "GRP_ECE_A", "course_id": "EC102", "faculty_id": "FAC09", "sessions_per_week": 2, "required_room_type": "ElectronicsLab"},
        {"curriculum_id": "CUR_28", "group_id": "GRP_ECE_A", "course_id": "MA101", "faculty_id": "FAC10", "sessions_per_week": 3, "required_room_type": "LectureHall"},
        {"curriculum_id": "CUR_29", "group_id": "GRP_ECE_A", "course_id": "MG101", "faculty_id": "FAC18", "sessions_per_week": 2, "required_room_type": "Classroom"},
        {"curriculum_id": "CUR_30", "group_id": "GRP_ECE_A", "course_id": "PH101", "faculty_id": "FAC12", "sessions_per_week": 2, "required_room_type": "Classroom"},

        # GRP_ECE_B (Digital Logic + Hardware Lab + Discrete Math + VAC)
        {"curriculum_id": "CUR_31", "group_id": "GRP_ECE_B", "course_id": "EC101", "faculty_id": "FAC08", "sessions_per_week": 3, "required_room_type": "Classroom"},
        {"curriculum_id": "CUR_32", "group_id": "GRP_ECE_B", "course_id": "EC102", "faculty_id": "FAC09", "sessions_per_week": 2, "required_room_type": "ElectronicsLab"},
        {"curriculum_id": "CUR_33", "group_id": "GRP_ECE_B", "course_id": "MA201", "faculty_id": "FAC11", "sessions_per_week": 3, "required_room_type": "Classroom"},
        {"curriculum_id": "CUR_34", "group_id": "GRP_ECE_B", "course_id": "NEP_VAC01", "faculty_id": "FAC16", "sessions_per_week": 2, "required_room_type": "LectureHall"},

        # Multidisciplinary & Open Elective Cohorts
        {"curriculum_id": "CUR_35", "group_id": "GRP_MDC_B1", "course_id": "NEP_MDC01", "faculty_id": "FAC16", "sessions_per_week": 2, "required_room_type": "Classroom"},
        {"curriculum_id": "CUR_36", "group_id": "GRP_MDC_B2", "course_id": "NEP_MDC02", "faculty_id": "FAC15", "sessions_per_week": 2, "required_room_type": "Classroom"},
        {"curriculum_id": "CUR_37", "group_id": "GRP_SEC_01", "course_id": "NEP_SEC01", "faculty_id": "FAC03", "sessions_per_week": 2, "required_room_type": "ComputerLab"},
        {"curriculum_id": "CUR_38", "group_id": "GRP_VAC_01", "course_id": "NEP_VAC01", "faculty_id": "FAC16", "sessions_per_week": 2, "required_room_type": "LectureHall"},
    ]
    return pd.DataFrame(curriculum_records)

def generate_existing_schedule() -> pd.DataFrame:
    """
    Generate realistic pre-fixed institutional timetable allocations.
    These simulate university-wide fixed events (e.g. Dean's Colloquium, NSS/Sports)
    that act as immovable hard constraints during scheduling.
    """
    existing_records = [
        {"schedule_id": "FIXED_01", "course_id": "NEP_VAC01", "group_id": "GRP_VAC_01", "faculty_id": "FAC16", "day": "Wednesday", "slot_id": 4, "room_id": "ROOM_LH101", "reason": "Institutional Ethics Colloquium"},
        {"schedule_id": "FIXED_02", "course_id": "CS101", "group_id": "GRP_CSE_A", "faculty_id": "FAC01", "day": "Monday", "slot_id": 2, "room_id": "ROOM_LH101", "reason": "Department Keynote Lecture"},
        {"schedule_id": "FIXED_03", "course_id": "AI201", "group_id": "GRP_AIDS_A", "faculty_id": "FAC04", "day": "Tuesday", "slot_id": 3, "room_id": "ROOM_CR201", "reason": "Industry Guest Lecture Series"},
        {"schedule_id": "FIXED_04", "course_id": "EC101", "group_id": "GRP_ECE_A", "faculty_id": "FAC08", "day": "Thursday", "slot_id": 3, "room_id": "ROOM_CR202", "reason": "Embedded Systems Seminar"},
        {"schedule_id": "FIXED_05", "course_id": "DS101", "group_id": "GRP_DS_A", "faculty_id": "FAC06", "day": "Friday", "slot_id": 2, "room_id": "ROOM_CR203", "reason": "Data Science Research Colloquium"},
    ]
    return pd.DataFrame(existing_records)

def generate_historical_allocations(n_samples: int = 1600) -> pd.DataFrame:
    """
    Generate a balanced, realistic historical dataset of candidate timetable allocations
    for supervised ML classifier training.
    
    Features engineered:
    - day_index (0-4)
    - slot_index (1-7)
    - is_peak_slot (0/1)
    - is_late_slot (0/1)
    - room_capacity_ratio (enrolled / room_capacity)
    - room_type_match (1 if matched, 0 if mismatch)
    - faculty_daily_load_candidate (current load 0-5)
    - faculty_weekly_load_candidate (current cumulative load)
    - faculty_available (1 if available, 0 if unavailable)
    - group_daily_load_candidate (current group load)
    - group_has_window_gap (1 if allocation creates idle hour gap)
    - is_lab_course (0/1)
    - historical_collision_score (float estimate based on slot popularity)
    
    Target:
    - is_conflict (0 = conflict-free feasible assignment, 1 = conflict-prone assignment)
    """
    random.seed(RANDOM_SEED)
    np.random.seed(RANDOM_SEED)
    
    rows = []
    days = list(range(5))
    slots = [s["slot_id"] for s in SLOTS]
    
    # 50% non-conflict, 50% conflict or slight class imbalance (~40% conflict, 60% feasible)
    for i in range(n_samples):
        day_idx = random.choice(days)
        slot_idx = random.choice(slots)
        is_peak = 1 if slot_idx in [2, 3, 4, 5] else 0
        is_late = 1 if slot_idx == 7 else 0
        
        # Room capacity and student count
        enrolled_students = random.randint(30, 65)
        room_capacity = random.choice([45, 50, 55, 60, 65, 100, 120])
        cap_ratio = round(enrolled_students / room_capacity, 3)
        
        # Room type match
        is_lab = random.choice([0, 1])
        room_type_match = 1 if random.random() > 0.15 else 0
        if is_lab and random.random() < 0.20:
            room_type_match = 0
            
        # Faculty parameters
        fac_available = 1 if random.random() > 0.12 else 0
        fac_daily_load = random.randint(0, 5)
        fac_weekly_load = random.randint(4, 20)
        
        # Group parameters
        grp_daily_load = random.randint(1, 6)
        grp_window_gap = 1 if random.random() > 0.65 else 0
        
        # Historical congestion score
        base_congestion = 0.7 if is_peak else 0.3
        historical_collision_score = round(base_congestion + np.random.normal(0, 0.1), 3)
        historical_collision_score = max(0.05, min(0.95, historical_collision_score))
        
        # Determine genuine conflict condition (ground truth based on constraint logic)
        conflict = 0
        if cap_ratio > 1.0: # Hard constraint violation: room too small
            conflict = 1
        elif room_type_match == 0: # Hard constraint violation: room type mismatch
            conflict = 1
        elif fac_available == 0: # Hard constraint violation: faculty not available
            conflict = 1
        elif fac_daily_load >= 4: # Hard constraint violation: faculty max daily hours exceeded
            conflict = 1
        elif grp_daily_load >= 6: # Hard constraint violation: group overload
            conflict = 1
        elif is_peak and historical_collision_score > 0.75 and random.random() < 0.35:
            # High collision probability in peak slots due to concurrent resource demand
            conflict = 1
        else:
            conflict = 0
            
        rows.append({
            "sample_id": f"HIST_{i+1:05d}",
            "day_index": day_idx,
            "slot_index": slot_idx,
            "is_peak_slot": is_peak,
            "is_late_slot": is_late,
            "enrolled_students": enrolled_students,
            "room_capacity": room_capacity,
            "room_capacity_ratio": cap_ratio,
            "room_type_match": room_type_match,
            "is_lab_course": is_lab,
            "faculty_daily_load": fac_daily_load,
            "faculty_weekly_load": fac_weekly_load,
            "faculty_available": fac_available,
            "group_daily_load": grp_daily_load,
            "group_has_window_gap": grp_window_gap,
            "historical_collision_score": historical_collision_score,
            "is_conflict": conflict
        })
        
    return pd.DataFrame(rows)

def create_master_workbook(output_excel_path: str):
    """
    Generate the authoritative 7-sheet master Excel workbook:
    1. Start Here
    2. Courses
    3. Faculty
    4. Rooms
    5. Groups & Slots
    6. Existing Schedule
    7. Data Needed
    """
    courses_df = generate_courses()
    faculty_df = generate_faculty()
    rooms_df = generate_rooms()
    groups_df = generate_student_groups()
    curriculum_df = generate_curriculum_mapping()
    existing_df = generate_existing_schedule()
    
    # 1. Start Here sheet
    start_here_data = [
        {"Attribute": "Project Title", "Value": "NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System"},
        {"Attribute": "Problem Statement ID", "Value": "SIH25091 (Smart India Hackathon 2025)"},
        {"Attribute": "Subject / Section Code", "Value": "K3P25IL"},
        {"Attribute": "Team Member 1", "Value": "Gandikota Sai Chandana (Registration No. 12511912 | Group RK3P25ILA15)"},
        {"Attribute": "Team Member 2", "Value": "Inayat (Registration No. 12512142 | Group RK3P25ILA16)"},
        {"Attribute": "Target Academic Session", "Value": "Autumn Semester 2025-2026 (Under NEP-2020 Curriculum Guidelines)"},
        {"Attribute": "Data Source Statement", "Value": "SYNTHETIC DEMONSTRATION DATASET. Generated algorithmically with fixed random seed 42 to ensure reproducible benchmarking. Not sourced from real institutional PII."},
        {"Attribute": "Total Courses Defined", "Value": f"{len(courses_df)} multidisciplinary courses"},
        {"Attribute": "Total Faculty Profiles", "Value": f"{len(faculty_df)} professors and lecturers"},
        {"Attribute": "Total Rooms & Labs", "Value": f"{len(rooms_df)} lecture halls, classrooms, and labs"},
        {"Attribute": "Total Student Groups", "Value": f"{len(groups_df)} student cohorts across B.Tech, B.Sc, and NEP baskets"},
        {"Attribute": "Scheduling Days", "Value": "5 Days (Monday through Friday)"},
        {"Attribute": "Daily Slots", "Value": "7 slots per day (09:00 - 17:00 with lunch interval)"},
        {"Attribute": "CSP Variable Count", "Value": f"{curriculum_df['sessions_per_week'].sum()} individual weekly course sessions"},
        {"Attribute": "Pre-fixed Allocations", "Value": f"{len(existing_df)} institutional fixed sessions"}
    ]
    start_here_df = pd.DataFrame(start_here_data)
    
    # 5. Groups & Slots combined representation
    slots_df = pd.DataFrame(SLOTS)
    
    # 7. Data Needed sheet
    data_needed_data = [
        {"Parameter": "Curriculum Definition", "Status": "Complete (26 NEP courses, 6 credit categories)", "Validation Rule": "All courses mapped to faculty and room types"},
        {"Parameter": "Room Suitability Mapping", "Status": "Complete (5 distinct room archetypes)", "Validation Rule": "Labs require specialized labs; lectures require halls/rooms"},
        {"Parameter": "Faculty Workload Quotas", "Status": "Complete (Daily max 3-4h, weekly 15-18h)", "Validation Rule": "Hard constraint enforcement prevents burnout"},
        {"Parameter": "Pre-allocated Sessions", "Status": "Complete (5 institutional locked sessions)", "Validation Rule": "Preserved without mutation in CSP search"},
        {"Parameter": "Multidisciplinary Cohorts", "Status": "Complete (MDC, SEC, VAC baskets)", "Validation Rule": "Ensures no overlap between elective blocks and major cores"},
        {"Parameter": "Deterministic Random Seed", "Status": "Enforced (Seed = 42)", "Validation Rule": "Reproducible across baseline and ML solvers"}
    ]
    data_needed_df = pd.DataFrame(data_needed_data)
    
    with pd.ExcelWriter(output_excel_path, engine="openpyxl") as writer:
        start_here_df.to_excel(writer, sheet_name="Start Here", index=False)
        courses_df.to_excel(writer, sheet_name="Courses", index=False)
        faculty_df.to_excel(writer, sheet_name="Faculty", index=False)
        rooms_df.to_excel(writer, sheet_name="Rooms", index=False)
        groups_df.to_excel(writer, sheet_name="Groups & Slots", index=False)
        existing_df.to_excel(writer, sheet_name="Existing Schedule", index=False)
        data_needed_df.to_excel(writer, sheet_name="Data Needed", index=False)
        
    print(f"[Data Generator] Master Excel workbook created at: {output_excel_path}")

def generate_all_datasets(data_dir: str):
    """Generate all individual CSV files and master Excel workbook into target directory."""
    os.makedirs(os.path.join(data_dir, "synthetic"), exist_ok=True)
    os.makedirs(os.path.join(data_dir, "processed"), exist_ok=True)
    
    synthetic_dir = os.path.join(data_dir, "synthetic")
    
    courses_df = generate_courses()
    faculty_df = generate_faculty()
    rooms_df = generate_rooms()
    groups_df = generate_student_groups()
    curriculum_df = generate_curriculum_mapping()
    existing_df = generate_existing_schedule()
    historical_df = generate_historical_allocations(n_samples=1800)
    
    courses_df.to_csv(os.path.join(synthetic_dir, "courses.csv"), index=False)
    faculty_df.to_csv(os.path.join(synthetic_dir, "faculty.csv"), index=False)
    rooms_df.to_csv(os.path.join(synthetic_dir, "rooms.csv"), index=False)
    groups_df.to_csv(os.path.join(synthetic_dir, "student_groups.csv"), index=False)
    curriculum_df.to_csv(os.path.join(synthetic_dir, "curriculum.csv"), index=False)
    existing_df.to_csv(os.path.join(synthetic_dir, "existing_schedule.csv"), index=False)
    historical_df.to_csv(os.path.join(synthetic_dir, "historical_allocations.csv"), index=False)
    
    # Generate master Excel workbook
    excel_path = os.path.join(synthetic_dir, "academic_timetable_data.xlsx")
    create_master_workbook(excel_path)
    
    print(f"[Data Generator] Successfully generated 7 CSVs and master Excel workbook in {synthetic_dir}")

if __name__ == "__main__":
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    data_path = os.path.join(base_dir, "data")
    generate_all_datasets(data_path)
