"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Data Loader and Validator Module

SIH 2025 | Problem Statement SIH25091
Team: Gandikota Sai Chandana (12511912) & Inayat (12512142)
Subject Code: K3P25IL
"""

import os
import pandas as pd
from typing import Dict, List, Tuple, Any, Optional

class TimetableDataLoader:
    """Loads and encapsulates timetable datasets from CSV files or Excel workbooks."""
    
    def __init__(self, data_dir: Optional[str] = None):
        if data_dir is None:
            base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
            data_dir = os.path.join(base_dir, "data", "synthetic")
        self.data_dir = data_dir
        self.courses_df: Optional[pd.DataFrame] = None
        self.faculty_df: Optional[pd.DataFrame] = None
        self.rooms_df: Optional[pd.DataFrame] = None
        self.groups_df: Optional[pd.DataFrame] = None
        self.curriculum_df: Optional[pd.DataFrame] = None
        self.existing_schedule_df: Optional[pd.DataFrame] = None
        self.historical_df: Optional[pd.DataFrame] = None
        
    def load_all(self) -> Dict[str, pd.DataFrame]:
        """Load all core CSV datasets into memory."""
        self.courses_df = pd.read_csv(os.path.join(self.data_dir, "courses.csv"))
        self.faculty_df = pd.read_csv(os.path.join(self.data_dir, "faculty.csv"))
        self.rooms_df = pd.read_csv(os.path.join(self.data_dir, "rooms.csv"))
        self.groups_df = pd.read_csv(os.path.join(self.data_dir, "student_groups.csv"))
        self.curriculum_df = pd.read_csv(os.path.join(self.data_dir, "curriculum.csv"))
        self.existing_schedule_df = pd.read_csv(os.path.join(self.data_dir, "existing_schedule.csv"))
        
        hist_path = os.path.join(self.data_dir, "historical_allocations.csv")
        if os.path.exists(hist_path):
            self.historical_df = pd.read_csv(hist_path)
            
        return {
            "courses": self.courses_df,
            "faculty": self.faculty_df,
            "rooms": self.rooms_df,
            "student_groups": self.groups_df,
            "curriculum": self.curriculum_df,
            "existing_schedule": self.existing_schedule_df,
            "historical_allocations": self.historical_df
        }

    def load_from_excel(self, excel_path: str) -> Dict[str, pd.DataFrame]:
        """Load datasets directly from a 7-sheet master Excel workbook."""
        xls = pd.ExcelFile(excel_path)
        sheet_mapping = {
            "Courses": "courses",
            "Faculty": "faculty",
            "Rooms": "rooms",
            "Groups & Slots": "student_groups",
            "Existing Schedule": "existing_schedule"
        }
        data = {}
        for sheet, key in sheet_mapping.items():
            if sheet in xls.sheet_names:
                data[key] = pd.read_excel(xls, sheet_name=sheet)
        self.courses_df = data.get("courses")
        self.faculty_df = data.get("faculty")
        self.rooms_df = data.get("rooms")
        self.groups_df = data.get("student_groups")
        self.existing_schedule_df = data.get("existing_schedule")
        return data

    def get_summary_metrics(self) -> Dict[str, Any]:
        """Return executive key performance metrics regarding loaded entities."""
        if self.courses_df is None:
            self.load_all()
            
        total_sessions = int(self.curriculum_df["sessions_per_week"].sum()) if self.curriculum_df is not None else 0
        total_capacity = int(self.rooms_df["capacity"].sum()) if self.rooms_df is not None else 0
        total_students = int(self.groups_df["strength"].sum()) if self.groups_df is not None else 0
        
        return {
            "total_courses": len(self.courses_df),
            "total_faculty": len(self.faculty_df),
            "total_rooms": len(self.rooms_df),
            "total_student_groups": len(self.groups_df),
            "total_sessions_required": total_sessions,
            "total_enrolled_students": total_students,
            "total_room_capacity": total_capacity,
            "fixed_allocations_count": len(self.existing_schedule_df) if self.existing_schedule_df is not None else 0
        }

    def get_infeasible_benchmark_instance(self) -> Dict[str, pd.DataFrame]:
        """
        Produce a deliberately infeasible benchmark instance to test CSP backtracking,
        timeout mechanisms, and explainable diagnostic error detection.
        Introduces:
        1. Extreme faculty overload / unavailability clash.
        2. Impossible room capacity constraint.
        3. Excessive session demand for a single room type.
        """
        if self.courses_df is None:
            self.load_all()
            
        inf_curriculum = self.curriculum_df.copy()
        # Create an impossible room requirement (Course requiring capacity 250 when max room is 120)
        inf_courses = self.courses_df.copy()
        inf_courses.loc[inf_courses["course_id"] == "CS101", "required_room_type"] = "ScienceLab"
        
        # Inject deliberate faculty availability collision
        inf_faculty = self.faculty_df.copy()
        # Make FAC01 unavailable on all 5 days slots 1-6
        all_slots = [f"{d}:{s}" for d in ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"] for s in range(1, 8)]
        inf_faculty.loc[inf_faculty["faculty_id"] == "FAC01", "unavailable_slots"] = ";".join(all_slots)
        
        return {
            "courses": inf_courses,
            "faculty": inf_faculty,
            "rooms": self.rooms_df.copy(),
            "student_groups": self.groups_df.copy(),
            "curriculum": inf_curriculum,
            "existing_schedule": self.existing_schedule_df.copy()
        }


class DataValidator:
    """Validates structural integrity, referential integrity, and domain constraints."""
    
    @staticmethod
    def validate_schema(data_dict: Dict[str, pd.DataFrame]) -> Tuple[bool, List[str]]:
        """Validate presence and columns of all required entity DataFrames."""
        errors = []
        required_tables = {
            "courses": ["course_id", "name", "category", "credits", "required_room_type", "sessions_per_week"],
            "faculty": ["faculty_id", "name", "department", "max_hours_per_day", "unavailable_slots"],
            "rooms": ["room_id", "type", "capacity"],
            "student_groups": ["group_id", "name", "strength"],
            "curriculum": ["curriculum_id", "group_id", "course_id", "faculty_id", "sessions_per_week", "required_room_type"],
            "existing_schedule": ["schedule_id", "course_id", "group_id", "faculty_id", "day", "slot_id", "room_id"]
        }
        
        for table_name, req_cols in required_tables.items():
            if table_name not in data_dict or data_dict[table_name] is None:
                errors.append(f"Missing mandatory table: '{table_name}'")
                continue
            df = data_dict[table_name]
            for col in req_cols:
                if col not in df.columns:
                    errors.append(f"Table '{table_name}' missing required column: '{col}'")
                    
        return (len(errors) == 0), errors

    @staticmethod
    def validate_referential_integrity(data_dict: Dict[str, pd.DataFrame]) -> Tuple[bool, List[str]]:
        """Check all foreign keys across curriculum and existing schedules."""
        errors = []
        courses_ids = set(data_dict["courses"]["course_id"].unique())
        faculty_ids = set(data_dict["faculty"]["faculty_id"].unique())
        rooms_ids = set(data_dict["rooms"]["room_id"].unique())
        groups_ids = set(data_dict["student_groups"]["group_id"].unique())
        
        # Check curriculum
        curriculum = data_dict["curriculum"]
        for idx, row in curriculum.iterrows():
            cid = row["curriculum_id"]
            if row["course_id"] not in courses_ids:
                errors.append(f"Curriculum {cid}: Unknown course_id '{row['course_id']}'")
            if row["faculty_id"] not in faculty_ids:
                errors.append(f"Curriculum {cid}: Unknown faculty_id '{row['faculty_id']}'")
            if row["group_id"] not in groups_ids:
                errors.append(f"Curriculum {cid}: Unknown group_id '{row['group_id']}'")
                
        # Check existing schedule
        existing = data_dict["existing_schedule"]
        for idx, row in existing.iterrows():
            sid = row["schedule_id"]
            if row["course_id"] not in courses_ids:
                errors.append(f"Existing schedule {sid}: Unknown course_id '{row['course_id']}'")
            if row["faculty_id"] not in faculty_ids:
                errors.append(f"Existing schedule {sid}: Unknown faculty_id '{row['faculty_id']}'")
            if row["room_id"] not in rooms_ids:
                errors.append(f"Existing schedule {sid}: Unknown room_id '{row['room_id']}'")
            if row["group_id"] not in groups_ids:
                errors.append(f"Existing schedule {sid}: Unknown group_id '{row['group_id']}'")
                
        return (len(errors) == 0), errors
