"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Verified Backend Tools Registry & Metadata Definition

Every registered tool maps directly to an active backend service, function, or engine.
No placeholders. No simulated tools.

SIH 2025 | Problem Statement SIH25091
"""

from typing import Dict, Any, List

TOOL_CATALOG: List[Dict[str, Any]] = [
    # ── CATEGORY A: TIMETABLE GENERATION ──
    {
        "id": "tool_csp_solver",
        "category": "Timetable Generation",
        "name": "CSP Heuristic Scheduling Engine",
        "tagline": "Generates complete academic timetable using MRV, Degree, LCV & Forward Checking heuristics.",
        "purpose": "Solves multi-variable constraint satisfaction problem to allocate all course sessions without conflicts.",
        "problem_solved": "Eliminates manual scheduling bottlenecks and prevents room, faculty, or student double-bookings.",
        "required_inputs": [
            {"name": "solver_mode", "label": "Search Strategy", "type": "select", "options": ["Baseline CSP (MRV+Degree+LCV)", "ML-Assisted CSP (Guided)"], "default": "Baseline CSP (MRV+Degree+LCV)"},
            {"name": "max_backtracks", "label": "Max Backtracks Allowed", "type": "slider", "min": 500, "max": 5000, "default": 2500, "step": 250},
            {"name": "timeout_seconds", "label": "Timeout Limit (seconds)", "type": "slider", "min": 5.0, "max": 60.0, "default": 20.0, "step": 5.0},
            {"name": "enable_forward_checking", "label": "Forward Checking Domain Pruning", "type": "checkbox", "default": True}
        ],
        "backend_function": "src.csp.solver.TimetableCSPSolver.solve()",
        "expected_result": "Complete or partial timetable schedule records with execution telemetry and soft-penalty breakdown.",
        "modifies_data": True,
        "requires_approval": False,
        "allowed_roles": ["ADMIN", "DEAN"],
        "status": "Working",
        "icon": "🚀"
    },
    {
        "id": "tool_cpsat_solver",
        "category": "Timetable Generation",
        "name": "OR-Tools CP-SAT Mathematical Optimizer",
        "tagline": "Proves global optimality or returns optimal feasible bounds using Google OR-Tools CP-SAT.",
        "purpose": "Applies integer constraint programming with soft-penalty objective optimization.",
        "problem_solved": "Guarantees optimal mathematical minimization of gaps, daily spread, and room archetype mismatches.",
        "required_inputs": [
            {"name": "time_limit_seconds", "label": "Time Limit (seconds)", "type": "slider", "min": 5.0, "max": 60.0, "default": 15.0, "step": 5.0},
            {"name": "num_workers", "label": "Parallel Worker Threads", "type": "slider", "min": 1, "max": 8, "default": 4, "step": 1}
        ],
        "backend_function": "src.solver.ortools_solver.TimetableCPSATSolver.solve()",
        "expected_result": "Certified optimal or feasible schedule with objective cost value, best bound, and solve status.",
        "modifies_data": True,
        "requires_approval": False,
        "allowed_roles": ["ADMIN", "DEAN"],
        "status": "Working",
        "icon": "⚡"
    },
    {
        "id": "tool_publish_gate",
        "category": "Timetable Generation",
        "name": "Certification Gate & Version Publisher",
        "tagline": "Submits draft timetable through independent validator; publishes atomically if 0 violations exist.",
        "purpose": "Prevents invalid or conflicting schedules from being published to students and faculty.",
        "problem_solved": "Safeguards production integrity by enforcing zero-tolerance certification before publication.",
        "required_inputs": [
            {"name": "title", "label": "Schedule Title / Release Name", "type": "text", "default": "Official Monsoon Semester Timetable v1"},
            {"name": "publisher_id", "label": "Authorizing User ID", "type": "text", "default": "ADMIN"}
        ],
        "backend_function": "src.operations.publishing_service.TimetablePublishingService.publish_version()",
        "expected_result": "Published timetable version record with certified status, archiving previous active releases.",
        "modifies_data": True,
        "requires_approval": True,
        "allowed_roles": ["ADMIN", "DEAN"],
        "status": "Working",
        "icon": "🛡️"
    },

    # ── CATEGORY B: TIMETABLE VALIDATION ──
    {
        "id": "tool_independent_validator",
        "category": "Timetable Validation",
        "name": "Independent Hard-Constraint Validator",
        "tagline": "Audits active schedule against all 10 mandatory NEP-2020 constraints and cohort overlaps.",
        "purpose": "Provides external, objective verification independent of solver heuristic internals.",
        "problem_solved": "Catches room double-bookings, faculty clashes, capacity breaches, and blackout slot violations.",
        "required_inputs": [
            {"name": "check_fixed", "label": "Verify Pre-fixed Institutional Sessions", "type": "checkbox", "default": True}
        ],
        "backend_function": "src.validation.validator.IndependentTimetableValidator.validate()",
        "expected_result": "Binary certification flag (PASS/FAIL) with an exhaustive list of resource-specific violation messages.",
        "modifies_data": False,
        "requires_approval": False,
        "allowed_roles": ["ADMIN", "DEAN", "HOD", "FACULTY"],
        "status": "Working",
        "icon": "🔍"
    },
    {
        "id": "tool_cohort_overlap_inspector",
        "category": "Timetable Validation",
        "name": "Cohort & Multidisciplinary Overlap Inspector",
        "tagline": "Inspects shared student memberships across major sections, minors, and multidisciplinary electives.",
        "purpose": "Evaluates clashing cohort combinations using the generalized atomic student membership model.",
        "problem_solved": "Prevents elective students from having simultaneous lectures across disparate departments.",
        "required_inputs": [
            {"name": "group_a", "label": "Primary Student Cohort", "type": "group_select", "default": "GRP_CSE_A"},
            {"name": "group_b", "label": "Comparison Cohort", "type": "group_select", "default": "GRP_MDC_B1"}
        ],
        "backend_function": "src.csp.overlap.CohortOverlapManager.has_overlap()",
        "expected_result": "Direct overlap decision, shared student roster count, and precomputed clash index.",
        "modifies_data": False,
        "requires_approval": False,
        "allowed_roles": ["ADMIN", "DEAN", "HOD", "FACULTY"],
        "status": "Working",
        "icon": "👥"
    },

    # ── CATEGORY C: OPTIMIZATION & DIAGNOSTICS ──
    {
        "id": "tool_conflict_explainer",
        "category": "Optimization & Diagnostics",
        "name": "Explainable Infeasibility Diagnostic Engine",
        "tagline": "Performs root-cause analysis on overconstrained or unassigned course sessions.",
        "purpose": "Identifies why an assignment failed (e.g. room shortage vs faculty blackout) and suggests remedies.",
        "problem_solved": "Replaces opaque solver failures with transparent, actionable academic recommendations.",
        "required_inputs": [
            {"name": "diagnostic_mode", "label": "Test Scenario", "type": "select", "options": ["Benchmark Infeasible Scenario (Faculty Blackout + Room Shortage)", "Active Schedule Diagnostic"], "default": "Benchmark Infeasible Scenario (Faculty Blackout + Room Shortage)"}
        ],
        "backend_function": "src.diagnostics.explainer.ConflictExplainer.diagnose_unassigned_sessions()",
        "expected_result": "Diagnostic table with root cause, constraint violated, and specific actionable recommendations.",
        "modifies_data": False,
        "requires_approval": False,
        "allowed_roles": ["ADMIN", "DEAN", "HOD"],
        "status": "Working",
        "icon": "💡"
    },
    {
        "id": "tool_ml_conflict_classifier",
        "category": "Optimization & Diagnostics",
        "name": "ML Conflict Risk Predictor",
        "tagline": "Random Forest model (1,800 historical records, AUC 0.9974) evaluates conflict risk.",
        "purpose": "Scores assignment feature vectors to predict collision probability before search exploration.",
        "problem_solved": "Guides LCV value ordering to prioritize high-feasibility slots, cutting search backtracks.",
        "required_inputs": [
            {"name": "day_index", "label": "Day of Week", "type": "select", "options": ["Monday (0)", "Tuesday (1)", "Wednesday (2)", "Thursday (3)", "Friday (4)"], "default": "Monday (0)"},
            {"name": "slot_index", "label": "Slot Number (1-7)", "type": "slider", "min": 1, "max": 7, "default": 3, "step": 1},
            {"name": "enrolled_students", "label": "Enrolled Cohort Size", "type": "slider", "min": 20, "max": 120, "default": 55, "step": 5},
            {"name": "room_capacity", "label": "Proposed Room Capacity", "type": "slider", "min": 30, "max": 150, "default": 60, "step": 10}
        ],
        "backend_function": "src.ml.classifier.TimetableConflictClassifier.predict()",
        "expected_result": "Feasibility vs Conflict classification with probabilistic confidence score and feature contributions.",
        "modifies_data": False,
        "requires_approval": False,
        "allowed_roles": ["ADMIN", "DEAN", "HOD", "FACULTY"],
        "status": "Working",
        "icon": "📈"
    },
    {
        "id": "tool_solver_benchmarker",
        "category": "Optimization & Diagnostics",
        "name": "Head-to-Head Solver Benchmarking Suite",
        "tagline": "Compares Baseline CSP vs ML-Guided CSP across execution speed, nodes explored & backtracks.",
        "purpose": "Measures empirical speedup, backtrack reduction, and solution quality across solver implementations.",
        "problem_solved": "Provides rigorous evidence of algorithmic efficiency and heuristic optimization.",
        "required_inputs": [
            {"name": "runs", "label": "Evaluation Runs per Solver", "type": "slider", "min": 1, "max": 3, "default": 1, "step": 1}
        ],
        "backend_function": "src.benchmarking.benchmark.TimetableBenchmarker.run_full_benchmark()",
        "expected_result": "Side-by-side performance comparison matrix with execution time (s), backtrack count, and efficiency gain %.",
        "modifies_data": False,
        "requires_approval": False,
        "allowed_roles": ["ADMIN", "DEAN"],
        "status": "Working",
        "icon": "⚡"
    },

    # ── CATEGORY D: ACADEMIC OPERATIONS ──
    {
        "id": "tool_substitute_matcher",
        "category": "Academic Operations",
        "name": "Faculty Substitute Recommendation Engine",
        "tagline": "Ranks and matches qualified substitute teachers for absent faculty based on department & load.",
        "purpose": "Identifies conflict-free faculty members eligible to cover a session during an instructor absence.",
        "problem_solved": "Eliminates cancelled lectures by automatically matching qualified peers who are free and within workload caps.",
        "required_inputs": [
            {"name": "day_of_week", "label": "Day of Absence", "type": "select", "options": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"], "default": "Friday"},
            {"name": "slot_id", "label": "Time Slot (1-7)", "type": "slider", "min": 1, "max": 7, "default": 2, "step": 1},
            {"name": "course_id", "label": "Target Course", "type": "course_select", "default": "CS101"},
            {"name": "absent_faculty_id", "label": "Absent Instructor", "type": "faculty_select", "default": "FAC01"}
        ],
        "backend_function": "src.operations.substitute_matcher.SubstituteMatcher.find_substitutes()",
        "expected_result": "Ranked candidates scored out of 100 with explainable match rationale (department affiliation, workload ceiling).",
        "modifies_data": False,
        "requires_approval": True,
        "allowed_roles": ["ADMIN", "DEAN", "HOD"],
        "status": "Working",
        "icon": "👨‍🏫"
    },
    {
        "id": "tool_makeup_feasibility",
        "category": "Academic Operations",
        "name": "Makeup Class Joint-Feasibility Checker",
        "tagline": "Verifies multi-resource availability (Room, Faculty, Cohort, Maintenance) for makeup slots.",
        "purpose": "Evaluates proposed date and time slot for a compensatory makeup lecture.",
        "problem_solved": "Rejects makeup requests if the room is occupied by a regular class or maintenance, even if faculty is free.",
        "required_inputs": [
            {"name": "proposed_date", "label": "Proposed Date (YYYY-MM-DD)", "type": "date", "default": "2026-11-28"},
            {"name": "day_of_week", "label": "Day of Week", "type": "select", "options": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"], "default": "Saturday"},
            {"name": "slot_id", "label": "Proposed Slot (1-7)", "type": "slider", "min": 1, "max": 7, "default": 3, "step": 1},
            {"name": "room_id", "label": "Proposed Room", "type": "room_select", "default": "ROOM_CR201"},
            {"name": "faculty_id", "label": "Instructing Faculty", "type": "faculty_select", "default": "FAC01"},
            {"name": "group_id", "label": "Student Cohort", "type": "group_select", "default": "GRP_CSE_A"},
            {"name": "course_id", "label": "Course", "type": "course_select", "default": "CS101"}
        ],
        "backend_function": "src.operations.makeup_service.MakeupSchedulingService.evaluate_makeup_feasibility()",
        "expected_result": "Binary feasibility result with exact clash explanations across all 9 joint availability checks.",
        "modifies_data": False,
        "requires_approval": False,
        "allowed_roles": ["ADMIN", "DEAN", "HOD", "FACULTY"],
        "status": "Working",
        "icon": "🔄"
    },
    {
        "id": "tool_localized_rescheduler",
        "category": "Academic Operations",
        "name": "Localized Single-Session Rescheduler",
        "tagline": "Moves an individual class atomically with rollback guarantee without regenerating the timetable.",
        "purpose": "Performs one-off slot or room swaps while ensuring zero newly introduced hard clashes.",
        "problem_solved": "Avoids full schedule regeneration for minor day-to-day timetable adjustments.",
        "required_inputs": [
            {"name": "new_day", "label": "Target Day of Week", "type": "select", "options": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"], "default": "Tuesday"},
            {"name": "new_slot", "label": "Target Slot (1-7)", "type": "slider", "min": 1, "max": 7, "default": 4, "step": 1},
            {"name": "new_room_id", "label": "Target Room (Optional)", "type": "room_select", "default": "Keep Existing Room"}
        ],
        "backend_function": "src.operations.rescheduler.LocalizedRescheduler.reschedule_session()",
        "expected_result": "Atomic session move with before/after state transition logged in audit trail.",
        "modifies_data": True,
        "requires_approval": True,
        "allowed_roles": ["ADMIN", "DEAN", "HOD"],
        "status": "Working",
        "icon": "📆"
    },
    {
        "id": "tool_absence_manager",
        "category": "Academic Operations",
        "name": "Faculty Absence & Impact Assessment",
        "tagline": "Registers instructor leave, flags affected sessions, and queues substitution proposals.",
        "purpose": "Prevents absent faculty from being scheduled and tracks required class coverage.",
        "problem_solved": "Coordinates immediate response to faculty absences with full audit history.",
        "required_inputs": [
            {"name": "faculty_id", "label": "Absent Faculty Member", "type": "faculty_select", "default": "FAC06"},
            {"name": "start_date", "label": "Leave Start Date", "type": "date", "default": "2026-11-27"},
            {"name": "end_date", "label": "Leave End Date", "type": "date", "default": "2026-11-27"},
            {"name": "reason", "label": "Absence Reason", "type": "text", "default": "Medical Leave"}
        ],
        "backend_function": "src.operations.absence_service.FacultyAbsenceService.record_absence()",
        "expected_result": "Absence registration ID with full list of affected scheduled sessions requiring coverage.",
        "modifies_data": True,
        "requires_approval": True,
        "allowed_roles": ["ADMIN", "DEAN", "HOD", "FACULTY"],
        "status": "Working",
        "icon": "📋"
    }
]

def get_tool_by_id(tool_id: str) -> Dict[str, Any]:
    """Retrieve tool metadata by unique ID."""
    for tool in TOOL_CATALOG:
        if tool["id"] == tool_id:
            return tool
    raise ValueError(f"Tool with ID '{tool_id}' not found in registry.")

def get_tools_by_category(category: str) -> List[Dict[str, Any]]:
    """Retrieve all tools belonging to a category."""
    return [t for t in TOOL_CATALOG if t["category"] == category]
