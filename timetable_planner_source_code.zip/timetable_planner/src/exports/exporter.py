"""
NEP-2020 Multidisciplinary Academic Timetable Planning & Conflict Resolution System
Export Engine: Multi-Format Reports (Excel, CSV, PDF) - Repaired for In-Memory Buffers (SYNC-01)

SIH 2025 | Problem Statement SIH25091
Team: Gandikota Sai Chandana (12511912) & Inayat (12512142)
Subject Code: K3P25IL
"""

import io
import os
import pandas as pd
from typing import Dict, List, Any, Optional
from reportlab.lib.pagesizes import letter, landscape, A4
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
SLOTS = [1, 2, 3, 4, 5, 6, 7]

class TimetableExporter:
    """Handles multi-format export of generated timetables, benchmark audits, and conflict diagnostics."""

    @staticmethod
    def export_to_csv_buffer(records: List[Dict[str, Any]]) -> io.BytesIO:
        """Export raw allocation records directly to an in-memory CSV BytesIO buffer."""
        df = pd.DataFrame(records)
        buf = io.BytesIO()
        df.to_csv(buf, index=False, encoding="utf-8")
        buf.seek(0)
        return buf

    @staticmethod
    def export_to_csv(records: List[Dict[str, Any]], output_path: str) -> str:
        """Export raw allocation records to CSV format on disk."""
        df = pd.DataFrame(records)
        df.to_csv(output_path, index=False)
        return output_path

    @staticmethod
    def export_to_excel_buffer(
        records: List[Dict[str, Any]],
        audit_summary: Optional[Dict[str, Any]] = None
    ) -> io.BytesIO:
        """
        Generate a multi-sheet Excel workbook in an in-memory BytesIO buffer:
        Sheet 1: Master Schedule (All sessions)
        Sheet 2: Group Grids (Weekly schedule grid for student groups)
        Sheet 3: Faculty Grids (Weekly schedule grid for faculty members)
        Sheet 4: Audit & Verification (Compliance checklist)
        """
        df = pd.DataFrame(records)
        buf = io.BytesIO()
        
        with pd.ExcelWriter(buf, engine="openpyxl") as writer:
            # 1. Master Schedule
            df.to_excel(writer, sheet_name="Master Schedule", index=False)
            
            # 2. Group Grids
            group_grid_rows = []
            if "group_id" in df.columns:
                for gid in sorted(df["group_id"].unique()):
                    g_sub = df[df["group_id"] == gid]
                    for day in DAYS:
                        row_data = {"Group": gid, "Day": day}
                        for s in SLOTS:
                            match = g_sub[(g_sub["day"] == day) & (g_sub["slot_id"] == s)]
                            if not match.empty:
                                m = match.iloc[0]
                                row_data[f"Slot {s}"] = f"{m.get('course_id', '')} ({m.get('room_id', '')}) - {m.get('faculty_name', '')}"
                            else:
                                row_data[f"Slot {s}"] = "FREE"
                        group_grid_rows.append(row_data)
            pd.DataFrame(group_grid_rows).to_excel(writer, sheet_name="Group Grids", index=False)

            # 3. Faculty Grids
            faculty_grid_rows = []
            if "faculty_id" in df.columns:
                for fid in sorted(df["faculty_id"].unique()):
                    f_sub = df[df["faculty_id"] == fid]
                    f_name = f_sub["faculty_name"].iloc[0] if not f_sub.empty and "faculty_name" in f_sub.columns else fid
                    for day in DAYS:
                        row_data = {"Faculty ID": fid, "Faculty Name": f_name, "Day": day}
                        for s in SLOTS:
                            match = f_sub[(f_sub["day"] == day) & (f_sub["slot_id"] == s)]
                            if not match.empty:
                                m = match.iloc[0]
                                row_data[f"Slot {s}"] = f"{m.get('course_id', '')} [{m.get('group_id', '')}] ({m.get('room_id', '')})"
                            else:
                                row_data[f"Slot {s}"] = "FREE"
                        faculty_grid_rows.append(row_data)
            pd.DataFrame(faculty_grid_rows).to_excel(writer, sheet_name="Faculty Grids", index=False)

            # 4. Audit Summary
            if audit_summary:
                audit_records = [
                    {"Parameter": "Verification Status", "Value": audit_summary.get("audit_status", "PASSED")},
                    {"Parameter": "Total Hard Violations", "Value": audit_summary.get("total_hard_violations", 0)},
                    {"Parameter": "Independent Validator Passed", "Value": audit_summary.get("is_valid", True)},
                    {"Parameter": "Total Scheduled Sessions", "Value": len(df)},
                    {"Parameter": "Compliance Framework", "Value": "NEP-2020 Multidisciplinary Criteria"}
                ]
                pd.DataFrame(audit_records).to_excel(writer, sheet_name="Audit & Compliance", index=False)

        buf.seek(0)
        return buf

    @staticmethod
    def export_to_excel(
        records: List[Dict[str, Any]],
        output_path: str,
        audit_summary: Optional[Dict[str, Any]] = None
    ) -> str:
        """Generate a multi-sheet Excel workbook on disk."""
        buf = TimetableExporter.export_to_excel_buffer(records, audit_summary)
        with open(output_path, "wb") as f:
            f.write(buf.getvalue())
        return output_path

    @staticmethod
    def export_to_pdf_buffer(
        records: List[Dict[str, Any]],
        title: str = "NEP-2020 Academic Master Timetable",
        sample_group_id: str = "GRP_CSE_A"
    ) -> io.BytesIO:
        """Generate academic timetable PDF in an in-memory BytesIO buffer."""
        buf = io.BytesIO()
        doc = SimpleDocTemplate(
            buf,
            pagesize=landscape(A4),
            leftMargin=30,
            rightMargin=30,
            topMargin=30,
            bottomMargin=30
        )
        
        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            "DocTitle",
            parent=styles["Heading1"],
            fontSize=16,
            leading=20,
            textColor=colors.HexColor("#0F172A"),
            spaceAfter=6
        )
        subtitle_style = ParagraphStyle(
            "DocSubTitle",
            parent=styles["Normal"],
            fontSize=9,
            leading=12,
            textColor=colors.HexColor("#475569"),
            spaceAfter=12
        )
        cell_style = ParagraphStyle(
            "CellText",
            parent=styles["Normal"],
            fontSize=7,
            leading=9,
            textColor=colors.HexColor("#1E293B")
        )
        header_cell_style = ParagraphStyle(
            "HeaderCellText",
            parent=styles["Normal"],
            fontSize=8,
            leading=10,
            fontName="Helvetica-Bold",
            textColor=colors.white
        )

        elements = []
        elements.append(Paragraph(title, title_style))
        subtitle_text = (
            "Smart India Hackathon 2025 | Problem Statement SIH25091 | "
            "Team: Gandikota Sai Chandana (12511912) & Inayat (12512142) | Subject Code: K3P25IL"
        )
        elements.append(Paragraph(subtitle_text, subtitle_style))
        elements.append(Spacer(1, 8))

        df = pd.DataFrame(records)
        target_group = sample_group_id
        if "group_id" in df.columns:
            available_groups = df["group_id"].unique()
            if sample_group_id not in available_groups and len(available_groups) > 0:
                target_group = available_groups[0]
            g_sub = df[df["group_id"] == target_group]
        else:
            g_sub = pd.DataFrame()

        grid_data = [
            [
                Paragraph("<b>Day / Slot</b>", header_cell_style),
                Paragraph("<b>Slot 1<br/>09:00-10:00</b>", header_cell_style),
                Paragraph("<b>Slot 2<br/>10:00-11:00</b>", header_cell_style),
                Paragraph("<b>Slot 3<br/>11:15-12:15</b>", header_cell_style),
                Paragraph("<b>Slot 4<br/>12:15-13:15</b>", header_cell_style),
                Paragraph("<b>Slot 5<br/>14:00-15:00</b>", header_cell_style),
                Paragraph("<b>Slot 6<br/>15:00-16:00</b>", header_cell_style),
                Paragraph("<b>Slot 7<br/>16:00-17:00</b>", header_cell_style),
            ]
        ]

        for day in DAYS:
            row = [Paragraph(f"<b>{day}</b>", cell_style)]
            for s in SLOTS:
                if not g_sub.empty and "day" in g_sub.columns and "slot_id" in g_sub.columns:
                    match = g_sub[(g_sub["day"] == day) & (g_sub["slot_id"] == s)]
                    if not match.empty:
                        m = match.iloc[0]
                        cell_content = f"<b>{m.get('course_id', '')}</b><br/>{m.get('room_id', '')}<br/>{m.get('faculty_name', '').split()[-1]}"
                        row.append(Paragraph(cell_content, cell_style))
                    else:
                        row.append(Paragraph("<font color='#94A3B8'>FREE</font>", cell_style))
                else:
                    row.append(Paragraph("<font color='#94A3B8'>FREE</font>", cell_style))
            grid_data.append(row)

        table = Table(grid_data, colWidths=[65, 95, 95, 95, 95, 95, 95, 95])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#0D9488")),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
        ]))
        elements.append(table)

        doc.build(elements)
        buf.seek(0)
        return buf

    @staticmethod
    def export_to_pdf(
        records: List[Dict[str, Any]],
        output_path: str,
        title: str = "NEP-2020 Academic Master Timetable",
        sample_group_id: str = "GRP_CSE_A"
    ) -> str:
        """Generate academic timetable PDF on disk."""
        buf = TimetableExporter.export_to_pdf_buffer(records, title, sample_group_id)
        with open(output_path, "wb") as f:
            f.write(buf.getvalue())
        return output_path
